
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>K&B IT SOLUTIONS | IDEA FOR YOUR SECURE BUSINESS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<meta name="keywords" content="Electrician Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--// bootstrap-css -->
<!-- css -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
<!--// css -->
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font-awesome.min.css" />
<!-- //font-awesome icons -->
<!-- font -->
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,100i,300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>
<!-- //font -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script src="js/main.js"></script>

<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<![endif]-->
</head>
<body>
	<!-- banner -->
	<div class="banner jarallax">
		<div class="agileinfo-dot">
			<div class="w3ls-banner-info-bottom">
				<?php include("banner.php") ?>
			</div>
			<div class="header">
				<?php include("header.php")?>
			</div>
			<div class="w3layouts-banner">
				<div class="container">
					<section class="slider">
						<div class="flexslider">
							<ul class="slides">
								<li>
									<div class="agileits_w3layouts_banner_info">
										<h3>pos/bar code system</h3>
										<p></p>
									</div>
								</li>
								<li>
									<div class="agileits_w3layouts_banner_info">
										<h3>cctv,websites,time attendence</h3>
										<p></p>
									</div>
								</li>
								<li>
									<div class="agileits_w3layouts_banner_info">
										<h3>PABX,mobile applications</h3>
										<p></p>
									</div>
								</li>
                                <li>
									<div class="agileits_w3layouts_banner_info">
										<h3>Networking,server centralized audio system</h3>
										<p></p>
									</div>
								</li>
							</ul>
						</div>
				</section>
			<!-- flexSlider -->
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
					$(window).load(function(){
					  $('.flexslider').flexslider({
						animation: "slide",
						start: function(slider){
						  $('body').removeClass('loading');
						}
					  });
					});
				</script>
			<!-- //flexSlider -->

				</div>
			</div>
		</div>
	</div>
	<!-- //banner -->
	<!-- services -->
<div class="services">
		<div class="container">
			<div class="agileits_heading_section">
				<h3 class="wthree_head">Welcome to K&B It Solutions</h3>
				<p class="agileits_w3layouts_para w3_agile_para">Idea To Secure Your Business.</p>
			</div>
			<div class="w3layouts_skills_grids w3layouts_featured_services_grids">
			<div class="col-md-6 w3_featured_services_right">
					<img src="images/2.jpg" alt="image" width="540" height="440" class="img-responsive">
				</div>
				<div class="col-md-6 w3_featured_services_left">
					<div class="w3_featured_services_left_grid">
						<div class="col-xs-4 w3_featured_services_left_gridl">
							<div class="hi-icon-wrap hi-icon-effect-9 hi-icon-effect-9a">
								<i class="hi-icon fa-arrow-right"> </i>
							</div>
						</div>
						<div class="col-xs-8 w3_featured_services_left_gridr">
							<h4>POS/Bar Code System</h4>
							<p></p>
						</div>
						<div class="clearfix"> </div>
					</div>
					
					<div class="w3_featured_services_left_grid">
						<div class="col-xs-4 w3_featured_services_left_gridl">
							<div class="hi-icon-wrap hi-icon-effect-9 hi-icon-effect-9a">
								<i class="hi-icon fa-plug"> </i>
							</div>
						</div>
						<div class="col-xs-8 w3_featured_services_left_gridr">
							<h4>Super Market Software Solution</h4>
							<p></p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="w3_featured_services_left_grid">
						<div class="col-xs-4 w3_featured_services_left_gridl">
							<div class="hi-icon-wrap hi-icon-effect-9 hi-icon-effect-9a">
								<i class="hi-icon fa-power-off"> </i>
							</div>
						</div>
						<div class="col-xs-8 w3_featured_services_left_gridr">
							<h4>Website Solution</h4>
							<p></p>
						</div>
						<div class="clearfix"> </div>
					</div>
					
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //services -->

	<!-- banner-bottom -->
	<div class="banner-bottom">
		<div class="container">
			<div class="agileits_heading_section">
				<h3 class="wthree_head">K&B it Services</h3>
				<p class="agileits_w3layouts_para w3_agile_para">Idea To Secure Your Business.</p>
			</div>
			
			<div class="agileits_banner_bottom_grid_three">
				<div class="col-md-4 agileinfo_banner_bottom_grid_three_left">
					<div class="wthree_banner_bottom_grid_three_left1 grid">
						<figure class="effect-roxy">
							<img src="images/s5.jpg" alt="image" width="640" height="425" class="img-responsive" />
							<figcaption>
							  <h3>cctv installation</h3>
							  <p>* Perfect for home and office surveillance<br>
                                   * Captures clear video even in total darkness<br>
                                   * Captures faces clearly from across a room
                              </p>
						  </figcaption>			
					  </figure>
					</div>
					<p class="w3_agileits_para">When we leave our homes or offices unattended, anything can happen. With nannies, coworkers, and roommates around, it’s important to keep a close watch on things.</p>
				</div>
				<div class="col-md-4 agileinfo_banner_bottom_grid_three_left">
					<div class="wthree_banner_bottom_grid_three_left1 grid">
						<figure class="effect-roxy">
							<img src="" alt=" " class="img-responsive" />
							<figcaption>
								<h3></h3>
								<p></p>
							</figcaption>			
						</figure>
					</div>
					<p class="w3_agileits_para">K&B IT Solutions also gives Services like Doors Security,Web Solutions,Mobile Application Solutions,Super Market Software Solutions And Networking Solutions.</p>
				</div>
				<div class="col-md-4 agileinfo_banner_bottom_grid_three_left">
					<div class="wthree_banner_bottom_grid_three_left1 grid">
						<figure class="effect-roxy">
							<img src="images/s2.jpg" alt="image" width="640" height="390" class="img-responsive" />
							<figcaption>
							  <h3>Thumb Atttendance</h3>
								<p>* Fingerprint Recognition<br>
                                   * Face Recognition<br>
                                   * Keystroke Dynamics
                              </p>
							</figcaption>			
						</figure>
					</div>
					<p class="w3_agileits_para">Using a fingerprint attendance system avoids time registration fraud, also known as buddy punching, and reduces overhead for security staff when badges are lost or pincodes forgotten.</p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //banner-bottom -->
<!-- stats -->
	<div class="stats">
		<div class="container">
			<div class="col-md-3 w3_counter_grid">
				<div class="w3_agileits_counter_grid">
					<i class="fa fa-umbrella" aria-hidden="true"></i>
				</div>
				<p class="counter">1,965</p>
				<h3>Orders Completed</h3>
			</div>
			<div class="col-md-3 w3_counter_grid">
				<div class="w3_agileits_counter_grid">
					<i class="fa fa-users" aria-hidden="true"></i>
				</div>
				<p class="counter">432</p>
				<h3>Crew Members</h3>
			</div>
			<div class="col-md-3 w3_counter_grid">
				<div class="w3_agileits_counter_grid">
					<i class="fa fa-comments" aria-hidden="true"></i>
				</div>
				<p class="counter">690</p>
				<h3>Million Man-hours</h3>
			</div>
			<div class="col-md-3 w3_counter_grid">
				<div class="w3_agileits_counter_grid">
					<i class="fa fa-book" aria-hidden="true"></i>
				</div>
				<p class="counter">124</p>
				<h3>Counties Covered</h3>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //stats -->
<!-- stats -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countup.js"></script>
		<script>
			$('.counter').countUp();
		</script>
<!-- //stats -->
<!-- team -->
<div class="banner-bottom">
		<div class="container">
			<div class="agileits_heading_section">
				<h3 class="wthree_head">meet our team</h3>
				<p class="agileits_w3layouts_para w3_agile_para">Etiam malesuada odio vitae enim malesuada accumsan diam sed.</p>
			</div>
			<div class="w3ls_banner_bottom_grids">
				<div class="col-md-3 agile_team_grid">
					<div class="agileits_w3layouts_team_grid">
						<ul class="agileinfo_social_icons">
							<li><a href="#" class="w3_agileits_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="wthree_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="agileinfo_google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						</ul>
						<img src="images/t2.jpg" alt=" " class="img-responsive">
					</div>
					<h4>Cayden</h4>
					<p>Manager</p>
				</div>
				<div class="col-md-3 agile_team_grid">
					<div class="agileits_w3layouts_team_grid">
						<ul class="agileinfo_social_icons">
							<li><a href="#" class="w3_agileits_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="wthree_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="agileinfo_google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						</ul>
						<img src="images/t4.jpg" alt=" " class="img-responsive">
					</div>
					<h4>Emmeline</h4>
					<p>Electrician</p>
				</div>
				<div class="col-md-3 agile_team_grid">
					<div class="agileits_w3layouts_team_grid">
						<ul class="agileinfo_social_icons">
							<li><a href="#" class="w3_agileits_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="wthree_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="agileinfo_google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						</ul>
						<img src="images/t3.jpg" alt=" " class="img-responsive">
					</div>
					<h4>Chadwick</h4>
					<p>Manager</p>
				</div>
				<div class="col-md-3 agile_team_grid">
					<div class="agileits_w3layouts_team_grid">
						<ul class="agileinfo_social_icons">
							<li><a href="#" class="w3_agileits_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="wthree_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="agileinfo_google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						</ul>
						<img src="images/t1.jpg" alt=" " class="img-responsive">
					</div>
					<h4>Brogan</h4>
					<p>Electrician</p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //team -->
	<!-- footer -->
<div class="footer">
		<?php include("footer.php") ?>
		
	</div>
<!-- //footer -->
<!-- copy-right -->
	<div class="w3_agileits_copy_right_social">
		<?php include("copyright.php"); ?>
	</div>
<!-- //copy-right -->
	<!-- jarallax -->
	<script src="js/jarallax.js"></script>
	<script src="js/SmoothScroll.min.js"></script>
	<script type="text/javascript">
		/* init Jarallax */
		$('.jarallax').jarallax({
			speed: 0.5,
			imgWidth: 1366,
			imgHeight: 768
		})
	</script>
	<!-- //jarallax -->
	<script src="js/bootstrap.js"></script>
<!-- //here ends scrolling icon -->
</body>	
</html>