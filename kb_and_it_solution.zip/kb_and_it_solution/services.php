
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>K&B IT SOLUTIONS | IDEA FOR YOUR SECURE BUSINESS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<meta name="keywords" content="Electrician Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--// bootstrap-css -->
<!-- css -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
<!--// css -->
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font-awesome.min.css" />
<!-- //font-awesome icons -->
<!-- font -->
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,100i,300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>
<!-- //font -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script src="js/main.js"></script>

<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<![endif]-->
</head>
<body>
	<!-- banner -->
	<div class="banner-1 jarallax">
		<div class="agileinfo-dot-1">
			<div class="w3ls-banner-info-bottom">
				<?php include("banner.php") ?>
			</div>
			<div class="header">
				<?php include("header.php")?>
			</div>
		</div>
	</div>
	<!-- //banner -->
	<!-- services -->
	<div class="agile-prod">
		<div class="container">
			<h3 class="wthree_head">Services</h3>
				<p class="agileits_w3layouts_para w3_agile_para">Our Services In Some Solutions.</p>
		<div class="agile-prod1">
			<div class="col-md-6 agile-sub">
				<h4>security doors</h4>
				<p>We repair and install a variety of commercial and residential security doors. Don't take risks, call the experts today!.</p>
				<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">24/7 Security Door Services.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Steel Security Screen Doors.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Custom Security Doors.</a></li>
				</ul>
			</div>
			<div class="col-md-6 agile-img">
				<img src="images/door.jpg" alt="image" width="640" height="383">
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="agile-prod1">
			<div class="col-md-6 agile-img">
				<img src="images/g2.jpg" alt="image">
			</div>
			<div class="col-md-6 agile-sub">
				<h4>cctv security surveillance</h4>
				<p>We believe Surveillance and CCTV in UAE demand 24 hour operation, excellent support and quality.</p>
				<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">IP Solutions.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Greater Flexibility.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Higher Quality Images.</a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="agile-prod1">
			<div class="col-md-6 agile-sub">
				<h4>Networking Solutions</h4>
				<p>We'll help you secure your data, expand your reach and create a network that positions your organization for growth.</p>
				<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Network Security.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Backup/Disaster Recovery.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Virtulaization.</a></li>
				</ul>
			</div>
            
			<div class="col-md-6 agile-img">
				<img src="images/g3.jpg" alt="image" width="640" height="382">
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="agile-prod1">
			<div class="col-md-6 agile-img">
				<img src="images/g4.jpg" alt="image">
			</div>
			<div class="col-md-6 agile-sub">
				<h4>Analouge Pbx</h4>
				<p>Simplify Your Business Communication. Speak With A Hosted PBX Expert Today!</p>
				<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Personalized onsite installation and ongoing support.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Benefit from advanced features—such as on-demand capacity.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Eliminate CAPEX costs by moving to a fully cloud-based communications system.</a></li>
				</ul>
			</div>
            
			<div class="clearfix"> </div>
		</div>
        <div class="agile-prod1">
			<div class="col-md-6 agile-sub">
				<h4>Mobile Applications</h4>
				<p>With our profound experience,methadologies and development process,we provide top notch app solutions utilizing cutting edge tchnologies.</p>
				<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Google Android App Developement.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Multi Platform App Developement.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">loT Android App Developement.</a></li>
				</ul>
			</div>
			<div class="col-md-6 agile-img">
				<img src="images/g5.jpg" alt="image" width="640" height="413">
			</div>
			<div class="clearfix"> </div>
		</div>
        <div class="agile-prod1">
			<div class="col-md-6 agile-img">
				<img src="images/g6.jpg" alt="image">
			</div>
			<div class="col-md-6 agile-sub">
				<h4>Website Solutions</h4>
				<p>Get expert hands with simple and professional solutions of the best modern web trends.</p>
				<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Design creative and Responsive Website.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Simple and professional.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">results-driven websites that WORK.</a></li>
				</ul>
			</div>
            
			<div class="clearfix"> </div>
		</div>
        <div class="agile-prod1">
			<div class="col-md-6 agile-sub">
				<h4>Barcode printing</h4>
				<p>K&B offers the broadest range of barcode printing solutions.We can help you choose from direct thermal or thermal transfer printing methods and evaluate which brand is right for your application.</p>
				<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Industrial Barcode Printers.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Mobile Label Printers.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Desktop Barcode Label Printers.</a></li>
				</ul>
			</div>
			<div class="col-md-6 agile-img">
				<img src="images/g7.jpg" alt="image" width="640" height="413">
			</div>
			<div class="clearfix"> </div>
		</div>
        <div class="agile-prod1">
			<div class="col-md-6 agile-img">
				<img src="images/g8.jpg" alt="image" width="640" height="410">
			</div>
			<div class="col-md-6 agile-sub">
				<h4>Cash Drawer Solution</h4>
				<p>Every business is different. Our Solution Consultants help you create a customized POS cash drawer solution.</p>
				<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">Touch Dynamic Cash Drawers.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">APG 1517 Heavy Duty Cash Drawers.</a></li>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i> <a href="#">APG E3600 Flip-Top Cash Drawers.</a></li>
				</ul>
			</div>
            
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!-- //services -->

	<!-- footer -->
<div class="footer">
		<?php include("footer.php") ?>
		
	</div>
<!-- //footer -->
<!-- copy-right -->
	<div class="w3_agileits_copy_right_social">
		<?php include("copyright.php"); ?>
	</div>
<!-- //copy-right -->
	<!-- jarallax -->
	<script src="js/jarallax.js"></script>
	<script src="js/SmoothScroll.min.js"></script>
	<script type="text/javascript">
		/* init Jarallax */
		$('.jarallax').jarallax({
			speed: 0.5,
			imgWidth: 1366,
			imgHeight: 768
		})
	</script>
	<!-- //jarallax -->
	<script src="js/bootstrap.js"></script>
<!-- //here ends scrolling icon -->
</body>	
</html>