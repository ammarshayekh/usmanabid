<div class="container">
		<h2 class="wthree_head">Subscribe to Newsletter</h2>
				<p class="agileits_w3layouts_para w3_agile_para">Subscribe To Our NewsLetter And Get Updated.</p>
			
				<div class="news-w3l">
					<form action="#" method="post">
						<input type="email" name="Email" placeholder="Enter Your Email..." required>
						<input type="submit" value="Send">
					</form>
				</div>
			<div class="agile_footer_copy">
				<div class="w3agile_footer_grids">
					
					<div class="col-md-4 w3agile_footer_grid">
						<h3>Contact Info</h3>
						<ul>
							<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>1506 Amber Gem Tower, Ajman <span>UAE.</span></li>
							<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info@kandbitsolutions.com</a></li>
							<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+971 52 4441 381</li>
						</ul>
					</div>
					
					<div class="col-md-4 w3agile_footer_grid">
						<h3>About Us</h3>
						<p>K&B IT Solutions is ranked among the top 100 IT Managed Service Providers globally. Our Mission is to become the most respected and referred technology solutions firm serving mid-market, enterprise, and emerging customers in the UAE.</p>
					</div>
					
					<div class="col-md-4 w3agile_footer_grid w3agile_footer_grid1">
						<h3>Navigation</h3>
						<ul>
							<li><span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span><a href="services.php">Services</a></li>
							<li><span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span><a href="projects.php">Projects</a></li>
							<!--<li><span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span><a href="icons.php">Web Icons</a></li>-->
							<li><span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span><a href="contact.php">Contact</a></li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			
		</div>