<?php include("dbConnect.inc.php"); ?>

<?php


	 $full_name=$_POST["name"];
	 $phone_number=$_POST["phone_number"];
	 $email_address=$_POST["email"];
	  $message=$_POST["message"];
	
	
//echo $full_name;

//$insert=mysql_query("insert into contact(full_name,phone_number,email_address,message) values ('$full_name','$phone_number','$email_address','$message')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=cpanel/personal-1.php\">";

 
 $to = "zamboads@gmail.com";
 
 $subject = "An Inquiry";
 
 $email_from = $_REQUEST['email_address'];
 
 $cust_msg = $_REQUEST['message'];
 
 $headers = "From: $email_from";
 
 $sent = mail($to, $subject, $cust_msg, $headers);

 if($sent)
 
{ echo " Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly."; 
 }
 
 else
 
 {echo "email is not sent, there is some error!"; }

?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:500px; height:100px; margin-left:550px; margin-top:300px;">
<p>Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly.</p>
<img src="images/preloader.gif" width="40" height="40" /><br><br><br>
<a href="index.php">You Can Continue Now</a>
</div>
</body>
</html