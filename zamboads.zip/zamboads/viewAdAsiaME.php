<?php
//echo $_GET['adz'];
include('dbConnect.inc.php');
include("outputfunctions.php");
//include('ps_pagination.php');
$sqlCountry="select id,name from countries  order by name asc ";
$resCountry=mysql_query($sqlCountry);
$checkCountry=mysql_num_rows($resCountry);

?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home |Adzmarket</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/home/fevicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	
	<script type="text/javascript" src="js/jquery-1.4.1.min.js"></script>
       <script type="text/javascript">
function selectCity(country_id){
	if(country_id!="-1"){
		loadData('state',country_id);
		$("#city_dropdown").html("<option value='-1'>Select city</option>");	
	}else{
		$("#state_dropdown").html("<option value='-1'>Select state</option>");
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function selectState(state_id){
	if(state_id!="-1"){
		loadData('city',state_id);
	}else{
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function loadData(loadType,loadId){
	var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
	$("#"+loadType+"_loader").show();
    $("#"+loadType+"_loader").fadeIn(400).html('Please wait... <img src="image/loading.gif" />');
	$.ajax({
		type: "POST",
		url: "loadData.php",
		data: dataString,
		cache: false,
		success: function(result){
			$("#"+loadType+"_loader").hide();
			$("#"+loadType+"_dropdown").html("<option value='-1'>Select "+loadType+"</option>");  
			$("#"+loadType+"_dropdown").append(result);  
		}
	});
}
</script>
   
	
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		
        <?php
		include("topheader.php");
		?> 
        <!--/header_top-->
       
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img src="images/home/logo.jpg" alt="" /></a>
						</div>
						
					</div>
					
                    <?php
					
							include("menu.php");
							 
					?>
                    
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom">
         <!--header-bottom-->
			<div class="container">
				<form action="search.php" method="post">
					<div class="col-sm-2" style="margin-left:50px;">
                 
                        <div class="search_box pull-right">
							<select onChange="selectCity(this.options[this.selectedIndex].value)"  name="country"  style="height:60px;width:200px;">
						<option value="-1">Select country</option>
							<?php
								while($rowCountry=mysql_fetch_array($resCountry)){
							?>
						
                        <option value="<?php echo $rowCountry['id']?>"><?php echo $rowCountry['name'	
										]?></option>
						<?php } ?>
						
					</select>
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                 
                        <div class="search_box pull-right">
							 <?php if($checkCountry > 0){ ?>
				
                    <select id="state_dropdown" onChange="selectState(this.options[this.selectedIndex].value)"
                    style="height:60px;width:200px;" name="state">
							
                          <option value="-1">Select state</option>
							</select>
							<span id="state_loader"></span>
					
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                 
                        <div class="search_box pull-right">
							<select id="city_dropdown"  style="height:60px;width:200px;" name="city">
								<option value="-1">Select city</option>
							</select>
							<span id="city_loader"></span>
						
						<?php }else{
								echo 'No Country Name Found'; }
					     ?>

					
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                    
						<div class="search_box pull-right">
							<select  name="category" style="height:60px;width:200px;">
						 <option value="-1">Select Category</option>
                              <?php
							  
								$q = mysql_query("SELECT * FROM `category`");	
							  	while($data= mysql_fetch_array($q)){
								
							  ?>
                              
                              <option value="<?php echo $data['cat_id']; ?>"><?php echo $data['cat_name']; ?></option>
                             
                             <?php } ?>
						
					</select>
						</div>
                        
					</div>
					<div class="col-sm-2">
                    <div class="search_box pull-right">
							<input type="text" style="height:60px; width:180px;" name="title">
						</div>
						
                        
					
				
			</div>
            </form>
		</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	 <section id="slider">
         <!--slider-->
         <div class="container">
            <div class="row">
              

                              <img src="images/asia middle east.jpg" height="500" class="girl img-responsive" alt="" />
                              <!--	<img src="images/home//Untitled-2.png"  class="pricing" alt="" />  -->
                           </div>
                        </div>

      </section>
      <!--/slider-->
	
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Quick Search</h2>
					
					<?php include("quicksearch.php"); ?>
						
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
                <h2 class="title text-center" style="color:#9fc637"><?php echo $_GET['adz']; ?> Adz List</h2>
					
                  
                <!-- list second -->
                
              <?php

$sql = "SELECT id FROM countries WHERE name='$_GET[adz]'";
$rs = mysql_query($sql);

	while($row = mysql_fetch_assoc($rs)) {
		//outputStory1($row['id'],TRUE);
		$countryid = $row['id'];
	
	}
	
// Pagination
				if (isset($_GET['pageno'])) {
   $pageno = $_GET['pageno'];
} else {
   $pageno = 1;
} // if
$query = "SELECT count(*) FROM adz WHERE country_id= '$countryid'";
$result = mysql_query($query) or trigger_error("SQL", E_USER_ERROR);
$query_data = mysql_fetch_row($result);
$numrows = $query_data[0];

$rows_per_page = 10;
$lastpage      = ceil($numrows/$rows_per_page);

$pageno = (int)$pageno;
if ($pageno > $lastpage) {
   $pageno = $lastpage;
} // if
if ($pageno < 1) {
   $pageno = 1;
} // if

$limit = 'LIMIT ' .($pageno - 1) * $rows_per_page .',' .$rows_per_page;

//$sql = mysql_query("SELECT ad_id FROM adz WHERE cat_id='$category'" .
    //"ORDER BY ad_id DESC $limit");
					  
					  
					  $sql = "SELECT * FROM adz WHERE country_id= '$countryid' ORDER BY ad_id DESC $limit";
  $result = mysql_query($sql,$con);
			
			   
 
  while($row = mysql_fetch_array($result)){
echo "<div class='features_items'>";
						
						
							
						echo "<div class='col-sm-4'>";
							echo "<div class='product-image-wrapper'>";
						
						
								
                                echo"<a href='view.php'><img src=" .  $row['image'] . " width='218' height='140'></a> ";
                               echo"<div style='background-color:#666;width:218px' align='center'>";
                               		//echo"<p style='color:#000;font-weight:bold'> Total 8 Pictures </p>"; 
                               echo "</div>";
							
							echo "</div>";
                           echo "</div>";
                        
							echo "<div class='product-image-wrapper' style='margin-left:14px'>";
								echo "<a href='view.php'><strong> ". $row['ad_title'] . "</strong></a><br> ";
						
                      echo "<p style='font-size:10px'>about 3 hours ago</p><br> ";
                      
                      $countryP = $row['country_id'];
							$f = mysql_query("SELECT * FROM `countries` where id = $countryP");
							while($cc= mysql_fetch_array($f)){
									$countryName = $cc['name'];
							}
							
							$stateP = $row['state_id'];
							$ff = mysql_query("SELECT * FROM `states` where id = $stateP");
							while($s= mysql_fetch_array($ff)){
									$stateName = $s['name'];
							}
							
					  		$city = $row['city_id'];
					  		$e = mysql_query("SELECT * FROM `cities` where id = $city");
							while($row1 = mysql_fetch_array($e)){
					   
                      
                     echo "<p><img src='images/home/location.png' width='20' height='20'> " .$row1['name'] .' , '. $stateName.' , '. $countryName. " </p>";
                      
                       }
						echo "<p style='font-size:14px;height:33px' > " .$row['Ad_description'].  "</p><br><br><br><br>";
                            echo"</div>";
				echo"</div>";
							}
							
							
							// Pagination Links
			echo "<table border='0' width='100%'>";
			echo "<tr><td colspan=4 align=center>";
			
			if ($pageno == 1) {
   			echo " FIRST PREV ";
				} else {
   							echo " <a href='{$_SERVER['PHP_SELF']}?adz=$_GET[adz]&pageno=1'>FIRST</a> ";
  							$prevpage = $pageno-1;
   							echo " <a href='{$_SERVER['PHP_SELF']}?adz=$_GET[adz]&?pageno=$prevpage'>PREV</a> ";
						} // if

			echo " ( Page $pageno of $lastpage ) ";

			if ($pageno == $lastpage) {
   				echo " NEXT LAST ";
					} else {
   								$nextpage = $pageno+1;
   								echo " <a href='{$_SERVER['PHP_SELF']}?adz=$_GET[adz]&pageno=$nextpage'>NEXT</a> ";
  							 echo " <a href='{$_SERVER['PHP_SELF']}?adz=$_GET[adz]&pageno=$lastpage'>LAST</a> ";
							} // if
			
			echo "</td></tr>";
			
			//End of Pagination Links
			
			echo "</table>";
?>             
                
			</div>
		</div>
		</div>
	</div>
	
	</section>
	
    <?php
		include("footer.php");
	?>
	
	

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>