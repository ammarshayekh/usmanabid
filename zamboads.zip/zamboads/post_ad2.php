<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Post ad | Adzmarket</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
   <link rel="shortcut icon" href="images/home/fevicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<?php
		include("topheader.php");
		?> 
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.html"><img src="images/home/logo.jpg" alt="" /></a>
						</div>
						<!--<div class="btn-group pull-right">
							<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									USA
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu">
									<li><a href="#">Canada</a></li>
									<li><a href="#">UK</a></li>
								</ul>
							</div>
							
							<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									DOLLAR
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu">
									<li><a href="#">Canadian Dollar</a></li>
									<li><a href="#">Pound</a></li>
								</ul>
							</div>
						</div> -->
					</div>
					  <?php
						include("menu.php");
	 					?>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					
					<div class="col-sm-12">
						<div class="search_box pull-right">
							<input type="text" placeholder="Search"/>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	 	
	<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<!--<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
						</ol> --> 
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="col-sm-6" style="margin-top:90px; padding-left:70px;">
									<img src="images/home/post ad 2.png" class="girl img-responsive" alt="" />
								</div>
								<div class="col-sm-6">
									<img src="images/home/post ad1.jpg" class="girl img-responsive" alt="" />
							<!--	<img src="images/home//Untitled-2.png"  class="pricing" alt="" />  -->
								</div>
							</div>
							<!--<div class="item">
								<div class="col-sm-6">
									<h1>Adzmarket</h1>
									<h2>Free Classifieds adz</h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
									<button type="button" class="btn btn-default get" style="background-color:#B4B1AB;">Get it now</button>
								</div>
								<div class="col-sm-6">
									<img src="images/home/header2.jpg" class="girl img-responsive" alt="" />
								<img src="images/home//Untitled-2.png"  class="pricing" alt="" /> 
								</div>
							</div> --> 
							
							<!--<div class="item">
								<div class="col-sm-6">
									<h1>Adzmarket</h1>
									<h2>Free Classifieds adz</h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
									<button type="button" class="btn btn-default get" style="background-color:#B4B1AB;">Get it now</button>
								</div>
								<div class="col-sm-6">
									<img src="images/home/header3.jpg" class="girl img-responsive" alt="" />
								<img src="images/home/Untitled-2.png" class="pricing" alt="" />
								</div>
							</div> -->
							
						</div>
						
						<!--<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>  -->
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	 <div id="contact-page" class="container" style="margin-top:0px;">
    	<div class="bg">
	    	<div class="row">    		
	    		<div class="col-sm-12">    			   			
					<!--<h2 class="title text-center">Contact <strong>Us</strong></h2>    --> 			    				    				
					
				</div>			 		
			</div>    	
    		<div class="row">  	
	    		<div class="col-sm-8">
	    			<div class="contact-form">
	    				<h2 class="title text-center">Make a Post</h2>
	    				<div class="status alert alert-success" style="display: none"></div>
				    	<form id="main-contact-form" class="contact-form row" name="contact-form" method="post">
						<div class="form-group col-md-6">
				               Add Title <input type="text" name="subject" class="form-control" required placeholder="Add title">
				            </div>
				            <div class="form-group col-md-6">
				            Select Catagory   <select class="form-control" required="required">
							   <option value="">post</option>
							   </select>
				            </div>
						
				            <div class="form-group col-md-6">
				              Asking Price <input type="text" name="subject" class="form-control" required placeholder=" Asking Price">
				            </div>
				            
							<div class="form-group col-md-6">
				               URL:http:// <input type="text" name="subject" class="form-control" required placeholder="Add Url">
				            </div>
				            <div class="form-group col-md-12">
				              Ad Description / Text (We strictly delete all spam ads on daily basis, so dont waste your time to promote your website.)
  <textarea name="message" id="message" required class="form-control" rows="8" placeholder="Your Message Here"></textarea>
				            </div>   
							<div class="form-group col-md-6">
				            Your name  <input type="text" name="subject" class="form-control" required placeholder=" Your name">
				            </div>
							<div class="form-group col-md-6">
				            Your Address  <input type="text" name="subject" class="form-control" required placeholder="Your Address  ">
				            </div>
							<div class="form-group col-md-6">
				               Select City <select class="form-control" required="required">
							   <option value="">post</option>
							   </select>
				            </div>
							<div class="form-group col-md-6">
				             Zip code<input type="text" name="subject" class="form-control" required placeholder="Zip code">
				            </div>
							<div class="form-group col-md-6">
				              Phone / Mobile no <input type="text" name="subject" class="form-control" required placeholder="Phone Number">
				            </div>  
							<div class="form-group col-md-6">
				              Your Email <input type="text" name="subject" class="form-control" required placeholder="Your Email">
				            </div>    
							<div class="form-group col-md-6" style="margin-top:20px;">
				              Spam Filter Question * 5+2=<input type="text" name="subject" class="form-control" required placeholder="">
				            </div> 
							<div class="form-group col-md-6">
				                <div ><img src="security-image.php?width=144" width="144" height="40" alt="Security Image" /></div>
        <input type="text" name="code" id="code" value="" class="form-control" placeholder="Type Security Code Here" />
				            </div>
							   <div class="form-group col-md-6">
				            Upload Picture <input type="file" name="subject"  required="required">
				            </div>
							   
							     <div class="form-group col-md-12">
				               <INPUT type=checkbox id="agree" value="I am agree the terms and conditions" name="agree"> I agree to 
                        the <A href="http://www.adzmarket.com/terms.php" target=_blank>terms of use</A> 
						by making a post. 
				            </div>   
				            <div class="form-group col-md-12">
				                <input type="submit" name="submit" class="btn btn-primary pull-right" value="Post Now">
				            </div>
				        </form>
	    			</div>
	    		</div>
	    	<div class="col-sm-4">
				<img src="images/home/SKYSCRAPPER3 160X600.png" class="girl img-responsive" alt="" />
				
	    			<!--<div class="contact-info">
	    				<h2 class="title text-center">Contact Info</h2>
	    				<address>
	    					<p>Adzmarket Inc.</p>
							<p>935 W. Webster Ave New Streets Chicago, IL 60614, NY</p>
							<p>Newyork USA</p>
							<p>Mobile: +2346 17 38 93</p>
							<p>Fax: 1-714-252-0026</p>
							<p>Email: info@e-shopper.com</p>
	    				</address>
	    				<div class="social-networks">
	    					<h2 class="title text-center">Social Networking</h2>
							<ul>
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-google-plus"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-youtube"></i></a>
								</li>
							</ul>
	    				</div>
	    			</div> -->
    			</div>  			
	    	</div>  
    	</div>	
    </div><!--/#contact-page-->
	
	<?php
		include("footer.php");
	?>
	

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="js/gmaps.js"></script>
	<script src="js/contact.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>