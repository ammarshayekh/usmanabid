<div class="panel-group category-products" id="accordian">
							
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#sportswear">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											US
										</a>
									</h4>
								</div>
								<div id="sportswear" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											
											<li><a href="viewAd1.php?adz=Arizona" 
										>Arizona</a></li>
											
											<li><a href="viewAd1.php?adz=California" 
										>California</a></li>
                                            
											<li><a href="viewAd1.php?adz=Florida" 
										>Florida</a></li>
                                           
											<li><a href="viewAd1.php?adz=Hawaii" 
										>Hawaii</a></li>
											<li><a href="viewAd1.php?adz=Kentucky" 
										>Kentucky</a></li>
											<li><a href="viewAd1.php?adz=Michigan" 
										>Michigan</a></li>
											
											<li><a href="viewAd1.php?adz=Nebraska" 
										>Nebraska</a></li>
											
                                            <li><a href="viewAd1.php?adz=New Jersey" 
										>New Jersey</a></li>
											<li><a href="viewAd1.php?adz=New Mexico" 
										>New Mexico</a></li>
											<li><a href="viewAd1.php?adz=New York" 
										>New York</a></li>
											
											<li><a href="viewAd1.php?adz=Texas" 
										>Texas</a></li>
                                           
											<li><a href="viewAd1.php?adz=West Virginia" 
										>West Virginia</a></li>
											<li><a href="viewAd1.php?adz=Washington" 
										>Washington</a></li>
											
                                          

                                            
										</ul>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#Canda">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Canada
										</a>
									</h4>
								</div>
								<div id="Canda" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="viewAd1.php?adz=Alberta" 
										>Alberta</a></li>
											<li><a href="viewAd1.php?adz=British Columbia" 
										>British Columbia</a></li>
											<li><a href="viewAd1.php?adz=Manitoba" 
										>Manitoba</a></li>
											<li><a href="viewAd1.php?adz=New Brunswick" 
										>New Brunswick</a></li>
											<li><a href="viewAd1.php?adz=Newfoundland and Labrador" 
										>Newfoundland and Labrador</a></li>
											<li><a href="viewAd1.php?adz=Northwest Territories" 
										>Northwest Territories</a></li>
											<li><a href="viewAd1.php?adz=Nova Scotia" 
										>Nova Scotia</a></li>
											<li><a href="viewAd1.php?adz=Ontario" 
										>Ontario</a></li>
											<li><a href="viewAd1.php?adz=Prince Edward Island" 
										>Prince Edward Island</a></li>
											<li><a href="viewAd1.php?adz=Quebec" 
										>Quebec</a></li>
                                            <li><a href="viewAd1.php?adz=Saskatchewan" 
										>Saskatchewan</a></li>
											<li><a href="viewAd1.php?adz=Yukon" 
										>Yukon</a></li>
											
										</ul>
									</div>
								</div>
							</div>
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#Europe">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Europe
										</a>
									</h4>
								</div>
								<div id="Europe" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="viewAdEurope.php?adz=Austria" 
										>Austria</a></li>
											<li><a href="viewAdEurope.php?adz=Belgium" 
										>Belgium</a></li>
											<li><a href="viewAdEurope.php?adz=Czech Republic" 
										>Czech Republic</a></li>
											<li><a href="viewAdEurope.php?adz=Denmark" 
										>Denmark</a></li>
                                            <li><a href="viewAdEurope.php?adz=Finland" 
										>Finland</a></li>
											<li><a href="viewAdEurope.php?adz=France" 
										>France</a></li>
											<li><a href="viewAdEurope.php?adz=Germany" 
										>Germany</a></li>
											<li><a href="viewAdEurope.php?adz=Ireland" 
										>Ireland</a></li>
											<li><a href="viewAdEurope.php?adz=Italy" 
										>Italy</a></li>
											<li><a href="viewAdEurope.php?adz=Netherlands" 
										>Netherlands</a></li>
                                            <li><a href="viewAdEurope.php?adz=Norway" 
										>Norway</a></li>
                                            <li><a href="viewAdEurope.php?adz=Spain" 
										>Spain</a></li>
											<li><a href="viewAdEurope.php?adz=Sweden" 
										>Sweden</a></li>
											<li><a href="viewAdEurope.php?adz=Switzerland" 
										>Switzerland</a></li>
											<li><a href="viewAdEurope.php?adz=Turkey" 
										>Turkey</a></li>
											<li><a href="viewAdEurope.php?adz=Ukraine" 
										>Ukraine</a></li>
                                            <li><a href="viewAdEurope.php?adz=United Kingdom" 
										>United Kingdom</a></li>
											
										</ul>
									</div>
								</div>
                       
							</div>
                            
                            <div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#Africa">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Africa
										</a>
									</h4>
								</div>
								<div id="Africa" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="viewAdAfrica.php?adz=Egypt" 
										>Egypt</a></li>
											<li><a href="viewAdAfrica.php?adz=Kenya" 
										>Kenya</a></li>
                                            <li><a href="viewAdAfrica.php?adz=South Africa" 
										>South Africa</a></li>
											<li><a href="viewAdAfrica.php?adz=Zimbabwe" 
										>Zimbabwe</a></li>
											
											  
										</ul>
									</div>
								</div>
							</div>
                            
                   			<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#Africa1">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Latin America and Caribbean
										</a>
									</h4>
								</div>
								<div id="Africa1" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="viewAdLatin.php?adz=Argentina" 
										>Argentina</a></li>
											<li><a href="viewAdLatin.php?adz=Bolivia" 
										>Bolivia</a></li>
											<li><a href="viewAdLatin.php?adz=Brazil" 
										>Brazil</a></li>
											<li><a href="viewAdLatin.php?adz=Chile" 
										>Chile</a></li>
											<li><a href="viewAdLatin.php?adz=Colombia" 
										>Colombia</a></li>
                                            
                                            <li><a href="viewAdLatin.php?adz=Dominican Republic" 
										>Dominican Republic</a></li>
											<li><a href="viewAdLatin.php?adz=Mexico" 
										>Mexico</a></li>
                                            
                                             <li><a href="viewAdLatin.php?adz=Peru" 
										>Peru</a></li>
											<li><a href="viewAdLatin.php?adz=Uruguay" 
										>Uruguay</a></li>
											  
										</ul>
									</div>
								</div>
								
								
								
							</div>
                            
                            <div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#Oceania">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Oceania
										</a>
									</h4>
								</div>
								<div id="Oceania" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="viewAdOceania.php?adz=Australia" 
										>Australia</a></li>
											<li><a href="viewAdOceania.php?adz=New Zealand" 
										>New Zealand</a></li>
										
										</ul>
									</div>
								</div>
							</div>
                            
                            <div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#Asia">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Asia and Middle East
										</a>
									</h4>
								</div>
								<div id="Asia" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="viewAdAsiaME.php?adz=Bangladesh" 
										>Bangladesh</a></li>
											<li><a href="viewAdAsiaME.php?adz=China" 
										>China</a></li>
											<li><a href="viewAdAsiaME.php?adz=Dubai" 
										>Dubai</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Hong Kong" 
										>Hong Kong</a></li>
											<li><a href="viewAdAsiaME.php?adz=India" 
										>India</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Indonesia" 
										>Indonesia</a></li>
											<li><a href="viewAdAsiaME.php?adz=Iran" 
										>Iran</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Iraq" 
										>Iraq</a></li>
											<li><a href="viewAdAsiaME.php?adz=Palestine" 
										>Palestine</a></li>
											<li><a href="viewAdAsiaME.php?adz=Japan" 
										>Japan</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Korea" 
										>Korea</a></li>
											<li><a href="viewAdAsiaME.php?adz=Kuwait" 
										>Kuwait</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Lebanon" 
										>Lebanon</a></li>
											<li><a href="viewAdAsiaME.php?adz=Malaysia" 
										>Malaysia</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Pakistan" 
										>Pakistan</a></li>
											<li><a href="viewAdAsiaME.php?adz=Philippines" 
										>Philippines</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Qatar" 
										>Qatar</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Singapore" 
										>Singapore</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=Taiwan" 
										>Taiwan</a></li>
											<li><a href="viewAdAsiaME.php?adz=Thailand" 
										>Thailand</a></li>
                                            <li><a href="viewAdAsiaME.php?adz=United Arab Emirates" 
										>United Arab Emirates</a></li>
									
										</ul>
									</div>
								</div>
							</div>
                   
							<!--<br><br><br><br><br><br>
							<img src="images/300x600.jpg" width="230">-->
						</div>