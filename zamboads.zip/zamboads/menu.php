<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li><a href="index.php"><!--<i class="fa fa-user"></i>  -->Home</a></li>
								<li><a href="post_ad.php"><!--<i class="fa fa-star"></i>  -->Post an ad(Free)</a></li>
								<li><a href="contact-us.php"><!--<i class="fa fa-crosshairs"></i> --> Contact Us</a></li>
								<!--<li><a href="cart.html"><i class="fa fa-shopping-cart"></i> Cart</a></li> -->
								<li><a href="login.php"><!--<i class="fa fa-lock"></i> --> Login</a></li>
							</ul>
						</div>
					</div>