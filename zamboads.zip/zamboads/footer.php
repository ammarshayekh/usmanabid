<footer id="footer"><!--Footer-->
		
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Service</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="howdoesitwork.php">How does it work?</a></li>
								
								
								<li><a href="#">FAQ</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Category</h2>
							
                            <ul class="nav nav-pills nav-stacked">
								<li><a href="viewAd.php?adz=12">Jobs</a></li>
								<li><a href="viewAd.php?adz=7">Services</a></li>
								<li><a href="viewAd.php?adz=8">Real Estate</a></li>
								
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Policies</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="term.php">Terms of Use</a></li>
								<li><a href="privacy.php">Privacy Policy</a></li>
								
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>About Zamboads</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="about.php">About</a></li>
								
								<li><a href="#">Copyright</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>About Zamboads</h2>
                            <p>Zamboads.com is a free classified ads website for cars, jobs, real estate, and 			
                            everything else.</p>
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright &copy; 2016 Zamboads,lnc. All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="http://www.swafcofoundation.org">Swafcofoundation</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->