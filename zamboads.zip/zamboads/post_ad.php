<?php
include('dbConnect.inc.php');
$sqlCountry="select id,name from countries  order by name asc ";
$resCountry=mysql_query($sqlCountry);
$checkCountry=mysql_num_rows($resCountry);


?>


<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Post ad | Adzmarket</title>
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <link href="css/prettyPhoto.css" rel="stylesheet">
      <link href="css/price-range.css" rel="stylesheet">
      <link href="css/animate.css" rel="stylesheet">
       
      <link href="css/main.css" rel="stylesheet">
      <link href="css/responsive.css" rel="stylesheet">
      <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->       
      <link rel="shortcut icon" href="images/home/fevicon.png">
      <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
      <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
      <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
      <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
   
   	  <!-- country ajax code start--->	
      
     <script type="text/javascript" src="js/jquery-1.4.1.min.js"></script>
       <script type="text/javascript">
function selectCity(country_id){
	if(country_id!="-1"){
		loadData('state',country_id);
		$("#city_dropdown").html("<option value='-1'>Select city</option>");	
	}else{
		$("#state_dropdown").html("<option value='-1'>Select state</option>");
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function selectState(state_id){
	if(state_id!="-1"){
		loadData('city',state_id);
	}else{
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function loadData(loadType,loadId){
	var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
	$("#"+loadType+"_loader").show();
    $("#"+loadType+"_loader").fadeIn(400).html('Please wait... <img src="image/loading.gif" />');
	$.ajax({
		type: "POST",
		url: "loadData.php",
		data: dataString,
		cache: false,
		success: function(result){
			$("#"+loadType+"_loader").hide();
			$("#"+loadType+"_dropdown").html("<option value='-1'>Select "+loadType+"</option>");  
			$("#"+loadType+"_dropdown").append(result);  
		}
	});
}
</script>


   		<!-- country ajax code start--->
   
   
   </head>
   <!--/head-->
   <body>
      <header id="header">
         <!--header-->
         <?php
            include("topheader.php");
            ?> 
         <div class="header-middle">
            <!--header-middle-->
            <div class="container">
               <div class="row">
                  <div class="col-sm-4">
                     <div class="logo pull-left">
                        <a href="index.php"><img src="images/home/logo.jpg" alt="" /></a>
                     </div>
                     
                  </div>
                  <?php
                     include("menu.php");
                   ?>
               </div>
            </div>
         </div>
         <!--/header-middle-->
         <div class="header-bottom">
            <!--header-bottom-->
            
         </div>
         <!--/header-bottom-->
      </header>
      <!--/header-->
      <section id="slider">
         <!--slider-->
         <div class="container">
            <div class="row">
               <div class="col-sm-12">
                  <div id="slider-carousel" class="carousel slide" data-ride="carousel">
                     
                     <div class="carousel-inner">
                        <div class="item active">
                           <div class="col-sm-4" style="margin-top:90px;">
                              <img src="images/home/post ad 2.png" class="girl img-responsive" alt="" />
                           </div>
                           <div class="col-sm-8" style="margin-left:20px;">
                              <img src="images/home/header1.jpg" class="girl img-responsive" alt="" />
                              <!--	<img src="images/home//Untitled-2.png"  class="pricing" alt="" />  -->
                           </div>
                        </div>
                       
                     </div>
                    
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--/slider-->
      <section>
      <div id="contact-page" class="container" style="margin-top:0px;">
         <div class="bg">
            <div class="row">
               <div class="col-sm-12">
                  <!--<h2 class="title text-center">Contact <strong>Us</strong></h2>    --> 			    				    				
               </div>
            </div>
            <div class="row">
               <div class="col-sm-8">
                  <div class="contact-form">
                     <h2 class="title text-center">Make a Post</h2>
                     <div class="status alert alert-success" style="display: none"></div>
            			
                        <!-- form area --> 
          <form id="main-contact-form" class="contact-form row" name="contact-form" method="post" action="insert_ad.php" 				enctype="multipart/form-data">
                
                <div class="form-group col-md-6">
                    
                    Add Title <input type="text" name="subject" class="form-control" required placeholder="Add title">
                </div>
    
    			 <div class="form-group col-md-6">
                           Select Catagory   
                           
                           
                   <select class="form-control" required="required" name="category">
                              <option value="-1">Select Category</option>
                              <?php
							  
								$q = mysql_query("SELECT * FROM `category`");	
							  	while($data= mysql_fetch_array($q)){
								
							  ?>
                              
                              <option value="<?php echo $data['cat_id']; ?>"><?php echo $data['cat_name']; ?></option>
                             
                             <?php } ?>
                             
                           </select>
                        </div>
    
                <div class="form-group col-md-6" >
                        
                    Select Location   
                    <select onChange="selectCity(this.options[this.selectedIndex].value)" class="form-control" name="country" >
						<option value="-1">Select country</option>
							<?php
								while($rowCountry=mysql_fetch_array($resCountry)){
							?>
						
                        <option value="<?php echo $rowCountry['id']?>"><?php echo $rowCountry['name'	
										]?></option>
						<?php } ?>
					</select>
                            
                    <?php if($checkCountry > 0){ ?>
				
                    <select id="state_dropdown" onChange="selectState(this.options[this.selectedIndex].value)"
                    class="form-control" style="margin-top:10px" name="state">
							
                          <option value="-1">Select state</option>
							</select>
							<span id="state_loader"></span>
					
							<select id="city_dropdown" class="form-control" style="margin-top:10px" name="city">
								<option value="-1">Select city</option>
							</select>
							<span id="city_loader"></span>
						
						<?php }else{
								echo 'No Country Name Found'; }
					     ?>

                            
                            
                        </div>
                     
                        <div class="form-group col-md-12">
                           Ad Description / Text (We strictly delete all spam ads on daily basis, so dont waste your time to promote your website.)
                           <textarea name="message" id="message" required class="form-control" rows="8" placeholder="Your Message Here"></textarea>
                        </div>
                        <div class="form-group col-md-6">
                           Your name  <input type="text" name="subject_name" class="form-control" required placeholder=" Your name">
                        </div>
                        <div class="form-group col-md-6">
                           Your Address  <input type="text" name="address" class="form-control" required placeholder="Your Address  ">
                        </div>
                       
                        <div class="form-group col-md-6">
                           Zip code<input type="text" name="zipCode" class="form-control" required placeholder="Zip code">
                        </div>
                        <div class="form-group col-md-6">
                           Phone / Mobile no <input type="text" name="mobile" class="form-control" required placeholder="Phone Number">
                        </div>
                        <div class="form-group col-md-6">
                           Your Email <input type="text" name="email" class="form-control" required placeholder="Your Email">
                        </div>
                        <div class="form-group col-md-6" >
                           Spam Filter Question * 5+2=<input type="text" name="SFQ" class="form-control"
                           required placeholder="">
                        </div>
                        <div class="form-group col-md-6">
                           Upload Picture <input type="file" name="image_upload">
                        </div>
                        <div class="form-group col-md-12">
                           <INPUT type=checkbox id="agree" value="I am agree the terms and conditions" name="agree"> I agree to 
                           the <A href="http://www.adzmarket.com/terms.php" target=_blank>terms of use</A> 
                           by making a post. 
                        </div>
                        <div class="form-group col-md-12">
                           <input type="submit" name="submit" class="btn btn-primary pull-right" value="Post Now">
                        </div>
                     </form>
                   
               </div>
            </div>
         </div>
      </div>
      <!--/#contact-page-->
      </div>
      </section>
      <?php
         include("footer.php");
      ?>
      <script src="js/jquery.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
      <script type="text/javascript" src="js/gmaps.js"></script>
      <script src="js/contact.js"></script>
      <script src="js/price-range.js"></script>
      <script src="js/jquery.scrollUp.min.js"></script>
      <script src="js/jquery.prettyPhoto.js"></script>
      <script src="js/main.js"></script>
   </body>
</html>