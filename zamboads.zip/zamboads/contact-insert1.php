<?php
//echo $_GET['adz'];
include('dbConnect.inc.php');

$full_name=$_POST["name"];
	 $phone_number=$_POST["phone_number"];
	 $email_address=$_POST["email"];
	  $message=$_POST["message"];
	
	
//echo $full_name;

//$insert=mysql_query("insert into contact(full_name,phone_number,email_address,message) values ('$full_name','$phone_number','$email_address','$message')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=cpanel/personal-1.php\">";

 
 $to = "adzmarketworld@gmail.com";
 
 $subject = "An Inquiry";
 
 $email_from = $_REQUEST['email_address'];
 
 $cust_msg = $_REQUEST['message'];
 
 $headers = "From: $email_from";
 
 $sent = mail($to, $subject, $cust_msg, "From: ".$email_from);

 if($sent)
 
{ //echo " Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly."; 
 }
 
 else
 
 {echo "email is not sent, there is some error!"; }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home |Adzmarket</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/home/fevicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">

<script type="text/javascript" src="js/jquery-1.4.1.min.js"></script>
       <script type="text/javascript">
function selectCity(country_id){
	if(country_id!="-1"){
		loadData('state',country_id);
		$("#city_dropdown").html("<option value='-1'>Select city</option>");	
	}else{
		$("#state_dropdown").html("<option value='-1'>Select state</option>");
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function selectState(state_id){
	if(state_id!="-1"){
		loadData('city',state_id);
	}else{
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function loadData(loadType,loadId){
	var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
	$("#"+loadType+"_loader").show();
    $("#"+loadType+"_loader").fadeIn(400).html('Please wait... <img src="image/loading.gif" />');
	$.ajax({
		type: "POST",
		url: "loadData.php",
		data: dataString,
		cache: false,
		success: function(result){
			$("#"+loadType+"_loader").hide();
			$("#"+loadType+"_dropdown").html("<option value='-1'>Select "+loadType+"</option>");  
			$("#"+loadType+"_dropdown").append(result);  
		}
	});
}
</script>

</head><!--/head-->

<body>
	<header id="header"><!--header-->
		
        <?php
		include("topheader.php");
		?> 
        <!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img src="images/home/logo.jpg" alt="" /></a>
						</div>
						
					</div>
					
                    <?php
					
							include("menu.php");
							 
					?>
                    
				</div>
			</div>
		</div>
	</header><!--/header-->
	
	<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
						</ol> 
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="col-sm-6">
									<h1 style="color:#9e0437">Buy</h1>
									<h2>Free buying listings on adzmarket</h2>
									<p>With unlimited free classified listings now you will search thousands of local and international businesses and brands with just one click. We always make sure to make our website more solid to build more solid relationships of buyer and seller.</p>
									
								</div>
								<div class="col-sm-6">
									<img src="images/home/header1.jpg" class="girl img-responsive" alt="" />
								<img src="images/home//Untitled-2.png"  class="pricing" alt="" /> 
								</div>
							</div>
							<div class="item">
								<div class="col-sm-6">
									<h1 style="color:#9e0437">Sell</h1>
									<h2>Free selling listings on adzmarket</h2>
									<p>With unlimited free business listings Promote your business, Sell your M erchandise. A lot of space for your valueable business.</p>
								
								</div>
								<div class="col-sm-6">
									<img src="images/home/header2.jpg" class="girl img-responsive" alt="" />
								<img src="images/home//Untitled-2.png"  class="pricing" alt="" /> 
								</div>
							</div> 
							
							<div class="item">
								<div class="col-sm-6">
									<h1 style="color:#9e0437">Explore</h1>
									<h2>Exploring the effectiveness of Ads Listings</h2>
									<p>More of who previously bought a product from the advertisier said the "personally identify with" the brand after viewing a free ad listing. Using the power of social media, we are here to promote your valueable business.</p>
									
								</div>
								<div class="col-sm-6">
									<img src="images/home/header3.jpg" class="girl img-responsive" alt="" />
								<img src="images/home/Untitled-2.png" class="pricing" alt="" />
								</div>
							</div>
							
						</div>
						
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a> 
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Quick Search</h2>
						
					<?php include("quicksearch.php"); ?>
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div style="width:500px; height:100px; margin-left:550px; margin-top:300px;">
<p>Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly.</p>
<img src="images/preloader.gif" width="40" height="40" /><br><br><br>
<a href="index.php"><font color="#FF6666" size="+4">You Can Continue Now</font></a>
</div>
					
						<br><br><br><br><br><br><br><br><br><br><br><br>

						<div class="col-sm-6-12">
						<br><br><br><br><br><br><br><br><br><br><br>
						<a href="http://www.onerishta.com" target="_blank"><img src="images/home/onerishta.jpg"  class="girl img-responsive" alt="" /></a>
						<br><br><br><br><br>
						<a href="http://www.bcit.pk" target="_blank"><img src="images/bcit.png"  class="girl img-responsive" alt="" /></a>
							
						</div>
					
				
			</div>
		</div>
	</section>
	
    <?php
		include("footer.php");
	?>
      
   	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
   	<script src="js/main.js"></script>

</body>
</html>