<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Welcome | Adzmarket</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
 <link rel="shortcut icon" href="images/home/fevicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
	<?php
		include("topheader.php");
		?> 
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img src="images/home/logo.jpg" alt="" /></a>
						</div>
					</div>
					  <?php
						include("menu.php");
	 					?>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom" style="padding-top:0px"><!--header-bottom-->
			<div class="container">
				<div class="row">
					
					
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	 
	 <div id="contact-page" class="container" style="margin-top:0px;">
    	<div class="bg">
    		<div class="row">  	
	    		<div class="col-sm-12">
	    			<div class="contact-info">
	    				<h2 class="title text-center" style="color:#fff;background-color:#9fc637;height:65px;font-size:	24px;padding-top:20px">Thank You For Posting Your Ad! </h2>
                        <h3 class="title text-center" >Shortly your add will be viewed , we'll send you email notification  </h3>
                        <hr>
                    
 <div align="center">    <a href="view.php"> <h2 class="title text-center" style="color:#fff;background-color:#09C;width:110px;height:45px;padding-top:13px;text-decoration:none">View Ad</h2>
                       </a>
                       </div><hr>
				<div align="center">    <a href="post_ad.php"> <h4 class="title text-center" style="color:#09C">Submit Another Ad</h4>
                       </a>
                       </div><hr>
                       <div align="center" style="margin-bottom:100px">
                       	<a href="index.php"><h4 class="title text-center" style="color:#C30">Go to Main Page</h4>
                       </a>
                       </div>
	    			</div>
    			</div>    			
	    	</div>  
    	</div>	
    </div><!--/#contact-page-->
	
	<?php
		include("footer.php");
	?>
	
	

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="js/gmaps.js"></script>
	<script src="js/contact.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>