<?php
//require_once 'conn.php';
include('dbConnect.inc.php');
function trimBody($theText, $lmt=500, $s_chr="\n", $s_cnt=2) {
 $pos = 0;
 $trimmed = FALSE;
 for ($i = 1; $i <= $s_cnt; $i++) {
  if ($tmp = strpos($theText,$s_chr,$pos)) {
   $pos = $tmp;
   $trimmed = TRUE;
  } else {
   $pos = strlen($theText) - 1;
   $trimmed = FALSE;
   break;
  }
 }
 $theText = substr($theText,0,$pos);

 if (strlen($theText) > $lmt) {
  $theText = substr($theText,0,$lmt);
  $theText = substr($theText,0,strrpos($theText,' '));
  $trimmed = TRUE;
 }
 if ($trimmed) $theText .= '...';
 return $theText;
}

function outputStory($adz, $only_snippet=FALSE) {
 global $con;

 if ($adz) {
  $sql = "SELECT * FROM adz WHERE ad_id = $adz ORDER BY ad_id DESC";
  $result = mysql_query($sql,$con);
  while($row = mysql_fetch_array($result)){
echo "<div class='features_items'>";
						
	$path = "upload/";					
							
						echo "<div class='col-sm-4'>";
							echo "<div class='product-image-wrapper'>";
						
							if ($row['image'] == $path)
							{
							echo"<a href=view.php?id=".$row['ad_id']."><img src='upload/pic.jpg' width='170'></a> ";
							}
							else
							{
								
                                			echo "<a href=view.php?id=".$row['ad_id']."><img src=" .  $row['image'] . " width='218' height='140'></a> ";
                                			}					
							
						
								
                                
                               echo"<div style='background-color:#666;width:218px' align='center'>";
                               		//echo"<p style='color:#000;font-weight:bold'> Total 8 Pictures </p>"; 
                               echo "</div>";
							
							echo "</div>";
                           echo "</div>";
                        
							echo "<div class='product-image-wrapper' style='margin-left:14px'>";
								echo "<a href=view.php?id=".$row['ad_id']."><strong> ". $row['ad_title'] . "</strong></a><br> ";
						
                      echo "<p style='font-size:10px'>about 3 hours ago</p><br> ";
                      
                      
					  		$city = $row['city_id'];
					  		$e = mysql_query("SELECT * FROM `cities` where id = $city");
							while($row1 = mysql_fetch_array($e)){
					   
                      
                     echo" <p><img src='images/home/location.png' width='20' height='20'> " . $row1['name'] ." </p>";
                      
                       }
						echo "<p style='font-size:14px;height:33px' > " .$row['Ad_description'].  "</p><br>";
                            echo"</div>";
				echo"</div>";
							}

 }
}


function outputStory1($adz, $only_snippet=FALSE) {
 global $con;

 if ($adz) {
  $sql = "SELECT * FROM adz WHERE state_id = $adz ORDER BY ad_id DESC";
  $result = mysql_query($sql,$con);
  while($row = mysql_fetch_array($result)){
echo "<div class='features_items'>";
						
					$path = "upload/";					
							
						echo "<div class='col-sm-4'>";
							echo "<div class='product-image-wrapper'>";
						
							if ($row['image'] == $path)
							{
							echo"<a href=view.php?id=".$row['ad_id']."><img src='upload/pic.jpg' width='170'></a> ";
							}
							else
							{
								
                                			echo "<a href=view.php?id=".$row['ad_id']."><img src=" .  $row['image'] . " width='218' height='140'></a> ";
                                			}
                               echo"<div style='background-color:#666;width:218px' align='center'>";
                               		//echo"<p style='color:#000;font-weight:bold'> Total 8 Pictures </p>"; 
                               echo "</div>";
							
							echo "</div>";
                           echo "</div>";
                        
							echo "<div class='product-image-wrapper' style='margin-left:14px'>";
								echo"<a href=view.php?id=".$row['ad_id']."><strong> ". $row['ad_title'] . "</strong></a><br> ";
						
                      echo "<p style='font-size:10px'>about 3 hours ago</p><br> ";
                      
                      
					  		$city = $row['city_id'];
					  		$e = mysql_query("SELECT * FROM `cities` where id = $city");
							while($row1 = mysql_fetch_array($e)){
					   
                      
                     echo" <p><img src='images/home/location.png' width='20' height='20'> " . $row1['name'] ." </p>";
                      
                       }
						echo "<p style='font-size:14px;height:33px' > " .$row['Ad_description'].  "</p><br>";
                            echo"</div>";
				echo"</div>";
							}

 }
}


function outputStory2($adz, $only_snippet=FALSE) {
 global $con;

 if ($adz) {
  $sql = "SELECT * FROM adz WHERE country_id = $adz ORDER BY ad_id DESC";
  $result = mysql_query($sql,$con);
  while($row = mysql_fetch_array($result)){
echo "<div class='features_items'>";
						
						$path = "upload/";					
							
						echo "<div class='col-sm-4'>";
							echo "<div class='product-image-wrapper'>";
						
							if ($row['image'] == $path)
							{
							echo"<a href=view.php?id=".$row['ad_id']."><img src='upload/pic.jpg' width='170'></a> ";
							}
							else
							{
								
                                			echo "<a href=view.php?id=".$row['ad_id']."><img src=" .  $row['image'] . " width='218' height='140'></a> ";
                                			}
                               echo"<div style='background-color:#666;width:218px' align='center'>";
                               		//echo"<p style='color:#000;font-weight:bold'> Total 8 Pictures </p>"; 
                               echo "</div>";
							
							echo "</div>";
                           echo "</div>";
                        
							echo "<div class='product-image-wrapper' style='margin-left:14px'>";
								echo"<a href=view.php?id=".$row['ad_id']."><strong> ". $row['ad_title'] . "</strong></a><br> ";
						
                      echo "<p style='font-size:10px'>about 3 hours ago</p><br> ";
                      
                      
					  		$city = $row['city_id'];
					  		$e = mysql_query("SELECT * FROM `cities` where id = $city");
							while($row1 = mysql_fetch_array($e)){
					   
                      
                     echo" <p><img src='images/home/location.png' width='20' height='20'> " . $row1['name'] ." </p>";
                      
                       }
						echo "<p style='font-size:14px;height:33px' > " .$row['Ad_description'].  "</p><br>";
                            echo"</div>";
				echo"</div>";
							}

 }
}


function countcat($cat)
  {
  $query = "SELECT * FROM `adz` where cat_id = '$cat' AND status = 1";
  $result=mysql_query($query) or die (mysql_error());
 echo mysql_num_rows($result);
//while ($row = mysql_fetch_array($result)) 

  //{echo "<option>" . $row["name"] . "</optio>";}   
  
}

function countcat1($cat, $cid)
  {
  $query = "SELECT * FROM cadz_adz where title = '$cat' AND is_published = 1 AND location = '$cid' ";
  $result=mysql_query($query) or die (mysql_error());
 echo mysql_num_rows($result);
//while ($row = mysql_fetch_array($result)) 
  //{echo "<option>" . $row["name"] . "</optio>";}   
  
}

function countcity($cat)
  {
  $query = "SELECT * FROM `cadz_adz` where location = '$cat' AND is_published = 1";
  $result=mysql_query($query) or die (mysql_error());
 echo mysql_num_rows($result);
//while ($row = mysql_fetch_array($result)) 
  //{echo "<option>" . $row["name"] . "</optio>";}   
  
}
function getcountry()
  {
  $query = "SELECT * FROM `countries` order by name";
  $result=mysql_query($query) or die (mysql_error());

while ($row = mysql_fetch_array($result)) 
  {echo "<option>" . $row["name"] . "</optio>";}   
  
}
?>