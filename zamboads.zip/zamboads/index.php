<?php
//echo $_GET['adz'];
include('dbConnect.inc.php');
include("outputfunctions.php");

$sqlCountry="select id,name from countries  order by name asc ";
$resCountry=mysql_query($sqlCountry);
$checkCountry=mysql_num_rows($resCountry);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | Zamboads</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/home/fevicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">

<script type="text/javascript" src="js/jquery-1.4.1.min.js"></script>
       <script type="text/javascript">
function selectCity(country_id){
	if(country_id!="-1"){
		loadData('state',country_id);
		$("#city_dropdown").html("<option value='-1'>Select city</option>");	
	}else{
		$("#state_dropdown").html("<option value='-1'>Select state</option>");
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function selectState(state_id){
	if(state_id!="-1"){
		loadData('city',state_id);
	}else{
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function loadData(loadType,loadId){
	var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
	$("#"+loadType+"_loader").show();
    $("#"+loadType+"_loader").fadeIn(400).html('Please wait... <img src="image/loading.gif" />');
	$.ajax({
		type: "POST",
		url: "loadData.php",
		data: dataString,
		cache: false,
		success: function(result){
			$("#"+loadType+"_loader").hide();
			$("#"+loadType+"_dropdown").html("<option value='-1'>Select "+loadType+"</option>");  
			$("#"+loadType+"_dropdown").append(result);  
		}
	});
}
</script>

</head><!--/head-->

<body>
	<header id="header"><!--header-->
		
        <?php
		include("topheader.php");
		?> 
        <!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img src="images/home/logo.jpg" alt="" /></a>
						</div>
						
					</div>
					
                    <?php
					
							include("menu.php");
							 
					?>
                    
				</div>
			</div>
		</div><!--/header-middle-->
	<div class="header-bottom">
            <!--header-bottom-->
            <div class="container">
				<form action="search.php" method="post">
					<div class="col-sm-2" style="margin-left:50px;">
                 
                        <div class="search_box pull-right">
							<select onChange="selectCity(this.options[this.selectedIndex].value)"  name="country"  style="height:60px;width:200px;">
						<option value="-1">Select country</option>
							<?php
								while($rowCountry=mysql_fetch_array($resCountry)){
							?>
						
                        <option value="<?php echo $rowCountry['id']?>"><?php echo $rowCountry['name'	
										]?></option>
						<?php } ?>
						
					</select>
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                 
                        <div class="search_box pull-right">
							 <?php if($checkCountry > 0){ ?>
				
                    <select id="state_dropdown" onChange="selectState(this.options[this.selectedIndex].value)"
                    style="height:60px;width:200px;" name="state">
							
                          <option value="-1">Select state</option>
							</select>
							<span id="state_loader"></span>
					
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                 
                        <div class="search_box pull-right">
							<select id="city_dropdown"  style="height:60px;width:200px;" name="city">
								<option value="-1">Select city</option>
							</select>
							<span id="city_loader"></span>
						
						<?php }else{
								echo 'No Country Name Found'; }
					     ?>

					
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                    
						<div class="search_box pull-right">
							<select  name="category" style="height:60px;width:200px;">
						 <option value="-1">Select Category</option>
                              <?php
							  
								$q = mysql_query("SELECT * FROM `category`");	
							  	while($data= mysql_fetch_array($q)){
								
							  ?>
                              
                              <option value="<?php echo $data['cat_id']; ?>"><?php echo $data['cat_name']; ?></option>
                             
                             <?php } ?>
						
					</select>
						</div>
                        
					</div>
					<div class="col-sm-2">
                    <div class="search_box pull-right">
							<input type="text" style="height:60px; width:180px;" name="title">
						</div>
						
                        
					
				
			</div>
            </form>
		</div>
         </div>
		<!--/header-bottom-->
	</header><!--/header-->
	
	<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
						</ol> 
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="col-sm-6">
									<h1 style="color:#9e0437">Buy</h1>
									<h2>Free buying listings on Zamboads</h2>
									<p>With unlimited free classified listings now you will search thousands of local and international businesses and brands with just one click. We always make sure to make our website more solid to build more solid relationships of buyer and seller.</p>
									
								</div>
								<div class="col-sm-6">
									<img src="images/home/header1.jpg" class="girl img-responsive" alt="" />
								<img src="images/home//Untitled-2.png"  class="pricing" alt="" /> 
								</div>
							</div>
							<div class="item">
								<div class="col-sm-6">
									<h1 style="color:#9e0437">Sell</h1>
									<h2>Free selling listings on Zamboads</h2>
									<p>With unlimited free business listings Promote your business, Sell your M erchandise. A lot of space for your valueable business.</p>
								
								</div>
								<div class="col-sm-6">
									<img src="images/home/header2.jpg" class="girl img-responsive" alt="" />
								<img src="images/home//Untitled-2.png"  class="pricing" alt="" /> 
								</div>
							</div> 
							
							<div class="item">
								<div class="col-sm-6">
									<h1 style="color:#9e0437">Explore</h1>
									<h2>Exploring the effectiveness of Ads Listings</h2>
									<p>More of who previously bought a product from the advertisier said the "personally identify with" the brand after viewing a free ad listing. Using the power of social media, we are here to promote your valueable business.</p>
									
								</div>
								<div class="col-sm-6">
									<img src="images/home/header3.jpg" class="girl img-responsive" alt="" />
								<img src="images/home/Untitled-2.png" class="pricing" alt="" />
								</div>
							</div>
							
						</div>
						
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a> 
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Quick Search</h2>
						
					<?php include("quicksearch.php"); ?>
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Featured Categories</h2>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
										<a href="viewAd.php?adz=1">	<img src="images/home/electronic.png" alt=""  />
											
											<h2>Electronics(<?php countcat("1"); ?>)</h2> </a>
											<!--<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a> -->
										</div>
										
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=2" 
										><img src="images/home/AUTOMOTIVE.jpg" alt="" />
										<h2>Automotive(<?php countcat("2"); ?>)</h2></a>
										
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=3"><img src="images/home/BUSINESS.jpg" alt="" />
										<h2>Business(<?php countcat("3"); ?>)</h2></a>
										
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=4"><img src="images/home/home n living.png" alt="" />
										<h2>Home & Living(<?php countcat("4"); ?>)</h2></a>
										
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=5"><img src="images/home/E-BOOKS.jpg" alt="" />
										<h2>E-Books(<?php countcat("5"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=6"><img src="images/home/garments.png" alt="" />
										<h2>Garments(<?php countcat("6"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=7"><img src="images/home/SERVICES.jpg" alt="" />
										<h2>Services(<?php countcat("7"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=8"><img src="images/home/REAL- ESTATE.jpg" alt="" />
										<h2>Real Estate(<?php countcat("8"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=13"><img src="images/home/toys.png" alt="" />
										<h2>Toys(<?php countcat("13"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=14"><img src="images/home/sports.png" alt="" />
										<h2>Sports(<?php countcat("14"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=12"><img src="images/home/JOBS.jpg" alt="" />
										<h2>Jobs(<?php countcat("12"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=9"><img src="images/home/PETS.jpg" alt="" />
										<h2>Pets(<?php countcat("9"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=15"><img src="images/home/foods.png" alt="" />
										<h2>Food & Beverages(<?php countcat("15"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=10"><img src="images/home/mobilesandcomputers.png" alt="" />
										<h2>Mobiles & Computers(<?php countcat("10"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=11"><img src="images/home/health n beauty.png" alt="" />
										<h2>Health & Beauty(<?php countcat("11"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>
						
						
					<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="viewAd.php?adz=16"><img src="images/home/others.png" alt="" />
										<h2>Others(<?php countcat("16"); ?>)</h2></a>
									
									</div>
									
								</div>
								
							</div>
						</div>	
						
					</div><!--features_items-->
					
						<br><br><br><br>

					<!---	<div class="col-sm-6-12">
						
						<a href="http://www.onerishta.com" target="_blank"><img src="images/home/onerishta.jpg"  class="girl img-responsive" alt="" /></a>
							
						</div> --->
					
				
			</div>
		</div>
	</section>
	
    <?php
		include("footer.php");
	?>
      
   	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
   	<script src="js/main.js"></script>

</body>
</html>