<?php
include('dbConnect.inc.php');

$loadType=$_POST['loadType'];
$loadId=$_POST['loadId'];

if($loadType=="state"){
	$sql="select id, name from states where country_id='".$loadId."' order by name asc";
}else{
	$sql="select id,name from cities where state_id='".$loadId."' order by name asc";
}
$res=mysql_query($sql);
$check=mysql_num_rows($res);
if($check > 0){
	$HTML="";
	while($row=mysql_fetch_array($res)){
		$HTML.="<option value='".$row['id']."'>".$row['1']."</option>";
	}
	echo $HTML;
}
?>