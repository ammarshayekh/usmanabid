<?php
//echo $_GET['adz'];
include('dbConnect.inc.php');
include("outputfunctions.php");
//include('ps_pagination.php');
$sqlCountry="select id,name from countries  order by name asc ";
$resCountry=mysql_query($sqlCountry);
$checkCountry=mysql_num_rows($resCountry);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Contact-us | privacy</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
 <link rel="shortcut icon" href="images/home/fevicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	
	<script type="text/javascript" src="js/jquery-1.4.1.min.js"></script>
       <script type="text/javascript">
function selectCity(country_id){
	if(country_id!="-1"){
		loadData('state',country_id);
		$("#city_dropdown").html("<option value='-1'>Select city</option>");	
	}else{
		$("#state_dropdown").html("<option value='-1'>Select state</option>");
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function selectState(state_id){
	if(state_id!="-1"){
		loadData('city',state_id);
	}else{
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function loadData(loadType,loadId){
	var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
	$("#"+loadType+"_loader").show();
    $("#"+loadType+"_loader").fadeIn(400).html('Please wait... <img src="image/loading.gif" />');
	$.ajax({
		type: "POST",
		url: "loadData.php",
		data: dataString,
		cache: false,
		success: function(result){
			$("#"+loadType+"_loader").hide();
			$("#"+loadType+"_dropdown").html("<option value='-1'>Select "+loadType+"</option>");  
			$("#"+loadType+"_dropdown").append(result);  
		}
	});
}
</script>
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<?php
		include("topheader.php");
		?> 
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img src="images/home/logo.jpg" alt="" /></a>
						</div>
						
					</div>
					  <?php
						include("menu.php");
	 					?>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<form action="search.php" method="post">
					<div class="col-sm-2" style="margin-left:50px;">
                 
                        <div class="search_box pull-right">
							<select onChange="selectCity(this.options[this.selectedIndex].value)"  name="country"  style="height:60px;width:200px;">
						<option value="-1">Select country</option>
							<?php
								while($rowCountry=mysql_fetch_array($resCountry)){
							?>
						
                        <option value="<?php echo $rowCountry['id']?>"><?php echo $rowCountry['name'	
										]?></option>
						<?php } ?>
						
					</select>
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                 
                        <div class="search_box pull-right">
							 <?php if($checkCountry > 0){ ?>
				
                    <select id="state_dropdown" onChange="selectState(this.options[this.selectedIndex].value)"
                    style="height:60px;width:200px;" name="state">
							
                          <option value="-1">Select state</option>
							</select>
							<span id="state_loader"></span>
					
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                 
                        <div class="search_box pull-right">
							<select id="city_dropdown"  style="height:60px;width:200px;" name="city">
								<option value="-1">Select city</option>
							</select>
							<span id="city_loader"></span>
						
						<?php }else{
								echo 'No Country Name Found'; }
					     ?>

					
						</div>
					</div>
                    <div class="col-sm-2" style="margin-left:20px;">
                    
						<div class="search_box pull-right">
							<select  name="category" style="height:60px;width:200px;">
						 <option value="-1">Select Category</option>
                              <?php
							  
								$q = mysql_query("SELECT * FROM `category`");	
							  	while($data= mysql_fetch_array($q)){
								
							  ?>
                              
                              <option value="<?php echo $data['cat_id']; ?>"><?php echo $data['cat_name']; ?></option>
                             
                             <?php } ?>
						
					</select>
						</div>
                        
					</div>
					<div class="col-sm-2">
                    <div class="search_box pull-right">
							<input type="text" style="height:60px; width:180px;" name="title">
						</div>
						
                        
					
				
			</div>
            </form>
		</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	 
	 <div id="contact-page" class="container" style="margin-top:0px;">
    	<div class="bg">
	    	
    		<div class="row">  	
	    		
	    		<div class="col-sm-12">
	    			<div class="contact-info">
	    				<h2 class="title text-center">Pakistan Free classifieds</h2>
	    				<address>
	    					<p style="text-align:justify;">
						<STRONG> PRIVACY POLICY</STRONG><BR><br>Your privacy is 
      important to us, so zamboads.com has created this Privacy Policy to explain 
      how your information is protected, collected and used. This Privacy Policy 
      applies to all zamboads.com web sites, including our publicly accessible web 
      sites located at zamboads.com ("zamboads.com"). This Privacy Policy may be 
      updated from time to time. You can always review the most current version 
      at <A 
      href="http://www.zamboads.com/privacy.php">http://www.zamboads.com/privacy.php</A>. 
      By using zamboads.com, you consent to the terms and conditions of this 
      Privacy Policy and are aware that our policies may evolve in the future. 
      If there is a conflict between our Terms of Use governing your use of the 
      Sites and this Privacy Policy, the Terms of Use control. 
      <BR><BR><STRONG>Collection.</STRONG> Information posted on zamboads.com is 
      obviously publicly available. Our servers are located in the United States 
      and in the European Union. Therefore, if you choose to provide us with 
      personal information, you are consenting to the transfer and storage of 
      that information on our servers in the United States and Europe. We 
      collect and store the following personal information: <BR>
      <UL>

        <LI>email address, physical contact information, and (depending on the 
        service used) sometimes financial information; <BR>
        <LI>computer sign-on data, statistics on page views, traffic to and from 
        zamboads.com and ad data (all through cookies - you can take steps to 
        disable the cookies on your browser although this is likely to affect 
        your ability to use the site); <BR>
        <LI>other information, including users IP address and standard web log 
        information. </LI></UL><BR><BR><STRONG>Use.</STRONG> We use users' 
      personal information to: <BR>
      <UL>
        <LI>provide our services<BR>

        <LI>resolve disputes, collect fees, and troubleshoot problems;<BR>
        <LI>encourage safe trading and enforce our policies; <BR>
        <LI>customize users' experience, measure interest in our services, and 
        inform users about services and updates; <BR>
        <LI>communicate marketing and promotional offers to you; <BR>
        <LI>do other things for users as described when we collect the 
        information. </LI></UL><BR><BR><STRONG>Disclosure.</STRONG> We don't sell 
      or rent users' personal information to third parties for their marketing 
      purposes without users explicit consent. We may disclose personal 
      information to respond to legal requirements, enforce our policies, 
      respond to claims that a posting or other content violates other's rights, 
      or protect anyone's rights, property, or safety. We may also share 
      personal information with: <BR><BR>

      <UL>
        <LI>corporate affiliates who help detect and prevent potentially illegal 
        acts and provide joint services. (Our corporate affiliates will market 
        only to users who ask them to). <BR>
        <LI>service providers who help with our business operations. 
      <BR></LI></UL><BR><STRONG>Using Information from zamboads.com.</STRONG> You 
      may use personal information gathered from adzmarket.com only to follow up 
      with another user about a specific posting, not to send spam or collect 
      personal information from someone who hasn't agreed to that. 
      <BR><BR><BR><STRONG>Access, Modification, and Deletion.</STRONG> You can 
      see, modify or erase your personal information by reviewing your posting 
      or account status page. Contact customer support ( support@zamboads.com ) to 
      review any personal information we store that is not available on 
      zamboads.com. There may a charge associated with such requests but these 
      will not exceed the amounts permitted by law. We delete personal 
      information when we no longer need it for the purposes we described 
      earlier. We retain personal information as permitted by law to resolve 
      disputes, enforce our policies; and prevent bad guys from coming back. 
      <BR><BR><STRONG>Security.</STRONG> We use lots of tools (encryption, 
      passwords, physical security) to protect your personal information against 
      unauthorized access and disclosure, but as you probably know, nothing's 
      perfect, so we make no guarantees. <BR><BR><STRONG>General.</STRONG> We 
      may update this policy at any time, with updates taking effect when you 
      next post or after 30 days, whichever is sooner. If we or our corporate 
      affiliates are involved in a merger or acquisition, we may share personal 
      information with another company, but this policy will continue to apply. 
      Send questions about this policy to privacy@zamboads.com. 

							</p>
	    				</address>
	    				<!--<div class="social-networks">
	    					<h2 class="title text-center">Social Networking</h2>
							<ul>
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-google-plus"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-youtube"></i></a>
								</li>
							</ul>
	    				</div> -->
	    			</div>
    			</div>    			
	    	</div>  
    	</div>	
    </div><!--/#contact-page-->
	
	<?php
		include("footer.php");
	?>
	

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="js/gmaps.js"></script>
	<script src="js/contact.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>