<?php
//echo $_GET['adz'];
include('dbConnect.inc.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>view | Zamboads</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
     <link rel="shortcut icon" href="images/home/fevicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	<style>




.v-center {
  height: 200px;
  width: 100%;
  display: table;
  position: relative;
  
}

.v-center > div {
  display: table-cell;
 
  position: relative;

}






.modal-box {
  display: none;
  position: absolute;
  z-index: 1000;
  width: 98%;
  background: white;
  
  border-bottom: 1px solid #aaa;
  border-radius: 4px;
  box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
  border: 1px solid rgba(0, 0, 0, 0.1);
  background-clip: padding-box;
}
@media (min-width: 32em) {

.modal-box { width: 100%;
margin-top:120px;
 }
}

.modal-box header,
.modal-box .modal-header {
  padding: 1.25em 1.5em;
  border-bottom: 1px solid #ddd;
}

.modal-box header h3,
.modal-box header h4,
.modal-box .modal-header h3,
.modal-box .modal-header h4 { margin: 0; }

.modal-box .modal-body { padding: 2em 1.5em; }

.modal-box footer,
.modal-box .modal-footer {
  padding: 1em;
  border-top: 1px solid #ddd;
  background: rgba(0, 0, 0, 0.02);
  text-align: right;
}

.modal-overlay {
  opacity: 0;
  filter: alpha(opacity=0);
  position: absolute;
  top: 0;
  left: 0;
  z-index: 900;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.3) !important;
}

a.close {
  line-height: 1;
  font-size: 1.5em;
  position: absolute;
  top: 5%;
  right: 2%;
  text-decoration: none;
  color: #bbb;
}

a.close:hover {
  color: #222;
  -webkit-transition: color 1s ease;
  -moz-transition: color 1s ease;
  transition: color 1s ease;
}
</style>
   
</head><!--/head-->

<body>
	
	<header id="header"><!--header-->
		<?php
		include("topheader.php");
		?> 
			
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left" >
							<a href="index.php"><img src="images/home/logo.jpg" alt="" /></a>
						</div>
						<!--<div class="btn-group pull-right">
							<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									USA
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu">
									<li><a href="#">Canada</a></li>
									<li><a href="#">UK</a></li>
								</ul>
							</div>
							
							<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									DOLLAR
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu">
									<li><a href="#">Canadian Dollar</a></li>
									<li><a href="#">Pound</a></li>
								</ul>
							</div>
						</div> -->
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li><a href="index.php"><!--<i class="fa fa-user"></i>  -->Home</a></li>
								<li><a href="post_ad.php"><!--<i class="fa fa-star"></i>  -->Post an ad(Free)</a></li>
								<li><a href="checkout.html"><!--<i class="fa fa-crosshairs"></i> --> Help</a></li>
								<!--<li><a href="cart.html"><i class="fa fa-shopping-cart"></i> Cart</a></li> -->
								<li><a href="login.php"><!--<i class="fa fa-lock"></i> --> Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					
					<div class="col-sm-12">
						<div class="search_box pull-right">
							<input type="text" placeholder="Search"/>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	 <section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="col-sm-3" >
                                
                                <?php
									$q = mysql_query("SELECT * FROM adz WHERE ad_id = '$_GET[id]'");
									while($r = mysql_fetch_array($q)){
								 ?>
                                 
                                	<?php  $cityy= $r['city_id']?>
                                    <?php if ($r['image'] == "upload/"){
							         $image = "upload/pic.jpg"; 
							
									echo"<a href='#'><img src=" .  $image . " width='500' class='girl img-responsive' alt='' /></a> ";
									}
									else
									{
										echo"<a href='#'><img src=" .  $r['image'] . " width='500' class='girl img-responsive' alt=''/></a> ";
										}
									?>
									<br>
									
                                    <div style="background-color:#9fc637;height:40px;padding-left:5px;padding-top:2px;margin-bottom:10px"><p ><strong ><h4 style="color:#FFF"><?php echo $r['user_name'] ?></h4></strong></p></div>
                                    <div style="background-color:#c4c4c4;height:40px;padding-left:5px;padding-top:2px;margin-bottom:2px" ><p style="color:#000"><strong><h4><?php echo $r['mobile_number'] ?></h4></strong> </p></div>
                                   <section class="v-center"><div>
<a  href="#" data-modal-id="popup1"><div  style="background-color:#c4c4c4;height:40px;padding-left:5px;padding-top:2px;" >
 <strong><h4 style="color:#000;"><?php echo $r['address'] ?></h4></strong></div></a>
</div>
</section>

<div id="popup1" class="modal-box" style="width:500px;height:800px; background-image:url(images/home/500x500.jpg); background-repeat:no-repeat">
  <header> <a href="#" class="js-modal-close close"><strong style="font-size:13;color:#F03;">X</strong></a>
    <h3>Address Here </h3>
  </header>
  <div class="modal-body" >
    <p><?php echo $r['address'] ?></p>
  </div>
  
</div>
</div>

								<div class="col-sm-8">
								
									<h3 style="margin-top:0px;color:#9e0437"><?php echo $r['ad_title'] ?></h3>
                                   
				       <b style="font-size:10px">Date Published:</b>
 						<p style="font-size:10px"><?php echo $r['date_submitted'] ?></p>
					     	
                            
                           <?php 
						   
					  		$e = mysql_query("SELECT * FROM cities where id=$cityy");
							while($row1 = mysql_fetch_array($e)){
								?>
                     
  <b> Location:</b> <?php echo $row1['name'] ?>
  <?php }?>
  
  <b style="font-size:10px;float:right">Viewed: 40 </b>
						 
						 <hr>
						  <b> Description:</b>  <?php echo $r['Ad_description'] ?>
<?php }?>
							<!--	<img src="images/home//Untitled-2.png"  class="pricing" alt="" />  -->
								</div>
								
							</div>
                            
						<!--   carousel-inner end -->
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	
	
	<?php
		include("footer.php");
	?>
	

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="js/gmaps.js"></script>
	<script src="js/contact.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="popup/aa.js"></script> 
<script>
$(function(){

var appendthis =  ("<div class='modal-overlay js-modal-close'></div>");

	$('a[data-modal-id]').click(function(e) {
		e.preventDefault();
    $("body").append(appendthis);
    $(".modal-overlay").fadeTo(500, 0.7);
    //$(".js-modalbox").fadeIn(500);
		var modalBox = $(this).attr('data-modal-id');
		$('#'+modalBox).fadeIn($(this).data());
	});  
  
  
$(".js-modal-close, .modal-overlay").click(function() {
    $(".modal-box, .modal-overlay").fadeOut(500, function() {
        $(".modal-overlay").remove();
    });
 
});
 
$(window).resize(function() {
    $(".modal-box").css({
        top: ($(window).height() - $(".modal-box").outerHeight()) / 2,
        left: ($(window).width() - $(".modal-box").outerWidth()) / 2
    });
});
 
$(window).resize();
 
});
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
   	
  
</body>
</html>