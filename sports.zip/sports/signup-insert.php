<?php include('config.php'); ?>

<?php
$name = $_REQUEST['fullname'];
$uname=$_REQUEST['username'];
$emailaddress=$_REQUEST['emailaddress'];
$password=$_REQUEST['password'];
$cpassword=$_REQUEST['cpassword'];
$university=$_REQUEST['university'];
$captcha=$_REQUEST['captcha'];
$code="koeqf";
$q=mysql_query("select * from tb_user where user_name='$uname' or email_address='$emailaddress'",$con);
$u_name_ac='abc';
$u_email_ac='abc';
while($q_data=mysql_fetch_array($q))
{
	$u_name_ac=$q_data['user_name'];
	$u_email_ac=$q_data['email_address'];
}
//echo $u_name_ac;
//echo $u_email_ac;
/*
echo $name."<br>";
echo $uname."<br>";
echo $emailaddress."<br>";
echo "Passowrd:".$password."<br>";
echo "Confirm Password:".$cpassword."<br>";
echo"University". $university."<br>";
echo $captcha."<br>";
*/
$date=date('d-m-Y');

if($u_email_ac == $emailaddress)
{
	echo "Email address is already exist. Please try another email address";
	exit();
}

if($password != $cpassword)
	{
	echo "Password is incorrect<br>";	
	exit();
	}
if($captcha != $code)
{
	echo "Captcha is incorrect<br>";
	exit();
}
if($u_name_ac == $uname)
{
	echo "User name is already exist. Please try another user name";
	exit();
}


	//echo "your both password is correct<br>";	
	
	$insert=mysql_query("insert into tb_user(full_name,user_name,email_address,password,university_name,dates,session_id)values('$name','$uname','$emailaddress','$password','$university','$date','$ses_id')",$con);
	//echo "Data is insert";
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cpanel.php\">";
	

	
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=mydetail.php\">";
?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html