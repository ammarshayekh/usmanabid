<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
GAME RULES
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">

 
 
 
 
 
 <div class="comments_schedule_cricket">
 <div class="schedule_programs_comments" >
<img src="images/images (1).jpg" width="300" height="225" style="margin:5px;"/><br />
 <b>Football Rules</b> <br />1. You can score from every part of field but not from your D.<br /> 2. Team should be consist of five players including one keeper.<br /> 3. Keeper can carry ball within D.<br /> 4. Fouls (pushing ,wrong tackle) etc.<br /> 5. Foul within D will be considered as penalty.<br /> 6. Handball(free kick).<br /> 7. Throw, corner, fouls.<br /> 8. Total duration 30 min(One half of fifteen minute).<br /> 9. If the game result is not decided within two half than there will be penalty shot out.<br /> 10. Five penalties for each side.<br /> 11. Red card, yellow card.<br /> 12. Only gripers allowed.<br /> 13. University card is mandatory otherwise player will not be allowed to play.<br /> 14. In case of using abusive/slang language, player will not be allowed to play.<br /> 15. Only one player of other department can play (one substitution is allowed).<br />
 16.Shirts for Engineering department will be (Blue), Social Sciences (White) and for Management will be (black). 


 </div>
 
 <div class="clear"></div>
 </div>
 
 
 
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>
</body>
</html>
