<?php
//session_start();
//$ses_id=session_id();
    if (!isset($_SESSION)) {
    session_start();
    }
	$ses_id = session_id();
$hostname = "localhost";
$username = "root";
$password = "";
$database_name = "sports";
$con = mysql_connect($hostname,$username,$password) or die("Could Not Make Connection with the [$hostname],[$username],[$password]");
if($con == true)
{
	mysql_select_db($database_name,$con) or die("Could Not Select the Database Name with the [$database_name],[$con]");
}
//=======================================================================================
$q=mysql_query("select * from tb_user where session_id='$ses_id'",$con);
$u_name="";
$u_pass="";
$session_id="abc";
while($q_data=mysql_fetch_array($q))
{
	$u_name=$q_data['user_name'];
	$u_id=$q_data['userid'];
	$u_pass=$q_data['password'];
	$session_id=$q_data['session_id'];
}

?>