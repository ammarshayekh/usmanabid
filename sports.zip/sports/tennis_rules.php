<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
GAME RULES
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">

 
 
 
 
 
 <div class="comments_schedule_cricket">
 <div class="schedule_programs_comments" >
<img src="images/download (6).jpg" width="300" height="225" style="margin:5px;"/><br />
<b>Tennis Rules</b><br />
 1.The right to choose the initial order of serving, receiving and ends shall be decided by lot and the winner may choose to serve or to receive first or to start at a particular end.<br />
2.A game shall be won by the player or pair first scoring 11 points unless either players or pairs score 10 points, when the game shall be won by the first player or pair subsequently gaining a lead of 2 points.<br />
3.A match shall consist of the best of any odd number of games.<br />
4.When one player or pair has chosen to serve or to receive first or to start at a particular end, the other player or pair shall have the other choice.<br />
5.After each 2 points have been scored the receiving player or pair shall become the serving player or pair and so on until the end of the game.
In singles, the server shall first make a service, the receiver shall then make a return and thereafter server and receiver alternately shall each make a return.<br />
6.In doubles, the server shall first make a service, the receiver shall then make a return, the partner of the server shall then make a return, the partner of the receiver shall then make a return and thereafter each player in turn in that sequence shall make a return.<br />
The ball shall be regarded as passing over or around the net assembly if it passes anywhere other than between the net and the net post or between the net and the playing surface.<br />
7.The ball, having been served or returned, shall be struck so that it passes over or around the net assembly and touches the opponent's court, either directly or after touching the net assembly.<br />
8.If the players have not changed ends when they should have done so, play shall be interrupted by the umpire as soon as the error is discovered and shall resume with the players at the ends at which they should be at the score that has been reached.<br />
<b>A player shall score a point,</b><br />
1.If an opponent fails to make a correct service.<br />
2.If an opponent fails to make a correct return.<br />
3.If, after he or she has made a service or a return, the ball touches anything other than the net assembly before being struck by an opponent.<br />
4.If the ball passes over his or her court or beyond his or her end line without touching his or her court, after being struck by an opponent.<br />
5.If an opponent deliberately strikes the ball twice in succession.<br />
6.His or her opponent touches the table with either hand before striking the ball.<br />
7.Shirts for Engineering department will be (Blue), Social Sciences (White) and for Management will be (black). 

 </div>
 
 <div class="clear"></div>
 </div>
 
 
 
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>
</body>
</html>
