<?php include('config.php'); ?>
<?php
$team_name=$_REQUEST['team_name'];
$program=$_REQUEST['program'];
$action=$_REQUEST['action'];
$bd_id=$_REQUEST['bid'];
$tournament='Badmintion';
$batch=$_REQUEST['batch'];
$contactnumber=$_REQUEST['contactnumber'];
$player1=$_REQUEST['player1'];
$reg1=$_REQUEST['reg1'];
$player2=$_REQUEST['player2'];
$reg2=$_REQUEST['reg2'];
//$player3=$_REQUEST['player3'];
//$reg3=$_REQUEST['reg3'];
//$player4=$_REQUEST['player4'];
//$reg4=$_REQUEST['reg4'];


/*echo "Program=" .$program."<br>";
echo "Batch=" .$batch."<br>";
echo "Contact Number=" .$contactnumber."<br>";
echo "Player One=".$player1."<br>";
echo "Regiseration No1=".$reg1."<br>";
echo "Player Two=".$player2."<br>";
echo "Regiseration No2=".$reg2."<br>";
echo "Player Three=".$player3."<br>";
echo "Regiseration No3=".$reg3."<br>";
echo "Player Four=".$player4."<br>";
echo "Regiseration No4=".$reg4."<br>";
$q=mysql_query("select * from badmintion",$con);where player1='$player1' and reg_no1='$reg1' player2='$player2' and reg_no2='$reg2' player3='$player3' and reg_no3='$reg3' player4='$player4' and reg_no4='$reg4'";
while($q_data=mysql_fetch_array($q))
{
	$pro=$q_data['program'];
	$bat=$q_data['batch'];
	$contnmbr=$q_data['cnumber'];
	$p1=$q_data['player1'];
	$r1=$q_data['reg_no1'];
	$p2=$q_data['player2'];
	$r2=$q_data['reg_no2'];
	$p3=$q_data['player3'];
	$r3=$q_data['reg_no3'];
	$p4=$q_data['player4'];
	$r4=$q_data['reg_no4'];
	echo "pro".$pro."<br>";
	echo "bat".$bat."<br>";
	echo "cnumbr".$contnmbr."<br>";
	echo "Player1".$p1."<br>";
	echo "reg1".$r1."<br>";
	echo "Player2".$p2."<br>";
	echo "reg2".$r2."<br>";
    echo "Player3".$p3."<br>";
	echo "reg3".$r3."<br>";
     echo "Player4".$p4."<br>";
	echo "reg4".$r4."<br>";

}
*/
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into badmintion (userid,team_name,tournament,program,batch,cnumber,player1,reg_no1,player2,reg_no2,dates,session_id) values ('$u_id','$team_name','$tournament','$program','$batch','$contactnumber','$player1','$reg1','$player2','$reg2','$date','$ses_id')",$con);
$q=mysql_query("select * from badmintion where session_id='$ses_id'",$con);
while($q_data=mysql_fetch_array($q))
{
	$bd_id=$q_data['bid'];
}
$update=mysql_query("update badmintion set where session_id='$ses_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=report/rpt_badmintion.php?id=$bd_id\">";

}
if($action == 'edit')
{
	$update=mysql_query("update badmintion set team_name='$team_name', program='$program', batch='$batch',cnumber='$contactnumber',player1='$player1',reg_no1='$reg1',player2='$player2',reg_no2='$reg2' where bid='$bd_id'" ,$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_badmintion.php\">";
}



?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html>