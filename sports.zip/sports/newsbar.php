<div class="newsbar">
<div style="width:115px; height:25px; float:left; color:#FF0000; padding-left:5px; font-weight:bold;  ">Important Note:</div>

<div style="width:875px; height:20px; float:left;">
<marquee direction="left"scrolldelay="1" scrollamount="2" onMouseOver="this.stop();this.style.cursor='default';" onMouseOut="this.start();this.style.cursor='default';">
Physical & mental fitness is essential for every person. Continuous studies without any pause make the students relentless so to lessen the stress FURC Sports Society offer you an opportunity to show your sports skills and freshen yourself for the upcoming semester. I, being the President of Sports Society introduce you for the first time online registration system. Now you can easily register yourself without rushing behind the management. With much effort this online registration system is set up for your ease. I now wish to see you all actively participating in the sports field. Good luck!  President of Sports Society

</marquee>
</div>


     </div>
     