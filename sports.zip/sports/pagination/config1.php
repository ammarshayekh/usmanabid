<?php

$hostname = "localhost";

$username = "furcspor_cricket";

$password = "usmanabid469gbtsd";

$database_name = "furcspor_cricket";

$con = mysql_connect($hostname,$username,$password) or die("Could Not Make Connection with the [$hostname],[$username],[$password]");

if($con == true)

{

	mysql_select_db($database_name,$con) or die("Could Not Select the Database Name with the [$database_name],[$con]");

}

?>