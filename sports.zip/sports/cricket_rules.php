<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
GAME RULES
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">

 
 
 
 
 
 <div class="comments_schedule_cricket">
 <div class="schedule_programs_comments" >
<img src="images/cricket.jpg" width="300" height="225" style="margin:5px;"/>
 <br /><b>RULES FOR CRICKET FALL 2014 </b><br />1. Umpires decision will be final decision.<br /> 2. No abuse/slang language should be granted in tournament/league. Ay player(including captains) found of using abuse/slang language would be warned only for once, on doing it twice, he will be sent out of the field and he will have a penalty of 1 match ban (min).<br /> 3. No player can raise finger on any of the society member, on doing so charge would be imposed on that player depending upon the circumstances.<br /> 4. Umpires are nominated by the Sports Society (with mutual concern). No team has right to change ground umpires one allocated.<br /> 5. University card is mandatory for all the players. Players without university card will not be able to play.<br /> 6. Maximum 10 minutes time relaxation would be granted to teams. On 10th min, captain would be called again and on 11th minute, the late team would be disqualified.<br /> 7. No chance of re-match or re-entry.<br /> 8. Match timings can be adjusted according to the time mention in registration form. It cannot be changed once allocated.<br /> 9. Students only and only from Foundation University Rawalpindi Campus FURC can take part in this tournament/league. Any player found outsider, that team will be disqualified. Captain of that disqualified team would be unable to captain the team in his presence in FURC and the case will be referred to FURC Sports discipline committee.<br /> 10. Any player who disobeys the rules will be penalized immediately and captain of the team will also be penalized.<br /> 11. In case of any emergency concern the management. <br />12. All cricket rules should be applicable.<br /> 13. Over limit 3,2,2,1. Full toss above waist height is considered as no ball<br /> 14. Overstepping will be considered as free hit <br />15. One over power play will be taken by bowling side any time. <br />16. Shirts for Engineering department will be (Blue), Social Sciences (White) and for Management will be (black).


 </div>
 
 <div class="clear"></div>
 </div>
 
 
 
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>
</body>
</html>
