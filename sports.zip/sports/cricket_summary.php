<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
SCHEDULE
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="main_bar">
 <div class="time">
 Matchid
 </div>
 <div class="time">
 Date
 </div>
 <div class="schedule_programs">
  PROGRAMMES
 </div>
 <!-----------
 <div class="announcement">
WEDNESDAY  07TH MAY 2014 to FRIDAY 09TH MAY 2014
 </div>
 --------------------->
 <div class="clear"></div>
 
 
 <div class="match_schedule_cricket_main">
 
 <div class="Schedule_cricket">
 Cricket
 </div>

 <?php
  
	 $q=mysql_query("select * from live_score group by matchid",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $team_name=$q_data['team_name'];
		 $match_with=$q_data['match_with'];
		 $dates=$q_data['dates'];
		 $matchid=$q_data['matchid'];
		
		
		 
	 
	 
	 ?>
	 
	 
	 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php //echo $matchid; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $dates; ?>
 </div>
 <div class="schedule_programs_cricket1" style="width:580px;">
<?php echo $team_name; ?> Vs <?php echo $match_with; ?>
 </div>
 
  <div class="time_cricket">
<a style="color:#333;" href="matches_summary.php?mid=<?php echo $matchid; ?>">Detail</a>
 </div>
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>
</body>
</html>
