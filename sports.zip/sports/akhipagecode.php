<?php include('config.php'); 
include("ip.php");
include('user-agent.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>

<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script> -->

</head>
<body>
<?php if($session != $ses_id){ ?>
<?php include('header.php'); 

?>

<!--UserBar !-->
<!--End UserBar !-->
<table align="center" cellpadding="0" cellspacing="0" class="c-table">
<tr><td align="center" class="c-td">
	
	<table cellpadding="0" cellspacing="0" class="ci-top-table">
	<tr>
	<td align="left" style="vertical-align:middle;padding-left:10px;">Login </td>
	<td align="right" style="vertical-align:middle;padding-right:10px;">
	<div style="float:right;">
	<a href="register.php" class="button-mini">CREATE AN ACCOUNT</a>
	</div>
	<div style="float:right;font:11px/24px Verdana,sans-serif;color:#fff;padding-right:8px;"></div>
	</td>
	</tr>
	</table>
 <?php
if(isset($_POST['submit']))
 {
$user = $_POST['username'];
$pwd = $_POST['password'];	 

$len_user=strlen($user);
$len_pwd=strlen($pwd);

//echo $user. '<br>';
//echo $pwd;

$error=0;

if($len_user > 15 || $len_pwd > 15 )
{
$error = 1;
$error_txt = 'Invalid Username or Password';	
}

if($error == 0)
{
$date= date('d-m-Y');
$q = mysql_query("select * from tb_users where username = '$user'",$con);
$user_status='';
$Username='';
$Password='';
	while($data = mysql_fetch_array($q))
		{
		$Password = $data['password'];
		$Username = $data['username'];
		$user_status = $data['user_status'];
		}	
if($user_status == 'suspend')
{
$error = 1;
$error_txt = 'Your account is suspended.';	
}

if(($user != $Username) || ($pwd != $Password))
{
$error = 1;
$error_txt = 'Invalid Username or Password.';	
}
if(($user == $Username) && ($pwd == $Password) && ($user_status != 'suspend') )
{

$update=mysql_query("update tb_users set SessionID= '$ses_id', lastiplog = '$ip' where username = '$user' and password = '$pwd'",$con);
	
$error = 2;
}

}

if($error == 1)
{
?>
<div class="error_box" style=" text-align:justify; margin-top:5px; margin-bottom:5px;">
<?php echo $error_txt; ?>
</div>
<?php	
}

if($error == 2)
{
?>
<div class="success_box" style=" text-align:justify; margin-top:5px; margin-bottom:5px;">
<!-- Login Success. Please wait<img src="images/wait.gif" />-->
<img src="images/chat_loading.gif" />
</div>
<?php

echo "<meta http-equiv=\"refresh\" content=\"0;URL=account.php\">";
}

	 
 }
 ?>   



	<table cellpadding="0" cellspacing="0" class="ci-bottom-table">
	<tr><td align="center" class="ci-inside-td">
     <?php		
	
		?>
        
		<form  action="login.php" method="post">
		<table align="center" cellpadding="0" cellspacing="10" class="ci-box">
        <tr>
        <td style="font-weight:bold; border-bottom:1px solid #ccc;">Login</td>
        </tr>
        <tr>
        <td align="center"><img src="images/user-login.jpg" /></td>
        </tr>
        
				<tr>
                <td >Username</td>
                </tr>
                <tr>
			
            <td align="left" style="padding:0px 10px; "><input type="text" value="" id="username" name="username" maxlength="15" style="width:260px;" required="required" placeholder="Your username" ></td>
		</tr>
		
		<tr>
        <td >Password</td>
        </tr>
		<tr>
        <td align="left" style="padding:0px 10px;"><input type="password" value="" id="password" name="password" style="width:260px;" placeholder="Your password" required="required" ></td>
        </tr>
       <!-- 
		<tr>
        <td align="left" style="padding:0px 10px;"><div style="float:left; margin-top:20px;"><img src="CaptchaSecurityImages.php?width=120&height=25&characters=6" /></div><div style="float:left; margin-top:20px;"><input type="text" value=""  name="security_code" style="width:135px;" placeholder="Enter Captcha" required="required" ></div> <div style="clear:both;"></div></td>
        </tr>

	 -->
        
      
		
        		<tr>
			<td style="padding-left:10px; padding-top:20px;" >
			<input type="submit" name="submit" value="LOGIN" style="width:270px;" class="button-submit" >
			</td>
		</tr>
		<tr>
			<td align="right" style="padding:10px 10px 5px;" >
			<p style="width:280px;"><a href="forgot-password.php" class="link" style="color:#f04949;">Forgot password?</a></p>
			</td>
		</tr>
       
		</table>
		</form>
		 
 		</td></tr>
	</table>

</td></tr>
</table>
	<?php include('footer.php'); ?>

<?php
}
else
{
echo "<meta http-equiv=\"refresh\" content=\"0;URL=logout.php\">";	
}
?>
</body>
</html>
