<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sports :: Foundation University Rawalpindi Campus </title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/css-menu.css"/> 
<link rel="stylesheet" type="text/css" href="Services/js-image-slider.css" />
<script src="Services/js-image-slider.js" type="text/javascript"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55444735-1', 'auto');
  ga('send', 'pageview');

</script>