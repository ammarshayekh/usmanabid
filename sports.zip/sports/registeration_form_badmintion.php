<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
BADMINTION REGISTRATION FORM  
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="main_bar">
 <div class="society_members_name">
  Please Fill All The Feilds Below For Badmintion Team Registration
 </div>
 <div class="registeration_form_select">
<span style="color:rgb(255,0,0);">Note:</span>Click for <a  style="color: #F00;"href="registeration_fee.php">Registration Fee</a> and sumbit in askari bank Foundation University Rawalpindi Campus 
</div>
 <form action="registeration_form_insert_badmintion.php" method="post">
 <input type="hidden" name="action" value="add" />
 <input type="hidden" name="bid" value="0" />
 <div class="form1">
 
 <div style="width:700px; height:30px;  margin-bottom:10px; margin-left:100px; margin-top:25px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;">Team Name:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="team_name" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="team name" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:10px; margin-left:100px; margin-top:25px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;">Program:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="program" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="program" required="required" />
</div>
<div class="clear"></div>
 </div>

 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px; margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Batch:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="batch" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="batch name" required="required" />
</div>
<div class="clear"></div>
 </div>
<div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Captain’s Contact Number:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="contactnumber" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="cell number" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Player 1:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="player1" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="player name" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:2px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Form/Registration #:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="reg1" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="registeration no" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Player 2:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="player2" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="player name"  />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:2px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Form/Registration #:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="reg2" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="registeration no"  />
</div>
<div class="clear"></div>
 </div>
 <!-------------------
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Player 3:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="player3" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="player name"  />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:2px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Registeration #:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="reg3" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="registeration no"/>
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Player 4:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="player4" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="player name"  />
</div>
<div class="clear"></div>
 </div>
 
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:2px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Registeration #:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="reg4" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="registeration no" />
</div>
<div class="clear"></div>
 </div>
 ---------------------->
<div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px; margin-bottom:25px;">
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:320px;"> <input type="submit" value="Register" style="width:100px; height:25px;"  /></div>
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:15px;"> <input type="button" name="button" value="cancel" onclick="location.href='cpanel.php'" style="width:100px; height:25px;"  /></div>
<div class="clear"></div>
 </div>
 
 </div>
 
 </form>
<div class="clear"></div>
 </div>
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>



<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="images/invalid.jpg" />
</div>	
<?php
}
?>




</body>
</html>
