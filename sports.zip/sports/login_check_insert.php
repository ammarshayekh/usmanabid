<?php include('config.php'); ?>
<?php

$uu=$_REQUEST['username'];
$pp=$_REQUEST['password'];
$ll=mysql_query("select * from tb_user where user_name='$uu' and password='$pp'",$con);
$oo="";
$ii="";
if($ll === FALSE) {
    die(mysql_error()); // TODO: better error handling
}
while($hh_data=mysql_fetch_array($ll))
{
	$oo=$hh_data['user_name'];
	$ii=$hh_data['password'];
	
}
if(($uu == $oo) && ($pp == $ii))
{
	//echo "user name passwor is correct";
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cpanel.php\">";
}
else
{
	//echo "user name and password is incorrect";
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
}
$update=mysql_query("update tb_user set session_id='$ses_id' where user_name='$uu' and password = '$pp'",$con);





?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html