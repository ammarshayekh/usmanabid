<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ACCOUNT  
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
   <?php  include('sidebar.php'); ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
     Cricket Registeration Data
     </div>
     <div id="dasbord_inner4" style="text-align:right;">
  
     </div>
     </div>
	  
	  <div id="dasbord_main">
     <div id="dasbord_inner">
     <div id="dasbord_inner8">
     RegID
     </div>
     <div id="dasbord_inner1">
     PROGRAM
     </div>
     <div id="dasbord_inner1">
     BATACH
     </div>
     <div id="dasbord_inner1">
     CONTACT#
     </div>
     <div id="dasbord_inner1">
     DATE
     </div>
     <div id="dasbord_inner1">
     PROOF
     </div>
     <div id="dasbord_inner9">
     ACTION
     </div>
     </div>
     <?php  
	 $q=mysql_query("select * from cricket where status='1' and userid='$u_id' ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $u_id=$q_data['userid'];
		 $c_id=$q_data['crid'];
		 $program=$q_data['program'];
		 $bat=$q_data['batch'];
		 $cnmbr=$q_data['cnumber'];
		 $dat=$q_data['dates'];
		 $proof=$q_data['proof'];
	 
	 ?>
     
     <div id="dasbord_inner3">  
     <div id="dasbord_inner7">
 
     
    <?php echo $c_id; ?>
     
     </div>
     
     <div id="dasbord_inner2">
     <?php       echo $program;   ?>
     </div>
     <div id="dasbord_inner2">
     <?php         echo $bat;   ?>
     </div>
     <div id="dasbord_inner2">
     <?php           echo $cnmbr;   ?>
     </div>
     <div id="dasbord_inner2">
     <?php          echo $dat;   ?>
     </div>
     
     <div id="dasbord_inner2">
     <?php
	 if($proof == '')
	 {
	 ?>
  <a href="cp_upload.php?update_id=<?php echo $c_id; ?>&amp;form_value=cricket" style="color:rgb(0,0,0); text-decoration:none;" >  UPLOAD FEE</a>
  <?php } 
  if($proof!='')
	{
	echo "Uploaded";
	}
  ?>
  
     </div>
     
     <div id="dasbord_inner7">
     <a style="color:#000000; text-decoration:none;" target="_blank" href="report/rpt_cricket.php?id=<?php echo $c_id; ?>">  View</a>
     </div>
     <div id="dasbord_inner7">
     <a style="color:#000000; text-decoration:none;"  href="registeration_form_cricket_edit.php?crid=<?php echo $c_id; ?>"><img src="images/edit.png" width="16" height="16" alt="Edit" title="Edit Record" /></a>
     </div>
     </div>
     
     <?php } ?>
     
     
     </div>
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>
<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="images/invalid.jpg" />
</div>	
<?php
}
?>







</body>
</html>
