<?php include('config.php'); ?>
<?php
$reg=$_REQUEST['regno'];
$action=$_REQUEST['action'];
$furc_id=$_REQUEST['furcid'];
$tournament='Cricket';
$program=$_REQUEST['program'];
$batch=$_REQUEST['batch'];
$name=$_REQUEST['name'];
$contactnumber=$_REQUEST['contactnumber'];
/*

echo "Program=" .$program."<br>";
echo "Batch=" .$batch."<br>";
echo "Contact Number=" .$contactnumber."<br>";
echo "Player1=".$player1."<br>";
echo "Regiseration No1=".$reg1."<br>";
*/


$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into furc_society (userid,tournament,regno,program,batch,name,cnumber,dates,session_id) values ('$u_id','$tournament','$reg','$program','$batch','$name','$contactnumber','$date','$ses_id')",$con);
$q=mysql_query("select * from furc_society where session_id='$ses_id'",$con);
while($q_data=mysql_fetch_array($q))
{
	$furc_id=$q_data['furcid'];
}
$update=mysql_query("update furc_society set session_id='0' where session_id='$ses_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=report/rpt_furcsociety.php?id=$furc_id\">";

}
if($action == 'edit')
{
	$update=mysql_query("update furc_society set program='$program', batch='$batch',cnumber='$contactnumber',name='$name',regno='$reg' where furcid='$furc_id'" ,$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_society.php\">";

}

?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html>