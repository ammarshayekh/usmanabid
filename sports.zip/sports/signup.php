<?php  include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>

<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
NEW ACCOUNT CREATION  
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="main_bar">
 <div class="society_members_name">
  Please Fill All The Feilds Below For Account Creation
 </div>
 <form action="signup-insert.php" method="post">
 
 <div class="form1">
 
 
 <div style="width:700px; height:30px;  margin-bottom:10px; margin-left:100px; margin-top:25px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;"> Full Name:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="fullname" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="full name" required="required" />
</div>
<div class="clear"></div>
 </div>

 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px; margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> User Name:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="username" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="user name" required="required" />
</div>
<div class="clear"></div>
 </div>
<div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> E-Mail Adrress:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="emailaddress" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="email address" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Password:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="password" name="password" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="password" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Confirm Password:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="password" name="cpassword" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="confirm password" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> University Name:</div>
<div style="width:300px; height:27px; float:left; padding-left:20px; text-align:left;">
<select name="university" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px; padding-top:3px;" >


<?php


$q=mysql_query("select * from participants ",$con);
while($q_data=mysql_fetch_array($q))
{
	$uni=$q_data['uni_name'];	
	//$id=$_REQUEST['unid'];


?>
<option value="<?php echo $uni; ?>"><?php echo $uni; ?></option>

<?php } ?>

</select>
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Captcha:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<img src="images/captcha.php.png" width="140" height="30" /><br /><span style="width:100px; font-size:9px; margin-bottom:5px;"> captcha enter small letter like koeqf</span>

</div>

<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Enter Captcha Code Here:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="captcha" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="enter captcha code here in small letter" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px; margin-bottom:25px;">
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:320px;"> <input type="submit" value="Sign in" style="width:100px; height:25px;"  /></div>
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:15px;"> <input type="button" name="button" value="cancel" onclick="location.href='index.php'" style="width:100px; height:25px;"  /></div>
<div class="clear"></div>
 </div>
 
 </div>
 
 </form>
<div class="clear"></div>
 </div>
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>








</body>
</html>
