<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ADMIN PANEL  
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
    <?php        include('sidebar.php');     ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
    User Feedback
     </div>
     
     </div>
	  
	  <div id="dasbord_main">
     <div id="dasbord_inner">
     <div id="dasbord_inner18">
     User Feedback Detail
     </div>
     
     </div>
     <div class="clear"></div>
     <?php
	 $fid=$_REQUEST['feeid'];
	 $q=mysql_query("select * from feedback where feeid='$fid'",$con);
	 while($q_data=mysql_fetch_array($q))
	 { 
	 
		 $name=$q_data['name'];
		 $email=$q_data['email_address'];
		 $subject=$q_data['subject'];
		 $message=$q_data['message'];
		 $date=$q_data['dates'];
	 }
	 ?>
     <div id="dasbord_inner17">  
     <div id="dasbord_inner16">
     Name
     </div>     
     <div id="dasbord_inner15">
     <?php echo $name; ?>
     </div>
<div class="clear"></div> 
     
     </div>
         
     <div id="dasbord_inner17">  
     <div id="dasbord_inner16">
     Email
     </div>     
     <div id="dasbord_inner15">
     <?php echo $email;?>
     </div>
     <div class="clear"></div>
     </div>
     <div id="dasbord_inner17">  
     <div id="dasbord_inner16">
     Subject
     </div>     
     <div id="dasbord_inner15">
     <?php echo $subject; ?>
     </div>
     <div class="clear"></div>
     </div>
     <div id="dasbord_inner17">  
     <div id="dasbord_inner16">
     Message
     </div>     
     <div id="dasbord_inner15">
    <?php echo $message; ?>
     </div>
     <div class="clear"></div>
     </div>
   <div id="dasbord_inner17">  
     <div id="dasbord_inner16">
     Date
     </div>     
     <div id="dasbord_inner15">
     <?php echo $date; ?>
     </div>
     <div class="clear"></div>
     </div>
     <div id="dasbord_inner17" style="height:35px;">  
     <div id="dasbord_inner21" style="margin-left:490px; margin-right:3px;">
   <a style="color:#000000; text-decoration:none;" href="status_update.php?feeid=<?php echo $fid; ?>">   Approve</a>
     </div>     
     
     <div id="dasbord_inner21" style="margin-right:3px;">
     <a style="color:#000000; text-decoration:none;"  href="feedback_delete.php?id=<?php echo $fid; ?>">  Cancel</a>
     </div>
     <div id="dasbord_inner21">
     <a style=" color:#000000; text-decoration:none;" href="ad_feedback.php">  Back</a>
     </div>
     <div class="clear"></div>
     </div>
     </div>
      
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>


<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>	
<?php
}
?>





</body>
</html>
