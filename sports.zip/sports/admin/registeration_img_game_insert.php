<?php     include('config.php');        ?>
<?php

$name=$_REQUEST['name'];
$action=$_REQUEST['action'];
$regid=$_REQUEST['regid'];
//=======================================
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$Target = $target_path;
move_uploaded_file($_FILES['image_upload']['tmp_name'], $target_path);
//=========================================
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into registeration_cata (game_name,proof,dates) values ('$name','$Target','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=registeration_img_game_show.php\">";
}
if($action == 'edit')
{
	$update=mysql_query("update registeration_cata set game_name='$name', proof='$Target' where regid='$regid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=registeration_img_game_show.php\">";
}



?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html