<?php include('config.php'); ?>
<?php
$team_name=$_REQUEST['team_name'];
$program=$_REQUEST['program'];
$action=$_REQUEST['action'];
$volly_id=$_REQUEST['vbid'];
$tournament='Vollyball';
$batch=$_REQUEST['batch'];
$contactnumber=$_REQUEST['contactnumber'];
$player1=$_REQUEST['player1'];
$reg1=$_REQUEST['reg1'];
$player2=$_REQUEST['player2'];
$reg2=$_REQUEST['reg2'];
$player3=$_REQUEST['player3'];
$reg3=$_REQUEST['reg3'];
$player4=$_REQUEST['player4'];
$reg4=$_REQUEST['reg4'];
$player5=$_REQUEST['player5'];
$reg5=$_REQUEST['reg5'];
$player6=$_REQUEST['player6'];
$reg6=$_REQUEST['reg6'];
$player7=$_REQUEST['player7'];
$reg7=$_REQUEST['reg7'];
$player8=$_REQUEST['player8'];
$reg8=$_REQUEST['reg8'];
$player9=$_REQUEST['player9'];
$reg9=$_REQUEST['reg9'];

/*echo "Program=" .$program."<br>";
echo "Batch=" .$batch."<br>";
echo "Contact Number=" .$contactnumber."<br>";
echo "Player1=".$player1."<br>";
echo "Regiseration No1=".$reg1."<br>";
echo "Player2=".$player2."<br>";
echo "Regiseration No2=".$reg2."<br>";
echo "Player3=".$player3."<br>";
echo "Regiseration No3=".$reg3."<br>";
echo "Player4=".$player4."<br>";
echo "Regiseration No4=".$reg4."<br>";
echo "Player5=".$player5."<br>";
echo "Regiseration No5=".$reg5."<br>";
echo "Player6=".$player6."<br>";
echo "Regiseration No6=".$reg6."<br>";
echo "Player7=".$player7."<br>";
echo "Regiseration No7=".$reg7."<br>";
echo "Player8=".$player8."<br>";
echo "Regiseration No8=".$reg8."<br>";
echo "Player9=".$player9."<br>";
echo "Regiseration No9=".$reg9."<br>";*/

$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into vollyball (userid,team_name,tournament,program,batch,cnumber,player1,reg_no1,player2,reg_no2,player3,reg_no3,player4,reg_no4,player5,reg_no5,player6,reg_no6,player7,reg_no7,player8,reg_no8,player9,reg_no9,dates,session_id) values ('$u_id','$team_name','$tournament','$program','$batch','$contactnumber','$player1','$reg1','$player2','$reg2','$player3','$reg3','$player4','$reg4','$player5','$reg5','$player6','$reg6','$player7','$reg7','$player8','$reg8','$player9','$reg9','$date','$ses_id')",$con);

$q=mysql_query("select * from vollyball where session_id='$ses_id'",$con);
while($q_data=mysql_fetch_array($q))
{
	$volly_id=$q_data['vbid'];
}
$update=mysql_query("update vollyball set where session_id='$ses_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=report/rpt_vollyball.php?id=$volly_id\">";
}
if($action == 'edit')
{
	$update=mysql_query("update vollyball set team_name='$team_name', program='$program', batch='$batch',cnumber='$contactnumber',player1='$player1',reg_no1='$reg1',player2='$player2',reg_no2='$reg2',player3='$player3',reg_no3='$reg3',player4='$reg4',player5='$player5',reg_no5='$reg5',player6='$player6',reg_no6='$reg6',player7='$player7',reg_no7='$reg7',player8='$player8',reg_no8='$reg8' where vbid='$volly_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_vollyball.php\">";
}
?>



<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html>