<?php include('config.php'); ?>
<?php
$uni_name=$_REQUEST['uni_name'];
$action=$_REQUEST['action'];
$partiid=$_REQUEST['grid'];
$announcement=$_REQUEST['announcement']; 
$serial_no=$_REQUEST['serial_no'];

$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into tb_group (s_no,team_name,group_name,dates) values ('$serial_no','$uni_name', '$announcement','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=group_result.php\">";
}

if($action == 'edit')
{
	$update=mysql_query("update tb_group set s_no='$serial_no', team_name='$uni_name', group_name='$announcement' where grid='$partiid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=group_result.php\">";
}



?>
<?php
/*$uni_name=$_REQUEST['uni_name'];
$action1=$_REQUEST['action'];
$partiid=$_REQUEST['grid'];
$announcement=$_REQUEST['announcement']; 
$serial_no=$_REQUEST['serial_no'];

$date=date('d-m-Y');
if($action1 == 'add')
{
$insert=mysql_query("insert into football_group (s_nofb,team_name_fb,group_fb,dates) values ('$serial_no','$uni_name','$announcement','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=group_result.php\">";
}


if($action_cr == 'edit')
{
	$update=mysql_query("update football_group set s_nofb='$s_nofb',team_name_fb='$team_name_fb',group_fb='$group_fb' where fbid='$fbid'",$con);
	//echo "<meta http-equiv=\"refresh\" content=\"0;URL=group_result.php\">";
}

*/
?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html