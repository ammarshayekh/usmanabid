<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ADMIN PANEL
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
   <?php  include('sidebar.php'); ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
    Furc Society Members data
     </div>
     <div id="dasbord_inner4"  style="text-align:right;">
  <a href="cp_upload.php">  <img src="img/add_12.gif" width="12" height="12" title="add new member" style="margin-right:5px;"/></a>
     </div>
     </div>
	  
	  <div id="dasbord_main">
     <div id="dasbord_inner">
     <div id="dasbord_inner8">
     FURCID
     </div>
     <div id="dasbord_inner_img">
     NAME
     </div>
     <div id="dasbord_inner1_imgview">
     IMAGES
     </div>
     
     
     <div id="dasbord_inner1">
     DATE
     </div>
     <div id="dasbord_inner9">
     ACTION
     </div>
     </div>
     <?php  
	 
	 $q=mysql_query("select * from upload_img ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $imgid=$q_data['imgid'];
		 $name=$q_data['name'];
		 $proof=$q_data['proof'];
		  $dat=$q_data['dates'];
	 
	 ?>
     
     <div id="dasbord_inner3">  
     <div id="dasbord_inner7">
     <?php  echo $imgid; ?>
     </div>
     <div id="dasbord_inner_name">
    <?php        echo $name;         ?>
     </div>
     <div id="dasbord_inner2_view_img">
    <?php
	 if($proof == 'proof/')
	 {
		 
	 ?>
      None
     <?php } 
  if($proof!='proof/')
	{
	?>
    <a href="save_show_img.php?img=<?php echo $proof; ?>" style="color:rgb(0,0,0); text-decoration:none;" >  View img</a>
    <?php
	}
	
  ?>
     </div>
     
     <div id="dasbord_inner2">
     <?php     echo $dat;   ?>
        </div>
     
     <div id="dasbord_inner7">
     <a style="color:#000000; text-decoration:none;" href="cp_upload_edit.php?imgid=<?php echo $imgid; ?>"><img src="img/edit.png" width="16" height="16" title="edit" alt="edit" /></a>
     </div>
     <!---------------------
     <div id="dasbord_inner7">
     <a style="color:#000000; text-decoration:none;" href="">  <img src="img/delete.png" width="16" height="16" title="cancel" /></a>
     </div>
     -------------------------->
     </div>
     
     <?php } ?>
     
     
     </div>
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>

<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>	
<?php
}
?>






</body>
</html>
