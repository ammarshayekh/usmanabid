<?php include('config.php');?>
<?php

$program=$_REQUEST['program'];
$action=$_REQUEST['action'];
$c_id=$_REQUEST['crid'];
$team_name=$_REQUEST['team_name'];
$tournament='Cricket';
$batch=$_REQUEST['batch'];
$contactnumber=$_REQUEST['contactnumber'];
$player1=$_REQUEST['player1'];
$reg1=$_REQUEST['reg1'];
$player2=$_REQUEST['player2'];
$reg2=$_REQUEST['reg2'];
$player3=$_REQUEST['player3'];
$reg3=$_REQUEST['reg3'];
$player4=$_REQUEST['player4'];
$reg4=$_REQUEST['reg4'];
$player5=$_REQUEST['player5'];
$reg5=$_REQUEST['reg5'];
$player6=$_REQUEST['player6'];
$reg6=$_REQUEST['reg6'];
$player7=$_REQUEST['player7'];
$reg7=$_REQUEST['reg7'];
$player8=$_REQUEST['player8'];
$reg8=$_REQUEST['reg8'];
$player9=$_REQUEST['player9'];
$reg9=$_REQUEST['reg9'];
$player10=$_REQUEST['player10'];
$reg10=$_REQUEST['reg10'];
$player11=$_REQUEST['player11'];
$reg11=$_REQUEST['reg11'];
$player12=$_REQUEST['player12'];
$reg12=$_REQUEST['reg12'];
$player13=$_REQUEST['player13'];
$reg13=$_REQUEST['reg13'];
$player14=$_REQUEST['player14'];
$reg14=$_REQUEST['reg14'];


/*echo "Program=" .$program."<br>";
echo "Batch=" .$batch."<br>";
echo "Contact Number=" .$contactnumber."<br>";
echo "Player One=".$player1."<br>";
echo "Regiseration No1=".$reg1."<br>";
echo "Player Two=".$player2."<br>";
echo "Regiseration No2=".$reg2."<br>";
echo "Player Three=".$player3."<br>";
echo "Regiseration No3=".$reg3."<br>";
echo "Player Four=".$player4."<br>";
echo "Regiseration No4=".$reg4."<br>";
echo "Player Five=".$player5."<br>";
echo "Regiseration No5=".$reg5."<br>";
echo "Player Six=".$player6."<br>";
echo "Regiseration No6=".$reg6."<br>";
echo "Player Seven=".$player7."<br>";
echo "Regiseration No7=".$reg7."<br>";
echo "Player Eight=".$player8."<br>";
echo "Regiseration No8=".$reg8."<br>";
echo "Player Nine=".$player9."<br>";
echo "Regiseration No9=".$reg9."<br>";
echo "Player Ten=".$player10."<br>";
echo "Regiseration No10=".$reg10."<br>";
echo "Player Eleven=".$player11."<br>";
echo "Regiseration No11=".$reg11."<br>";
echo "Player Tewelve=".$player12."<br>";
echo "Regiseration No12=".$reg12."<br>";
echo "Player Thirteen=".$player13."<br>";
echo "Regiseration No13=".$reg13."<br>";
echo "Player Fourteen=".$player14."<br>";
echo "Regiseration No14=".$reg14."<br>";
*/

$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into cricket (userid,team_name,tournament,program,batch,cnumber,player1,reg_no1,player2,reg_no2,player3,reg_no3,player4,reg_no4,player5,reg_no5,player6,reg_no6,player7,reg_no7,player8,reg_no8,player9,reg_no9,player10,reg_no10,player11,reg_no11,player12,reg_no12,player13,reg_no13,player14,reg_no14,dates,session_id) values ('$u_id','$team_name','$tournament','$program','$batch','$contactnumber','$player1','$reg1','$player2','$reg2','$player3','$reg3','$player4','$reg4','$player5','$reg5','$player6','$reg6','$player7','$reg7','$player8','$reg8','$player9','$reg9','$player10','$reg10','$player11','$reg11','$player12','$reg12','$player13','$reg13','$player14','$reg14','$date','$ses_id')",$con);

$q=mysql_query("select * from cricket where session_id='$ses_id'",$con);
while($q_data=mysql_fetch_array($q))
{
	$cr_id=$q_data['crid'];
}

$update=mysql_query("update cricket set session_id='0' where session_id='$ses_id'",$con);

echo "<meta http-equiv=\"refresh\" content=\"0;URL=report/rpt_cricket.php?id=$cr_id\">";
}
if($action == 'edit')
{
	$update=mysql_query("update cricket set team_name='$team_name', program='$program', batch='$batch',cnumber='$contactnumber',player1='$player1',reg_no1='$reg1',player2='$player2',reg_no2='$reg2',player3='$player3',reg_no3='$reg3',player4='$player4',reg_no4='$reg4',player5='$player5',reg_no5='$reg5',player6='$player6',reg_no6='$reg6',player7='$player7',reg_no7='$reg7',player8='$player8',reg_no8='$reg8',player9='$player9',reg_no9='$reg9',player10='$player10',reg_no10='$reg10',player11='$player11',reg_no11='$reg11',player12='$player12',reg_no12='$reg12',player13='$player13',reg_no13='$reg13',player14='$player14',reg_no14='$reg14' where crid='$c_id'" ,$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_cricket.php\">";
}
?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html>