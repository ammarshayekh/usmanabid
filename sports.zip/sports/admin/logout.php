<?php  include('config.php'); ?>
<?php

$uupdate=mysql_query("update tb_admin set session_id='0' where session_id='$ses_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html