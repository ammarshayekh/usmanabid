<?php include('config.php'); ?>
<?php
$uni_name=$_REQUEST['uni_name'];
$action=$_REQUEST['action'];
$partiid=$_REQUEST['partiid'];
$announcement=$_REQUEST['announcement']; 
$serial_no=$_REQUEST['serial_no'];

$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into participants (s_no,uni_name,announcement,dates) values ('$serial_no','$uni_name', '$announcement','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=participants_result.php\">";
}

if($action == 'edit')
{
	$update=mysql_query("update participants set s_no='$serial_no', uni_name='$uni_name', announcement='$announcement' where partiid='$partiid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=participants_result.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html