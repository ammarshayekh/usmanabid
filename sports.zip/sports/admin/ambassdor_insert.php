<?php include('config.php'); ?>
<?php
$uni_name=$_REQUEST['uni_name'];
$action=$_REQUEST['action'];
$ambid=$_REQUEST['ambid'];
$name=$_REQUEST['name']; 
$cnumber=$_REQUEST['cnumber'];
$serial_no=$_REQUEST['serial_no'];

$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into ambassdor (s_no,name,uni_name,cnumber,dates) values ('$serial_no','$name', '$uni_name','$cnumber','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=ambassdor_result.php\">";
}

if($action == 'edit')
{
	$update=mysql_query("update ambassdor set s_no='$serial_no', name='$name', uni_name='$uni_name',cnumber='$cnumber' where ambid='$ambid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=ambassdor_result.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html