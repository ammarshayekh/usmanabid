<?php include('config.php'); ?>
<?php
$team_name=$_REQUEST['team_name'];
$mid=$_REQUEST['mid'];
//$action=$_REQUEST['action'];
$live_id=$_REQUEST['live_id'];
$player_name=$_REQUEST['player_name']; 
$run=$_REQUEST['run'];
$midden=$_REQUEST['midden'];
$balls=$_REQUEST['ball'];
$four=$_REQUEST['four'];
$six=$_REQUEST['six'];
////////////////////////////////////////////////////////////////////////////////////////////////////
$b_name=$_REQUEST['out_by'];
$b_run=$_REQUEST['b_run'];
$m_midden=$_REQUEST['midden_over'];
$wicket=$_REQUEST['wicket'];
$extra_run=$_REQUEST['extra'];
$runout=$_REQUEST['runout'];
$comment=$_REQUEST['p_comment'];

if($wicket == '0')
{
$insert=mysql_query("insert into live_score_detail (liveid,team_name,player_name,run,midden,ball,fours,sixs,p_out) values ('$live_id','$team_name','$player_name','$run','$midden','$balls','$four','$six','$comment')",$con);
}

if($wicket == '1')
{
$insert=mysql_query("insert into live_score_detail (liveid,team_name,player_name,outs,run,midden,ball,fours,sixs,p_out) values ('$live_id','$team_name','$player_name','$b_name','$run','$midden','$balls','$four','$six','$comment')",$con);

}



$insert1=mysql_query("insert into live_score_bowling (liveid,bowler_name,ball,midden,runs,wicket,run_out,comment,extra_run) values('$live_id','$b_name','$balls','$m_midden','$b_run','$wicket','$runout','$comment','$extra_run')",$con);
echo "Record Saved Successfully.";


//echo "<meta http-equiv=\"refresh\" content=\"0;URL=live_cricket_detail_result.php?live_id=$live_id\">";

// ================== select live_score table data =================

$q1= mysql_query("select * from live_score where liveid = '$live_id'",$con);
while($q1_data = mysql_fetch_array($q1))
	{
		
	$live_total_score = $q1_data['total_score'];
	$live_total_out = $q1_data['total_out'];
	$live_total_over_cons = $q1_data['over_consumed'];
	}
// = ============================== total over calculation ===============================
$q_bal = mysql_query("select sum(ball) as ball from live_score_detail where liveid = '$live_id'",$con);
while($q_bal_data = mysql_fetch_array($q_bal))
	{
	$t_ball = $q_bal_data['ball'];	
	}
$over = $t_ball/ 6;
$arry= explode(".",$over);
list($ovr) = $arry;

$rem_ball = $t_ball % 6;
$over_cons = $ovr.".".$rem_ball;	
//================= update live score table data  =======================


$update= mysql_query("update live_score set total_score = '$live_total_score' + '$run', total_out = '$live_total_out' + '$wicket' , over_consumed = '$over_cons' where liveid = '$live_id'",$con);	



?>
<br />
<a href="live_cricket_detail_result.php?live_id=<?php echo $live_id; ?>&amp;mid=<?php echo $mid; ?>"> Add New Score </a>