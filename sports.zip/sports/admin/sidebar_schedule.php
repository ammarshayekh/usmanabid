<div id="menubar">
	  <ul id="menulist">
       <li class="menuitem">		<a href="cricket_result_schedule.php" style="color:#000000; text-decoration:none;">Cricket Schedule</a>
		<li class="menuitem">		<a href="football_result_schedule.php" style="color:#000000; text-decoration:none;">Football Schedule</a>
		<li class="menuitem">		<a href="tabletennis_result_schedule.php" style="color:#000000; text-decoration:none;">Table Tennis Schedule</a>
		<li class="menuitem">		<a href="basketball_result_schedule.php" style="color:#000000; text-decoration:none;">Basketball Schedule</a>
        <li class="menuitem">		<a href="vollyball_result_schedule.php" style="color:#000000; text-decoration:none;">Volly Ball Schedule</a>
        <li class="menuitem">		<a href="squash_result_schedule.php" style="color:#000000; text-decoration:none;">Squash Schedule</a>
        <li class="menuitem">		<a href="sprints_result_schedule.php" style="color:#000000; text-decoration:none;">Sprints Schedule</a>
        <li class="menuitem">		<a href="badmintion_result_schedule.php" style="color:#000000; text-decoration:none;">Badmintion Schedule</a>
		<li class="menuitem">		<a href="tugofwar_result_schedule.php" style="color:#000000; text-decoration:none;">Tug of War Schedule</a>
       	<li class="menuitem">		<a href="athletics_result_schedule.php" style="color:#000000; text-decoration:none;">Athletics Schedule</a>
        <li class="menuitem">		<a href="all_games_show.php" style="color:#000000; text-decoration:none;">All Games Schedule</a>
                <li class="menuitem">		<a href="form_mail.php" style="color:#000000; text-decoration:none;">E-Mail</a>

        <li class="menuitem">		<a href="program_furc_show.php" style="color:#000000; text-decoration:none;">Programs Furc</a>
        
	  </ul>
    </div>