<?php   include('config.php'); ?>
<?php
$u_name=$_REQUEST['username'];
$password=$_REQUEST['password'];
$q=mysql_query("select * from tb_admin where user_name='$u_name' and password='$password'",$con);
$username='';
$pass='';
while($q_data=mysql_fetch_array($q))
{
	$username=$q_data['user_name'];
	$pass=$q_data['password'];
}
if(($u_name == $username) && ($password == $pass))
{
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
}
else
{
	echo "username and password is incorrect";
}

$update=mysql_query("update tb_admin set session_id='$ses_id' where user_name='$u_name' and password='$password'",$con);
?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html