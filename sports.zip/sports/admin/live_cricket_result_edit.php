<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ADMIN PANEL
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
   <?php  include('sidebar_result.php'); ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
     Update Record
     </div>
     
     </div>
     <?php
	 $liveid=$_REQUEST['liveid'];
	 $q=mysql_query("select * from live_score where liveid='$liveid'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $liveid=$q_data['liveid'];
		 $team=$q_data['team_name'];
		 $match_with=$q_data['match_with'];
		 $toss=$q_data['toss'];
		 $total_over=$q_data['total_over'];
		 $played_at=$q_data['played_at'];
		 $match_no=$q_data['match_no'];
		 $date=$q_data['dates'];
		 $match_status=$q_data['match_status'];
		 $total_score=$q_data['total_score'];
		 $total_out=$q_data['total_out'];
		 $over_consumed=$q_data['over_consumed'];
	 }
	 
	 ?> 
     
     
	  
	  <div id="dasbord_main">
     <form action="live_cricket_result_insert.php" method="post">
     <input type="hidden" name="action" value="edit" />
  <input type="hidden" name="liveid" value="<?php echo $liveid; ?>" />
  <input type="hidden" name="team3" value="0" />
  <input type="hidden" name="team4" value="0" />
  
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Team Name:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <select name="team1"  style="width:205px; height:25px; margin-right:150px;">
     <option value="<?php echo $team; ?>"><?php echo $team; ?></option>
     <?php
	 $q=mysql_query("select * from cricket ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		// $team=$q_data['team'];
	 
	 ?>
    <option value="<?php echo $q_data['team_name']; ?>"><?php echo $q_data['team_name']; ?></option>
    <?php
	 }
	 ?>
    </select>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
       Match with:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <select name="team2"  style="width:205px; height:25px; margin-right:150px;">
     <option value="<?php echo $match_with; ?>"><?php echo $match_with; ?></option>
     <?php
	 $q1=mysql_query("select * from cricket ",$con);
	 while($q_data1=mysql_fetch_array($q1))
	 {
		 //$team=$q_data['team'];
	 
	 ?>
    <option value="<?php echo $q_data1['team_name']; ?>"><?php echo $q_data1['team_name']; ?></option>
    <?php
	 }
	 ?>
    </select>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Toss:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="toss" value="<?php echo $toss; ?>"  placeholder="enter toss " style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Total Over:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="total_over" value="<?php echo $total_over; ?>" placeholder=" enter total over" style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Play at:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="play" value="<?php echo $played_at; ?>" placeholder=" enter play ground name" style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Match No:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="match_no" value="<?php echo $match_no; ?>"  style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Date:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="date" value="<?php echo $date; ?>"  style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Match Status:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
    <select name="match_status" style="width:205px; height:25px; margin-right:150px;">
    <option value="<?php echo $match_status; ?>"><?php echo $match_status; ?></option>
    <option value="start">Start</option>
    <option value="end">End</option>
    </select>
     </div>
     <div style="clear:both"></div>
     </div>
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Total Score:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="total_score" value="<?php echo $total_score; ?>"  style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Total Out:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="total_out" value="<?php echo $total_out; ?>"  style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Over Consumed:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="over_consumed" value="<?php echo $over_consumed; ?>"  style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <!---------------------------------
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Date:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
     <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> 
     <input type="text" name="date" value=""  placeholder=" enter date" style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Total Score:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
    <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> 
     <input type="text" name="score" value="0"  style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Total Out:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
     <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> 
     <input type="text" name="out" value="0"  style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Over Consumed:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
    <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> 
     <input type="text" name="over_consumed" value="0"  style="width:205px; height:20px; margin-right:150px;" />
     </div>
     <div style="clear:both"></div>
     </div> -------------------------------->
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:420px; height:25px; float:left; text-align:right;">
     <input type="submit" value="Update" style="width:100px; height:25px;"  />
     </div>
     <div style="width:280px; height:25px; float:left; margin-left:10px;">
      <input type="button" name="button" value="cancel" onclick="location.href='live_cricket_result_show.php'" style="width:100px; height:25px; margin-right:200px;"  />
     </div>
     <div style="clear:both"></div>
     </div>
     </form>
  </div>
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>



<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>	
<?php
}
?>




</body>
</html>
