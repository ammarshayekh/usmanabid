<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
TABLE TENNIS REGISTRATION FORM  
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="main_bar">
 <div class="society_members_name">
  Please Fill All The Feilds Below For Table Tennis Team Registration
 </div>
 
 <form action="registeration_form_insert_table_tennis.php" method="post">
  <?php
 $tab_id=$_REQUEST['tabid'];
 $q=mysql_query("select * from table_tennis where tabid='$tab_id' ",$con);
 while($q_data=mysql_fetch_array($q))
 {
	 $team_name=$q_data['team_name'];
	 $program=$q_data['program'];
	 $bat=$q_data['batch'];
	 $cnumber=$q_data['cnumber'];
	 $payler1=$q_data['player1'];
	 $regno1=$q_data['reg_no1'];
	  $payler2=$q_data['player2'];
	 $regno2=$q_data['reg_no2'];
	 // $payler3=$q_data['player3'];
	 //$regno3=$q_data['reg_no3'];
	  //$payler4=$q_data['player4'];
	} //$regno4=$q_data['reg_no4'];
?>
<input type="hidden" name="action" value="edit" />
<input type="hidden" name="tabid" value="<?php echo $tab_id; ?>" />
 <div class="form1">
 <div style="width:700px; height:30px;  margin-bottom:10px; margin-left:100px; margin-top:25px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;">Team Name:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="team_name" value="<?php echo $team_name; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" />
</div>
<div class="clear"></div>
 </div>
 
 <div style="width:700px; height:30px;  margin-bottom:10px; margin-left:100px; margin-top:25px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;">Program:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="program" value="<?php echo $program; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="program" required="required" />
</div>
<div class="clear"></div>
 </div>

 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px; margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Batch:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="batch" value="<?php echo $bat; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="batch name" required="required" />
</div>
<div class="clear"></div>
 </div>
<div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Captain’s Contact Number:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="contactnumber" value="<?php echo $cnumber; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="cell number" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Player 1:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="player1" value="<?php echo $payler1; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="player name" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:2px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Registration #:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="reg1" value="<?php echo $regno1; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="registeration no" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Player 2:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="player2" value="<?php echo $payler2; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="player name" required="required" />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:2px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Registration #:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="reg2" value="<?php echo $regno2; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="registeration no" required="required" />
</div>
<div class="clear"></div>
 </div>
 <!------------------------------
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Player 3:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="player3" value="<?php //echo $payler3; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="player name"  />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:2px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Registeration #:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="reg3" value="<?php //echo $regno3; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="registeration no"/>
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Player 4:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="player4" value="<?php //echo $payler4; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="player name"  />
</div>
<div class="clear"></div>
 </div>
 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:2px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;"> Registeration #:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="reg4" value="<?php //echo $regno4 ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="registeration no" />
</div>
<div class="clear"></div>
 </div>
 ---------------------->
<div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px; margin-bottom:25px;">
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:320px;"> <input type="submit" value="Update" style="width:100px; height:25px;"  /></div>
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:15px;"> <input type="button" name="button" value="cancel" onclick="location.href='cp_tabletennis.php'" style="width:100px; height:25px;"  /></div>
<div class="clear"></div>
 </div>
 
 </div>
 
 </form>
<div class="clear"></div>
 </div>
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>



<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="images/invalid.jpg" />
</div>	
<?php
}
?>




</body>
</html>
