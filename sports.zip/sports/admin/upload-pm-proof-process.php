<?php
include("config.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_link.php'); ?>
</head>
<body>
<?php
if($session == $ses_id)
{
?>
 <?php include('header.php'); ?>
 
<div class="fullsite">

    <div class="wrapper">



        <div id="content">


<div class="site_title">Account</div>
<div class="site_content">
<!-- Content -->
    
<div style="display:table; width:100%">
<div style="display:table-cell; width:210px">
<?php include('left_menu.php'); ?>    
</div>
<div style="display:table-cell; padding-left:20px">
        
        	<!-- Content -->
            
<div class="widget-main-title" style="background-color:#66CCFF; color:#fff;">Upload Payment Proof</div>
<div class="menu-content">
<?php
$withdraw_id= $_REQUEST['wid'];
//=======================================
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$Target = $target_path;
move_uploaded_file($_FILES['image_upload']['tmp_name'], $target_path);
//=========================================

$update = mysql_query("update tb_withdraw set proof_path = '$Target' where withdrawid = '$withdraw_id' and userid = '$u_id'",$con);

$q_with=mysql_query("select * from tb_withdraw where userid = '$u_id' and withdrawid = '$withdraw_id'",$con);
	while($q_with_data=mysql_fetch_array($q_with))
		{
		$proof=$q_with_data['proof_path'];
		}
?>
	   
    <div class="success_box">Your payment proof is uploaded successfully.</div> 
    
    <div class="info_box">Check your proof below. Thanks</div> 
    <div style="overflow:hidden;">
    <img src="<?php echo $proof; ?>" width="700" />
    </div>
                
             
    
       
</div>

           


<!-- End Content -->
            <!-- End Content -->
  
</div>
</div>
<div class="clear"></div>


</div>
<!-- End Content -->

<!-- End Content -->



        <div class="processorlist">

        <!-- 
        
        
        
        
         -->

        </div>

	</div>

	<?php include('footer.php'); ?>

</div>

</div>




<?php } else { 
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>
<?php
  }  ?>
</body>

</html>    

    
