<?php include('config.php'); ?>
<?php
$bowler_name=$_REQUEST['bowler_name'];
//$action=$_REQUEST['action'];
//$crid=$_REQUEST['cid'];
$over=$_REQUEST['over']; 
$midden_over=$_REQUEST['midden_over'];
$runs=$_REQUEST['runs'];
$wicket=$_REQUEST['wicket'];
$runout=$_REQUEST['runout'];
$comment=$_REQUEST['p_comment'];
//$date=$_REQUEST['date'];
//if($action == 'add')
//{
$insert=mysql_query("insert into live_score_bowling (bowler_name,over,midden,runs,wicket,run_out,comment) values ('$bowler_name','$over','$midden_over','$runs','$wicket','$runout','$comment')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=cricket_result_day.php\">";
//}

//if($action == 'edit')
//{
	//$update=mysql_query("update cricket_result set team='$team', play='$play', won='$won', lost='$lost', tied='$tied', no_result='$noreslt', pts='$point', net_runrate='$net_run_rate' where cid='$crid'",$con);
	//echo "<meta http-equiv=\"refresh\" content=\"0;URL=cricket_result_day.php\">";
//}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html