<div class="endbar">
<div class="endbar_text">
<a href="https://www.facebook.com/TECHNO.CATIONS/" target="_blank">Designed and Developed By TECHNOCATION</a>
</div>
</div>