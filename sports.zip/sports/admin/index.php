<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="css/admin.css"  type="text/css" />
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<div id="logo_main">
<div id="logo">
<img src="img/logo1.jpg" width="125" height="`125" />
</div>
</div>

<div class="admin">
Admin Control Pannel
</div>
<!--<div class="main">
<div class="icon">
<img src="img/erroricon.png" width="32" height="32" style="text-align:left" />
</div>
<div class="invalid">
invalid login details
</div>
</div>-->
<form action="index_insert.php" method="post">
<div style="width:300px; height:25px; margin-left:25px; float:left;margin-top:15px;">
<div style="width:74px; height:20px; color: rgb(171,171,171); float:left; margin-right:3px;">
Username:
</div>
<div style="width:220px; height:20px; float:left; ">
<input type="text" name="username" value="" style="width:215px; height:20px; float:left;   border: 1px solid #DEE2E4; border-radius:5px; padding-left:5px;"/>
</div>
<div class="clear"></div>
</div>
<div style="width:300px; height:25px; margin-left:25px; float:left;margin-top:15px;">
<div style="width:74px; height:20px; color: rgb(171,171,171); float:left; margin-right:3px;">
Password:
</div>
<div style="width:220px; height:20px; float:left; ">
<input type="password" name="password" value="" style="width:215px; height:20px; float:left;   border: 1px solid #DEE2E4; border-radius:5px; padding-left:5px;"/>
</div>
<div class="clear"></div>
</div>
<div style="width:300px; height:35px; margin-left:25px; float:left;margin-top:10px; margin-top:15px;">

<div style="width:100px; height:35px; float:left; margin-left:100px; ">
<input type="submit" name="" value="Login" style="width:100px; height:35px;color:rgb(255,255,255);font: bold 16px Arial;border:1px solid #4C4C4C;border-radius:5px;background-color:#4C4C4C; cursor:pointer;"/>
</div>
<div class="clear"></div>
</div>
</form>
</div>
</body>
</html>