<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
	$live_id = $_REQUEST['live_id'];
	$match_id = $_REQUEST['mid'];

$update = mysql_query("update live_score set session_id = '0' , c_status = '0'",$con);
$update2 = mysql_query("update live_score set c_status = '2' where matchid = '$match_id'",$con);
$update1 = mysql_query("update live_score set session_id = '$ses_id', c_status = '1' where liveid = '$live_id'",$con);
	
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ADMIN PANEL
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
   <?php  include('sidebar_result.php'); ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
     Add New Record
     </div>
     
     </div>
	  
	  <div id="dasbord_main">
     <form action="live_cricket_detail_result_insert.php" method="post">
     <input type="hidden" name="action" value="add" />
  <input type="hidden" name="cid" value="0" />
  <input type="hidden" name="mid" value="<?php echo $match_id; ?>" />
  <input type="hidden" name="live_id" value="<?php echo $live_id; ?>" />

     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Team Name:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <?php
	 $q=mysql_query("select * from live_score where liveid = '$live_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		
		 $team=$q_data['team_name'];
		 $match_with=$q_data['match_with'];
		
	 }
	 ?>
     
      <?php
	 $q=mysql_query("select * from cricket where team_name = '$team' ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		$team=$q_data['team_name'];
		
		$p1=$q_data['player1'];
		$p2=$q_data['player2'];
		$p3=$q_data['player3'];
		$p4=$q_data['player4'];
		$p5=$q_data['player5'];
		$p6=$q_data['player6'];
		$p7=$q_data['player7'];
		$p8=$q_data['player8'];
		$p9=$q_data['player9'];
		$p10=$q_data['player10'];
		$p11=$q_data['player11'];
		$p12=$q_data['player12'];
		$p13=$q_data['player13'];
		$p14=$q_data['player14'];
		
	 }
	 
//======================== second team data =============================

$q3=mysql_query("select * from cricket where team_name = '$match_with' ",$con);
	 while($q_data3=mysql_fetch_array($q3))
	 {
				
		$pp1=$q_data3['player1'];
		$pp2=$q_data3['player2'];
		$pp3=$q_data3['player3'];
		$pp4=$q_data3['player4'];
		$pp5=$q_data3['player5'];
		$pp6=$q_data3['player6'];
		$pp7=$q_data3['player7'];
		$pp8=$q_data3['player8'];
		$pp9=$q_data3['player9'];
		$pp10=$q_data3['player10'];
		$pp11=$q_data3['player11'];
		$pp12=$q_data3['player12'];
		$pp13=$q_data3['player13'];
		$pp14=$q_data3['player14'];
		
	 }	 
	 ?>
    <select name="team_name"  style="width:205px; height:25px; margin-right:150px;">
    
    <option value="<?php echo $team; ?>"><?php echo $team; ?></option>
    
    </select>
   
     </div>
     <div style="clear:both"></div>
     </div>
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Player Name:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <select name="player_name" style="width:205px; height:25px; margin-right:150px;">
  <option value="<?php echo $p1; ?>"><?php echo $p1; ?></option>
     <option value="<?php echo $p2; ?>"><?php echo $p2; ?></option>
     <option value="<?php echo $p3; ?>"><?php echo $p3; ?></option>
     <option value="<?php echo $p4; ?>"><?php echo $p4; ?></option>
     <option value="<?php echo $p5; ?>"><?php echo $p5; ?></option>
     <option value="<?php echo $p6; ?>"><?php echo $p6; ?></option>
     <option value="<?php echo $p7; ?>"><?php echo $p7; ?></option>
     <option value="<?php echo $p8; ?>"><?php echo $p8; ?></option>
     <option value="<?php echo $p9; ?>"><?php echo $p9; ?></option>
     <option value="<?php echo $p10; ?>"><?php echo $p10; ?></option>
     <option value="<?php echo $p11; ?>"><?php echo $p11; ?></option>
     <option value="<?php echo $p12; ?>"><?php echo $p12; ?></option>
  	 <option value="<?php echo $p13; ?>"><?php echo $p13; ?></option>
   	<option value="<?php echo $p14; ?>"><?php echo $p14; ?></option>
    <?php  ?>
     </select>
     </div>
     <div style="clear:both"></div>
     </div>
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Balls:
     </div>
     <div style="width:365px; height:25px; float:left;">
      <select name="ball" style="width:110px; height:22px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  ">
     <option value="1"> Yes </option>
     <option value="0"> No </option>
     </select>
 
     </div>
     <div style="clear:both"></div>
     </div>
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Run:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <input type="text" name="run"    style="width:110px; height:20px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  "/>
     </div>
     <div style="clear:both"></div>
     </div>
     
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Beat Ball:
     </div>
     <div style="width:365px; height:25px; float:left;">

     <select name="midden" style="width:110px; height:22px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  ">
     <option value="0"> No </option>
     <option value="1"> Yes </option>
     </select>
     </div>
     <div style="clear:both"></div>
     </div>
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     4s:
     </div>
     <div style="width:365px; height:25px; float:left;">
    <select name="four" style="width:110px; height:22px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  ">
     <option value="0"> No </option>
     <option value="1"> Yes </option>
     </select>
     </div>
     <div style="clear:both"></div>
     </div>
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     6s:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <select name="six" style="width:110px; height:22px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  ">
     <option value="0"> No </option>
     <option value="1"> Yes </option>
     </select>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;background-color:#FF9;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Bowler Name:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <select name="out_by" style="width:205px; height:25px; margin-right:150px;" required="required">

	<option>Select a Value</option>
	 <option value="<?php echo $pp1; ?>"><?php echo $pp1; ?></option>
     <option value="<?php echo $pp2; ?>"><?php echo $pp2; ?></option>
     <option value="<?php echo $pp3; ?>"><?php echo $pp3; ?></option>
     <option value="<?php echo $pp4; ?>"><?php echo $pp4; ?></option>
     <option value="<?php echo $pp5; ?>"><?php echo $pp5; ?></option>
     <option value="<?php echo $pp6; ?>"><?php echo $pp6; ?></option>
     <option value="<?php echo $pp7; ?>"><?php echo $pp7; ?></option>
     <option value="<?php echo $pp8; ?>"><?php echo $pp8; ?></option>
     <option value="<?php echo $pp9; ?>"><?php echo $pp9; ?></option>
     <option value="<?php echo $pp10; ?>"><?php echo $pp10; ?></option>
     <option value="<?php echo $pp11; ?>"><?php echo $pp11; ?></option>
     <option value="<?php echo $pp12; ?>"><?php echo $pp12; ?></option>
  	 <option value="<?php echo $pp13; ?>"><?php echo $pp13; ?></option>
   	<option value="<?php echo $pp14; ?>"><?php echo $pp14; ?></option>
    
    
     </select>
     </div>
     <div style="clear:both"></div>
     </div>
  <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px; background-color:#FF9;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Run:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <input type="text" name="b_run"    style="width:110px; height:20px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  "/>
     </div>
     <div style="clear:both"></div>
     </div>   
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;background-color:#FF9;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Extra Run:
     </div>
     <div style="width:365px; height:25px; float:left;">
      <select name="extra" style="width:110px; height:22px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  ">
     <option value="0"> Select Value </option>
     <option value="1"> Wide Ball </option>
     <option value="0"> Dead Ball </option>
     <option value="1"> No Ball </option>
     <option value="1"> Leg By </option>
     <option value="1"> Over Through </option>
      <option value="5"> Five </option>
       <option value="4"> Four </option>
        <option value="3"> Three </option>
         <option value="2"> Two </option>
     </select>
 
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;background-color:#FF9;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Midden Over:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <select name="midden_over" style="width:110px; height:22px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  ">
     <option value="0"> No </option>
     <option value="1"> Yes </option>
     </select>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;background-color:#FF9;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Wickets:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <select name="wicket" style="width:110px; height:22px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  ">
     <option value="0"> No </option>
     <option value="1"> Yes </option>
     </select>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;background-color:#FF9;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Run Out:
     </div>
     <div style="width:110px; height:25px; float:left;">
     <select name="runout" style="width:110px; height:22px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  ">
     <option value="0"> No </option>
     <option value="1"> Yes </option>
     </select>
     </div>
     <div style="width:80px; height:25px; float:left;">
     Comments:
     </div>
     <div style="width:210px; height:25px; float:left;">
     <input type="text" name="p_comment"    style="width:210px; height:20px;  padding-left:5px; border:1px solid rgb(204,204,204);  "/>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:420px; height:25px; float:left; text-align:right;">
     <input type="submit" value="Send" style="width:100px; height:25px;"  />
     </div>
     <div style="width:280px; height:25px; float:left; margin-left:10px;">
      <input type="button" name="button" value="cancel" onclick="location.href='live_cricket_result_show.php'" style="width:100px; height:25px; margin-right:200px;"  />
     </div>
     <div style="clear:both"></div>
     </div>
     </form>
  </div>
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>



<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>	
<?php
}
?>




</body>
</html>
