<?php include('config.php'); ?>
<?php
//$game_name=$_REQUEST['game_name'];
$news=addslashes($_REQUEST['news']);
$action=addslashes($_REQUEST['action']);
$todid=$_REQUEST['lanid'];
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into latest_news(text,dates) values ('$news','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=latest_news_result.php\">";
}

if($action == 'edit')
{
	$update=mysql_query("update latest_news set text='$news' where lanid='$todid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=latest_news_result.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html