<?php include('config.php'); ?>
<?php
$team1=$_REQUEST['team1'];
$action=$_REQUEST['action'];
$liveid=$_REQUEST['liveid'];
$team2=$_REQUEST['team2']; 
$team3=$_REQUEST['team3']; 
$team4=$_REQUEST['team4']; 
$toss=$_REQUEST['toss'];
$over=$_REQUEST['total_over'];
$play=$_REQUEST['play'];
$match_no=$_REQUEST['match_no'];
$match_status=$_REQUEST['match_status'];
$total_score=$_REQUEST['total_score'];
$total_out=$_REQUEST['total_out'];
$over_consumed=$_REQUEST['over_consumed'];
$date=$_REQUEST['date'];

$m_id = substr($ses_id , 1, 6);
$m_rand = rand(1,1000);

$match_id = $m_id.$m_rand;

if($action == 'add')
{
$insert=mysql_query("insert into live_score (team_name,match_with,toss,total_over,played_at,match_no,dates,match_status,matchid) values ('$team1','$team2','$toss','$over','$play','$match_no','$date','Start','$match_id')",$con);


$insert=mysql_query("insert into live_score (team_name,match_with,toss,total_over,played_at,match_no,dates,match_status,matchid) values ('$team3','$team4','$toss','$over','$play','$match_no','$date','Start','$match_id')",$con);

echo "<meta http-equiv=\"refresh\" content=\"0;URL=live_cricket_result_show.php\">";
}

if($action == 'edit')
{
	$update=mysql_query("update live_score set team_name='$team1', match_with='$team2', toss='$toss', total_over='$over', played_at='$play', match_no='$match_no', dates='$date', match_status='$match_status', total_score='$total_score', total_out='$total_out', over_consumed='$over_consumed' where liveid='$liveid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=live_cricket_result_show.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html