<div class="menubar">
<div class="menu2">
    <a href="cp_cricket.php">Home</a>
    <a href="cricket_result_schedule.php" class="current">Schedule</a>
    <a href="participants_result.php">Video</a>
    <a href="registeration_img_game_show.php">Registration</a>
    <a href="ambassdor_result.php">Event</a>
    <a href="img_society_show.php">Society Members</a>
    <a href="cricket_result_day.php">Results</a>
    <a href="live_cricket_result_show.php">Live Score</a>
    <a href="contact_img_society_show.php">Coordinator</a>
    <a class="dummy"> </a>
</div>
 </div>