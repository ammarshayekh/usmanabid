<?php include('config.php'); ?>
<?php
$team=$_REQUEST['team'];
$action=$_REQUEST['action'];
$crid=$_REQUEST['cid'];
$play=$_REQUEST['play']; 
$won=$_REQUEST['won'];
$lost=$_REQUEST['lost'];
$tied=$_REQUEST['tied'];
$noreslt=$_REQUEST['no_result'];
$point=$_REQUEST['points'];
$net_run_rate=$_REQUEST['net_run_rate'];
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into cricket_result (team,play,won,lost,tied,no_result,pts,net_runrate,dates) values ('$team','$play', '$won','$lost','$tied','$noreslt','$point','$net_run_rate','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=cricket_result_day.php\">";
}

if($action == 'edit')
{
	$update=mysql_query("update cricket_result set team='$team', play='$play', won='$won', lost='$lost', tied='$tied', no_result='$noreslt', pts='$point', net_runrate='$net_run_rate' where cid='$crid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cricket_result_day.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html