<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ADMIN PANEL
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
   <?php  include('sidebar.php'); ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
    Edit Points By Match
     </div>
     
     </div>
	  <?php 
	  $tugoid=$_REQUEST['tugoid'];
	  $q=mysql_query("select * from tugofwar_schedule where tugoid='$tugoid'",$con);
	  while($q_data=mysql_fetch_array($q))
	  {
		 $program=$q_data['program'];
		 $team=$q_data['team_name'];
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $date=$q_data['dates'];
		 
	  }
	  
	   ?>
	  <div id="dasbord_main">
     <form action="tugofwar_schedule_insert.php" method="post">
     <input type="hidden" name="action" value="edit" />
     <input type="hidden" name="tugoid" value="<?php echo $tugoid; ?>" />
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Teams Name:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="team" value="<?php echo $team; ?>" required="required"  style="width:300px; height:20px; margin-right:55px;" />
     </div>
     <div style="clear:both"></div>
     </div>
     
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Program:
     </div>
     
     <div style="width:365px; height:25px; float:left;">
     <div style="width:110px; height:25px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="program" value="<?php echo $program; ?>" required="required"  style="width:100px; height:20px;border:1px solid rgb(204,204,204);" />
     </div>
     <div style="width:90px; height:22px; float:left; margin-left:20px;border:1px solid rgb(204,204,204);">
     <?php echo $program; ?>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Time:
     </div>
     
     <div style="width:365px; height:25px; float:left;">
     <div style="width:110px; height:25px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
     <input type="text" name="cr_time" value="<?php echo $cr_time; ?>" required="required"  style="width:100px; height:20px;border:1px solid rgb(204,204,204);" />
     </div>
     <div style="width:90px; height:22px; float:left; margin-left:20px;border:1px solid rgb(204,204,204);">
     <?php echo $cr_time; ?>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="clear:both"></div>
     </div>
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Date:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <div style="width:110px; height:25px; float:left;">
     <input type="text" name="cr_date" value="<?php echo $cr_date; ?>"  required="required"  style="width:100px; height:20px; padding-left:5px; border:1px solid rgb(204,204,204);  "/>
     </div>
     <div style="width:90px; height:22px; float:left; margin-left:20px;border:1px solid rgb(204,204,204);">
     <?php echo $cr_date; ?>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="clear:both"></div>
     </div>
     
     
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:420px; height:25px; float:left; text-align:right;">
     <input type="submit" value="Update" style="width:100px; height:25px;"  />
     </div>
     <div style="width:280px; height:25px; float:left; margin-left:10px;">
      <input type="button" name="button" value="cancel" onclick="location.href='tugofwar_result_schedule.php'" style="width:100px; height:25px; margin-right:200px;"  />
     </div>
     <div style="clear:both"></div>
     </div>
     </form>
  </div>
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>

<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>	
<?php
}
?>






</body>
</html>
