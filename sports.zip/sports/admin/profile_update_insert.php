<?php   include('config.php');  ?>
<?php


$uname=$_REQUEST['name'];
$password=$_REQUEST['password'];
$cpass=$_REQUEST['cpassword'];


$date=date('d-m-Y');
$q=mysql_query("select * from tb_admin where session_id='$ses_id'",$con);
while($q_data=mysql_fetch_array($q))
{
	$admin_id=$q_data['admin_id'];
}

if($password == $cpass)
{
	//echo "correct";
$update=mysql_query("update tb_admin set user_name='$uname', password='$password',dates='$date' where admin_id='$admin_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=home.php\">";
	
}
else
{
	echo " Your current password is incorrect";
	exit();
}



//$insert=mysql_query("insert into tb_user (full_name,user_name,email_address,password,university_name) valuess('$fname','$uname','$email','$password','$uniname')",$con);




?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html