<?php include('config.php'); ?>
<?php
$game_name=$_REQUEST['game_name'];
$news=$_REQUEST['news'];
$action=$_REQUEST['action'];
$todid=$_REQUEST['todid'];
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into today_sports (game_name,news,dates) values ('$game_name','$news','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=today_sports_result.php\">";
}

if($action == 'edit')
{
	$update=mysql_query("update today_sports set game_name='$game_name', news='$news' where todid='$todid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=today_sports_result.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html