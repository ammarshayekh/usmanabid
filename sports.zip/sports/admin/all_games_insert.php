<?php     include('config.php');        ?>
<?php

$name=$_REQUEST['name'];
$gameid=$_REQUEST['gameid'];
$action=$_REQUEST['action'];
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into all_games (game_name,dates) values ('$name','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=all_games_show.php\">";
}
if($action == 'edit')
{
	$update=mysql_query("update all_games set game_name='$name' where gameid='$gameid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=all_games_show.php\">";
}

?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html