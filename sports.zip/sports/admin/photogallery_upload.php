<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
	
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ADMIN PANEL  
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
    <?php        include('sidebar.php');     ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
     Upload Images in photogallery
     </div>
     
     </div>
	  
	  <div id="dasbord_main">
     <div id="dasbord_inner">
     <div id="dasbord_inner1_note">
     Note:
     </div>
     <div id="dasbord_inner2_note">
     Now you can upload Images here.Only upload (jpg.png.gif) images
     </div>
     </div>
     
	
	 
  <form action="photogallery_insert.php" method="post" enctype="multipart/form-data">
 <input type="hidden" name="action" value="add" />
 <input type="hidden" name="photoid" value="0" />
  <div id="dasbord_inner42">  
     <div  id="dasbord_inner45" style="text-align:right; padding-top:5px;">
     Name:
     </div>
     <div id="dasbord_inner45">
    <input type="text" name="name"  value="" required="required" placeholder="enter name" style="width:250px; height:20px;"/>
     </div>
      </div>
     <div id="dasbord_inner42">  
     <div  id="dasbord_inner45" style="text-align:right; padding-top:5px;">
     Select image
     </div>
     <div id="dasbord_inner45">
    <input type="file" name="image_upload" />
     </div>
      </div>
      <div id="dasbord_inner42">  
     
     <input type="submit" name="upload" value="Save" />
    <input type="button" name="cancel" value="Cancel" onclick="location.href='photogallery_show.php'" />
      </div>
     
</form>
     
     
     </div>
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>

<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>	
<?php
}
?>





</body>
</html>
