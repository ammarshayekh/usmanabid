<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ADMIN PANEL
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
   <?php  include('sidebar.php'); ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
     Participants Data
     </div>
     <div id="dasbord_inner4" style="text-align:right;">
  <a href="participants_form.php">  <img src="img/add_12.gif" width="12" height="12" title="add new university" style="margin-right:5px;"/></a>
     </div>
     </div>
	
	  <div id="dasbord_main">
     <div id="dasbord_inner">
     <div id="dasbord_inner8">
     PID
     </div>
     
     
     
     
     <div id="dasbord_inner24">
     S.No
     </div>
     <div id="dasbord_inner_uni">
    UNIVERSITY NAME
     </div>
     
     
     <div id="dasbord_inner24">
     DATE
     </div>
     <div id="dasbord_inner25" style="width:135px;">
     ACTION
     </div>
     <div class="clear"></div>
     </div>
     <?php
	 $q=mysql_query("select * from participants",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $partiid=$q_data['partiid'];
		 $s_no=$q_data['s_no'];
		 $uni_name=$q_data['uni_name'];
		
		 $date=$q_data['dates'];
	 
	 
	 ?> 
     
     
     <div id="dasbord_inner3">  
     <div id="dasbord_inner7">
     <?php  echo $partiid; ?>
     </div>
     
     <div id="dasbord_inner26">
    <?php echo $s_no; ?>
     </div>
     <div id="dasbord_inner_uni1">
     <?php echo $uni_name; ?>
     </div>
     <div id="dasbord_inner26">
     <?php  echo $date; ?>
     </div>
    
     
    
     <div id="dasbord_inner26" style="width:66px;">
   <a href="participants_edit.php?partiid=<?php echo $partiid; ?>">  <img src="../css/img/edit.png" height="16" width="16" title="edit" /></a>
     </div>
     <!-----------------
     <div id="dasbord_inner26" style="width:66px;">
   <a href="">  <img src="img/delete.png" width="16" height="16" title="delete" /></a>
     </div>
     
     <div class="clear"></div>
     ---------------------->
     </div>
     
     <?php  } ?>
     
     
     </div>
      
      
      
      
      
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>

<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>	
<?php
}
?>






</body>
</html>
