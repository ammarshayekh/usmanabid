<?php include('config.php');?>
<?php
$feid=$_REQUEST['feeid'];
$update=mysql_query("update feedback set status='1' where feeid='$feid' ",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=ad_feedback.php\">";

?>