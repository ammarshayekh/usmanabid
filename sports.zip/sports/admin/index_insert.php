<?php include('config.php'); ?>
<?php
$u_name=$_REQUEST['username'];
$password=$_REQUEST['password'];
//echo $u_name;
//echo $password;
$date=date('d-m-Y');
//$q=mysql_query("insert into tb_admin(user_name,password,dates,session_id) values('$u_name','$password','$date','$ses_id')",$con);
$q=mysql_query("select * from tb_admin where user_name='$u_name'",$con);
$username='abc';
$pass='abc';
while($q_data=mysql_fetch_array($q))
{
	$username=$q_data['user_name'];
	$pass=$q_data['password'];
}
if($u_name!=$username)
{
	echo "invalid username";
	exit();
}
if($password!=$pass)
{
	echo "invalid password";
	exit();
}
$update=mysql_query("update tb_admin set session_id='$ses_id' where user_name='$u_name' and password='$password'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=home.php\">";

?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html