<?php     include('config.php');        ?>
<?php

$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$program=$_REQUEST['program'];
$cnumber=$_REQUEST['cnumber'];
$action=$_REQUEST['action'];
$contid=$_REQUEST['contid'];
//=======================================
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$Target = $target_path;
move_uploaded_file($_FILES['image_upload']['tmp_name'], $target_path);
//=========================================
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into contact_img (name,program,cnumber,email,proof,dates) values ('$name','$program','$cnumber','$email','$Target','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=contact_img_society_show.php\">";
}
if($action == 'edit')
{
	$update=mysql_query("update contact_img set name='$name', program='$program', cnumber='$cnumber', email='$email', proof='$Target' where contid='$contid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=contact_img_society_show.php\">";
}



?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html