<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$sts = $_REQUEST['s'];
$id = $_REQUEST['id'];

$update= mysql_query("update table_tennis set status = '$sts' where tabid = '$id'",$con);

echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_tabletennis.php\">";
?>
</body>
</html>