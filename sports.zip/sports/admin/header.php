<div class="header">
 <div id="logo" >
 <img src="../images/complete2.gif" width="210" height="90"/>
 </div>
 <div id="p">
 Foundation University Rawalpindi Campus
 </div>
 
 <!----------start form------------->
 
 
 
 
 <div style="width:155px; height:25px;  margin-top:70px; margin-left:840px;">
 <div style="width:75px; height:20px; float:left;">
 <a href="cp_cricket.php " style="color:rgb(255,0,0); font:  bold 14px Arial;"> My deatail</a>
 </div>
  <div style="width:75px; height:20px; float:left;">
 <a href="logout.php" style="color:rgb(255,0,0); font:  bold 14px Arial;"> Logout</a>
 </div>
 <div style="clear:both"></div>
 </div>

 <!----------end form------------->
 
<div class="clear"></div>
 
</div>