<?php  include('config.php'); ?>
<?php
$img=$_REQUEST['img'];

?>
<img src="../<?php echo $img; ?>" />