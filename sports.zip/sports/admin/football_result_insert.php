<?php include('config.php'); ?>
<?php
$team=$_REQUEST['team'];
$action=$_REQUEST['action'];
$fbid=$_REQUEST['fbbid'];
$play=$_REQUEST['play']; 
$won=$_REQUEST['won'];
$draw=$_REQUEST['draw'];

$lost=$_REQUEST['lost'];
$gf=$_REQUEST['gf'];
$ga=$_REQUEST['ga'];
$gd=$_REQUEST['gd'];
$pts=$_REQUEST['pts'];
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into football_result (team_name,play,won,draw,lost,gf,ga,gd,pts,dates) values ('$team','$play', '$won','$draw','$lost','$gf','$ga','$gd','$pts','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=football_result_day.php\">";
}

if($action == 'edit')
{
	$update=mysql_query("update football_result set team_name='$team', play='$play', won='$won', draw='$draw', lost='$lost', gf='$gf', ga='$ga', gd='$gd', pts='$pts' where fbbid='$fbid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=football_result_day.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html