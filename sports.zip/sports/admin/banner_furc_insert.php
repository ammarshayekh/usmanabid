<?php     include('config.php');        ?>
<?php

$name=$_REQUEST['name'];
$action=$_REQUEST['action'];
$banid=$_REQUEST['banid'];
//=======================================
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$Target = $target_path;
move_uploaded_file($_FILES['image_upload']['tmp_name'], $target_path);
//=========================================
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into banner_furc (name,proof,dates) values ('$name','$Target','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=banner_furc_show.php\">";
}
if($action == 'edit')
{
	$update=mysql_query("update banner_furc set name='$name', proof='$Target' where banid='$banid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=banner_furc_show.php\">";
}



?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html