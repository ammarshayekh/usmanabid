<?php
include("config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<?php include('meta_link.php'); ?>
</head>



<body>
 <?php
if($session == $ses_id)
{
?>


<div class="fullsite">

    <div class="wrapper">

 <?php include('header.php'); ?>

        <div id="content">


<div class="site_title">Account</div>
<div class="site_content">
<!-- Content -->
    
<div style="display:table; width:100%">
<div style="display:table-cell; width:210px">
<?php include('left_menu.php') ?>        
</div>
<div style="display:table-cell; padding-left:20px">
        
        	<!-- Content -->
            <!-- Content -->
<div class="widget-main-title" style="background-color:#66CCFF; color:#fff;">Upload Payment Proof</div>

<div class="widget-content">
 
 <div class="info_box" id="error_box" >
Now you can upload your payment proof here.  Only upload (jpg, png, gif ) images.</div> 
    <form  class="formclass" method="post" encType="multipart/form-data" action="upload-pm-proof-process.php">
    <?php
	$withdraw_id = $_REQUEST['wid'];
	?>
<input type="hidden" name="wid" value="<?php echo $withdraw_id; ?>" />
<table class="widget-tbl" width="100%">

  <tr>
    	<td align="right">Select Image:</td>
        <td> <input name="image_upload" type="file"   /></td>
    </tr>
    
    
	
    <tr>
    	<td colspan="2" align="center"><input type="submit" name="btn" value="Upload" class="orange" /> &nbsp;&nbsp;<input type="button" name="btn" value="Cancel" onclick="location.href='withdraw-history.php';"></td>
    </tr>
</table>

</form>
</div>




<!-- End Content -->
            <!-- End Content -->
  
</div>
</div>
<div class="clear"></div>


</div>
<!-- End Content -->

<!-- End Content -->



        <div class="processorlist">

        <!-- 
        
        
        
        
         -->

        </div>

	</div>

	<?php include('footer.php'); ?>

</div>

</div>


<?php } else { 
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>
<?php
  }  ?>


</body>

</html>    

    
