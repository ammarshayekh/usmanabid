<?php include('config.php'); ?>
<?php
$result=$_REQUEST['result'];
$action=$_REQUEST['action'];
$crid=$_REQUEST['cricid'];
$team1=$_REQUEST['team1'];
$pts1=$_REQUEST['pts1']; 
$team2=$_REQUEST['team2'];
$pts2=$_REQUEST['pts2'];
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into cricket_day (result_date,team_name1,pts1,team_name2,pts2,dates) values ('$result','$team1', '$pts1','$team2','$pts2','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=cricket_result_day.php\">";
}
if($action == 'edit')
{
	$updat=mysql_query("update cricket_day set result_date='$result', team_name1='$team1', pts1='$pts1', team_name2='$team2', pts2='$pts2'where cricid='$crid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cricket_result_day.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html