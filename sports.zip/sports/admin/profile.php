<?php  include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ACCOUNT  
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
    <?php include('sidebar.php'); ?>
     
     <div id="dasbord">
     User Edit Record
     </div>
    <form action="profile_update_insert.php" method="post">
     <?php  
	 
	 $q=mysql_query("select * from tb_admin where session_id='$ses_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $uuname=$q_data['user_name'];
		 $passs=$q_data['password'];
		 
	 }
	  ?>
     <div id="dasbord_main">
    
     
   
	 
   <div id="dasbord1">
     <div style="width:727px; height:30px;  margin-bottom:0px; margin-left:0px;">
<div style="width:200px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;"> User Name:</div>
<div style="width:300px; height:25px; float:left;  text-align: left; padding-left:20px;">
<input type="text" name="name" value="<?php echo $uuname; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;"  />
</div>
<div class="clear"></div>
 </div>
     </div>
     
  <div id="dasbord1">
     <div style="width:727px; height:30px;  margin-bottom:0px; margin-left:0px;">
<div style="width:200px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;">New Password:</div>
<div style="width:300px; height:25px; float:left;  text-align: left; padding-left:20px;">
<input type="password" name="password" value="<?php echo $passs; ?>" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;"  />
</div>
<div class="clear"></div>
 </div>
     </div>
    <div id="dasbord1">
     <div style="width:727px; height:30px;  margin-bottom:0px; margin-left:0px;">
<div style="width:200px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;"> Current password:</div>
<div style="width:300px; height:25px; float:left;  text-align: left; padding-left:20px;">
<input type="password" name="cpassword" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;"  />
</div>
<div class="clear"></div>
 </div>
     </div>
     
     <div id="dasbord1">
     
     
     <div style="width:700px; height:30px;  margin-bottom:5px; ">
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:220px;"> <input type="submit" value="Update" style="width:100px; height:25px;"  /></div>
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:15px;"> <input type="button" name="button" value="cancel" onclick="location.href='home.php'" style="width:100px; height:25px;"  /></div>

 </div>
 </div>
 </div>
 </form>
     
  
  </div>
 
 
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>



<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="../images/invalid.jpg" />
</div>	
<?php
}
?>





</body>
</html>
