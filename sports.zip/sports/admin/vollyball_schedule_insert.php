<?php include('config.php'); ?>
<?php
$teams=$_REQUEST['team'];
$program=$_REQUEST['program'];
$action=$_REQUEST['action'];
$volid=$_REQUEST['volid'];
$cr_time=$_REQUEST['cr_time'];
$cr_date=$_REQUEST['cr_date']; 
$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into vollyball_schedule (program,cr_time,cr_date,team_name,dates) values ('$program','$cr_time','$cr_date', '$teams','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=vollyball_result_schedule.php\">";
}
if($action == 'edit')
{
	$updat=mysql_query("update vollyball_schedule set program='$program', cr_time='$cr_time', cr_date='$cr_date', team_name='$teams' where volid='$volid'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=vollyball_result_schedule.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html