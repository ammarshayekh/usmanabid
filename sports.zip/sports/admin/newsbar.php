<div class="newsbar">

     </div>