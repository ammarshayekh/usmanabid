<div id="menubar">
	  <ul id="menulist">
       <li class="menuitem">		<a href="cricket_result_day.php" style="color:#000000; text-decoration:none;">Cricket Result</a>
		<li class="menuitem">		<a href="football_result_day.php" style="color:#000000; text-decoration:none;">Football Result</a>
		<li class="menuitem">		<a href="tennis_result_day.php" style="color:#000000; text-decoration:none;">Table Tennis Result</a>
		<li class="menuitem">		<a href="basketball_result_day.php" style="color:#000000; text-decoration:none;">Basketball Result</a>
        <li class="menuitem">		<a href="vollyball_result_day.php" style="color:#000000; text-decoration:none;">Volly Ball Result</a>
        <li class="menuitem">		<a href="squash_result_day.php" style="color:#000000; text-decoration:none;">Squash Result</a>
        <li class="menuitem">		<a href="sprints_result_day.php" style="color:#000000; text-decoration:none;">Sprints Result</a>
        <li class="menuitem">		<a href="badmintion_result_day.php" style="color:#000000; text-decoration:none;">Badmintion Result</a>
		<li class="menuitem">		<a href="tugofwar_result_day.php" style="color:#000000; text-decoration:none;">Tug of War Result</a>
       	<li class="menuitem">		<a href="athletics_result_day.php" style="color:#000000; text-decoration:none;">Athletics Result</a>
        <li class="menuitem">		<a href="today_sports_result.php" style="color:#000000; text-decoration:none;">Today Sports Result</a>
        <li class="menuitem">		<a href="latest_news_result.php" style="color:#000000; text-decoration:none;">Latest News </a>
        <li class="menuitem">		<a href="photogallery_show.php" style="color:#000000; text-decoration:none;">Photogallery </a>
        
	  </ul>
    </div>