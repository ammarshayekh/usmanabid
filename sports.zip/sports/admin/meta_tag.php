<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sports :: Foundation University Rawalpindi Campus </title>
<link rel="stylesheet" type="text/css" href="css/css/style.css" />
<link rel="stylesheet" type="text/css" href="css/css/css-menu.css"/> 