<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ADMIN PANEL
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
   <?php  include('sidebar_result.php'); ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
     Add New Record
     </div>
     
     </div>
	  
	  <div id="dasbord_main">
     <form action="live_cricket_bowling_result_insert.php" method="post">
     <input type="hidden" name="action" value="add" />
  <input type="hidden" name="cid" value="0"  />
     
     
     
     
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
      Bowler Name:
     </div>
     
     <div style="width:365px; height:30px; float:left;">
   <!----  <select name="total_team" style="width:205px; height:25px; margin-right:150px; padding-left:5px; border:1px solid rgb(204,204,204); padding-top:3px;" > 
   
     <option value="">Pakistan</option>
     </select> --->
      <select name="bowler_name" style="width:205px; height:25px; margin-right:150px;">
     <?php
	// $crid=$_REQUEST['crid'];
	 $q=mysql_query("select * from cricket where crid='$crid' ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $player=$q_data['player1'];
		 
	 ?>
     <option value="<?php echo $player; ?>"><?php echo $player; ?></option>
     <?php } ?>
    
     </select>

     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Over:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <input type="text" name="over" value="0"   style="width:110px; height:20px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  "/>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Midden Over:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <input type="text" name="midden_over" value="0"    style="width:110px; height:20px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  "/>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Run:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <input type="text" name="runs" value="0"   style="width:110px; height:20px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  "/>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:310px; height:25px; float:left; text-align:right;">
     Wickets:
     </div>
     <div style="width:365px; height:25px; float:left;">
     <input type="text" name="wicket" value="0"   style="width:110px; height:20px; margin-right:250px; padding-left:5px; border:1px solid rgb(204,204,204);  "/>
     </div>
     <div style="clear:both"></div>
     </div>
     <div style="width:727px; height:25px; margin-top:5px; margin-bottom:5px;">
     <div style="width:420px; height:25px; float:left; text-align:right;">
     <input type="submit" value="Send" style="width:100px; height:25px;"  />
     </div>
     <div style="width:280px; height:25px; float:left; margin-left:10px;">
      <input type="button" name="button" value="cancel" style="width:100px; height:25px; margin-right:200px;"  />
     </div>
     <div style="clear:both"></div>
     </div>
     </form>
  </div>
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>



<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="img/invalid.jpg" />
</div>	
<?php
}
?>




</body>
</html>
