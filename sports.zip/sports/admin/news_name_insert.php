<?php include('config.php'); ?>
<?php
$news=$_REQUEST['news'];
//echo $uniname;
$date=date('d-m-Y');
$insert=mysql_query("insert into university (news,dates) values('$news','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=live_cricket_result_show.php\">";

?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="img/preloader.gif" width="40" height="40" />
</div>
</body>
</html