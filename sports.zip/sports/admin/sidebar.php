<div id="menubar">
	  <ul id="menulist">
       <li class="menuitem">		<a href="cp_cricket.php" style="color:#000000; text-decoration:none;">Cricket</a>
		<li class="menuitem">		<a href="cp_football.php" style="color:#000000; text-decoration:none;">Football</a>
		<li class="menuitem">		<a href="cp_tabletennis.php" style="color:#000000; text-decoration:none;">Table Tennis</a>
		<li class="menuitem">		<a href="cp_basketball.php" style="color:#000000; text-decoration:none;">Basketball</a>
        <li class="menuitem">		<a href="cp_vollyball.php" style="color:#000000; text-decoration:none;">Volly Ball</a>
        <li class="menuitem">		<a href="cp_squash.php" style="color:#000000; text-decoration:none;">Squash</a>
        <li class="menuitem">		<a href="cp_sprints.php" style="color:#000000; text-decoration:none;">Sprints</a>
        <li class="menuitem">		<a href="cp_badmintion.php" style="color:#000000; text-decoration:none;">Badmintion</a>
		<li class="menuitem">		<a href="cp_tugofwar.php" style="color:#000000; text-decoration:none;">Tug of War</a>
       	<li class="menuitem">		<a href="cp_athletics.php" style="color:#000000; text-decoration:none;">Athletics</a>
        <li class="menuitem">		<a href="cp_society.php" style="color:#000000; text-decoration:none;">Furc Society</a>
        <li class="menuitem">		<a href="group_result.php" style="color:#000000; text-decoration:none;">Match Group</a>
        <li class="menuitem">		<a href="ad_feedback.php" style="color:#000000; text-decoration:none;">Feedback</a>
        <li class="menuitem">		<a href="profile.php" style="color:#000000; text-decoration:none;">Admin Profile</a>
	  </ul>
    </div>