<?php include('../config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registeration Report</title>
<link rel="stylesheet" href="css/report.css" type="text/css" />
</head>

<body>
<?php

$id=$_REQUEST['id'];
$q=mysql_query("select * from basketball where baid='$id'",$con);


while($q_data=mysql_fetch_array($q))
{
	$uid=$q_data['userid'];
	$sess_id=$q_data['session_id'];
	$team_name=$q_data['team_name'];
	$pro=$q_data['program'];
	$to=$q_data['tournament'];
	$bat=$q_data['batch'];
	$contnmbr=$q_data['cnumber'];
	$p1=$q_data['player1'];
	$r1=$q_data['reg_no1'];
	$p2=$q_data['player2'];
	$r2=$q_data['reg_no2'];
	$p3=$q_data['player3'];
	$r3=$q_data['reg_no3'];
	$p4=$q_data['player4'];
	$r4=$q_data['reg_no4'];
	$p5=$q_data['player5'];
	$r5=$q_data['reg_no5'];
	$p6=$q_data['player6'];
	$r6=$q_data['reg_no6'];
	$p7=$q_data['player7'];
	$r7=$q_data['reg_no7'];
	$p8=$q_data['player8'];
	$r8=$q_data['reg_no8'];
	





	


}
?>



<div class="wrap">
<!-------header start--------->
<div id="header">
<div id="logo">
<img src="img/logo1.jpg" height="130" width="130" />
</div>
<p>FURC SPORTS FESTIVAL Fall 2015</p>
<div class="clear"></div>
</div>
<!---------header close------->
<div id="program_main">
<div id="rpt_cricket">
<div id="program_text">
Team Name:
</div>
<div id="program_text1">
<?php echo $team_name; ?>
</div>
<div class="clear"></div>
<div id="program_text">
Tournament:
</div>
<div id="program_text1">
<?php echo $to ; ?>
</div>
<div class="clear"></div>

<div id="program_text">
Program:
</div>
<div id="program_text1">
<?php echo $pro; ?>
</div>
<div class="clear"></div>
<div id="program_text">
Batch:
</div>
<div id="program_text1">
<?php  echo $bat; ?>
</div>
<div class="clear"></div>
<div id="program_text">
Captain's Contact #:
</div>
<div id="program_text1">
<?php echo $contnmbr; ?>
</div>
<div class="clear"></div>
<div style="width:680px; height:25px; margin-top:5px;">
<div id="player_text">
Player1:
</div>
<div id="player_text1">
<?php echo $p1; ?>
</div>
<div id="player_text">
Registration #:
</div>
<div id="player_text1">
<?php  echo $r1; ?>
</div>
</div>
<div class="clear"></div>
<div style="width:680px; height:25px; margin-top:5px;">
<div id="player_text">
Player2:
</div>
<div id="player_text1">
<?php echo $p2; ?>
</div>
<div id="player_text">
Registration #:
</div>
<div id="player_text1">
<?php echo $r2; ?>
</div>
</div>
<div class="clear"></div>
<div style="width:680px; height:25px; margin-top:5px;">
<div id="player_text">
Player3:
</div>
<div id="player_text1">
<?php echo $p3; ?>
</div>
<div id="player_text">
Registration #:
</div>
<div id="player_text1">
<?php echo $r3; ?>
</div>
</div>
<div class="clear"></div>
<div style="width:680px; height:25px; margin-top:5px;">
<div id="player_text">
Player4:
</div>
<div id="player_text1">
<?php echo $p4; ?>
</div>
<div id="player_text">
Registration #:
</div>
<div id="player_text1">
<?php echo $r4; ?>
</div>
</div>
<div class="clear"></div>
<div style="width:680px; height:25px; margin-top:5px;">
<div id="player_text">
Player5:
</div>
<div id="player_text1">
<?php echo $p5; ?>
</div>
<div id="player_text">
Registration #:
</div>
<div id="player_text1">
<?php echo $r5; ?>
</div>
</div>
<div class="clear"></div>
<div style="width:680px; height:25px; margin-top:5px;">
<div id="player_text">
Player6:
</div>
<div id="player_text1">
<?php echo $p6; ?>
</div>
<div id="player_text">
Registration #:
</div>
<div id="player_text1">
<?php echo $r6; ?>
</div>
</div>
<div class="clear"></div>
<?php
if($p7!='')
{
?>
<div style="width:680px; height:25px; margin-top:5px;">
<div id="player_text">
Player7:
</div>
<div id="player_text1">
<?php echo $p7; ?>
</div>
<div id="player_text">
Registration #:
</div>
<div id="player_text1">
<?php echo $r7; ?>
</div>
</div>
<div class="clear"></div>
<?php } ?>
<?php
if($p8!='')
{ 
?>
<div style="width:680px; height:25px; margin-top:5px;">
<div id="player_text">
Player8:
</div>
<div id="player_text1">
<?php echo $p8; ?>
</div>
<div id="player_text">
Registration #:
</div>
<div id="player_text1">
<?php echo $r8; ?>
</div>
</div>
<div class="clear"></div>

<?php } ?>





<div id="coordinator_text">
Presdient's Signature                                                                                                     
</div>

<div class="clear"></div>


</div>
</div>

</div>

</body>
</html>