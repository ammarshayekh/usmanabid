<?php include('../config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registeration Report</title>
<link rel="stylesheet" href="css/report.css" type="text/css" />
</head>

<body>
<?php

$id=$_REQUEST['id'];
$q=mysql_query("select * from furc_society where furcid='$id'",$con);


while($q_data=mysql_fetch_array($q))
{
	$uid=$q_data['userid'];
	$sess_id=$q_data['session_id'];
	$too=$q_data['tournament'];
	$regnoo=$q_data['regno'];
	$proo=$q_data['program'];
	$batt=$q_data['batch'];
	$namm=$q_data['name'];
	$contnmbrr=$q_data['cnumber'];
	
	

	


}
?>



<div class="wrap">
<!-------header start--------->
<div id="header">
<div id="logo">
<img src="img/logo1.jpg" height="130" width="130" />
</div>
<p>FURC SPORTS FESTIVAL Fall 2015</p>
<div class="clear"></div>
</div>
<!---------header close------->
<div id="program_main">
<div id="rpt_cricket">
<div id="program_text">
Tournament
</div>
<div id="program_text1">
<?php echo $too; ?>
</div>
<div class="clear"></div>

<div id="program_text">
Programe:
</div>
<div id="program_text1">
<?php echo $proo; ?>
</div>
<div class="clear"></div>
<div id="program_text">
Batch
</div>
<div id="program_text1">
<?php echo $batt; ?>
</div>
<div class="clear"></div>
<div id="program_text">
  Name:
</div>
<div id="program_text1">
<?php echo  $namm; ?>
</div>
<div class="clear"></div>
<div id="program_text">
  Contact #:
</div>
<div id="program_text1">
<?php echo  $contnmbrr; ?>
</div>
<div class="clear"></div>






<div id="coordinator_text">
Presdient's Signature                                                                                                     
</div>

<div class="clear"></div>


</div>
</div>

</div>

</body>
</html>