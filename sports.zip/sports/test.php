<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<?php
//session_start();
//$ses_id=session_id();
//echo $ses_id;
/*$q=mysql_query("select * from tb_user ",$con);
while($q_data=mysql_fetch_array($q))
{
	$u=$q_data['user_name'];
	$f=$q_data['full_name'];
	$e=$q_data['email_address'];
	$p=$q_data['password'];
	$un=$q_data['university_name'];
	$d=$q_data['dates'];
	$se=$q_data['session_id'];
	echo $u;
	echo $f;
	echo $e;
	echo $p;
	echo $un;
	echo $d;
	echo $se;
}
*/
$f='al';
$k='';
$l=mysql_query("select * from tb_user where user_name='$f' or email_address='$k'",$con);
$n='aa';
$r='aa';
while($h_data=mysql_fetch_array($l))
{
	$n=$h_data['user_name'];
	$r=$h_data['email_address'];
	echo $n;
	echo $r;
}
?>
</body>
</html>
