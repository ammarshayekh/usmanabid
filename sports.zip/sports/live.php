<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
<meta http-equiv="refresh" content="35" >
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
 Live Score Card<span style="width:600px; text-align:center; margin-left:200px;"> Click here for <a href="cricket_summary.php" style="color:#FF0000;"> Match Summary</a></span>
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div class="clear"></div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Cricket
</div>
 
 </div>
 
 <?php

$q_m=mysql_query("select * from live_score where c_status = '1'",$con);
while($q_m_data=mysql_fetch_array($q_m))
	{
 $mid=$q_m_data['matchid'];
	}
 //$q4=mysql_query("select * from live_score"
 $q1= mysql_query("select * from live_score where matchid = '$mid' order by c_status ASC ",$con);
while($q1_data = mysql_fetch_array($q1))
	{
	$live_liveid = $q1_data['liveid'];
	//$live_detailid = $q1_data['livedetailid'];				
	$live_team_name = $q1_data['team_name'];	
	$live_match_with = $q1_data['match_with'];
	$live_toss = $q1_data['toss'];
	$live_play_at = $q1_data['played_at'];
	$live_match_no = $q1_data['match_no'];	
	$live_dates = $q1_data['dates'];
	$live_total_over = $q1_data['total_over'];
	$live_total_score = $q1_data['total_score'];
	$live_total_out = $q1_data['total_out'];
	$live_total_over_cons = $q1_data['over_consumed'];
	
	 $qww=mysql_query("select sum(run_out) as run_out  from live_score_bowling where liveid='$live_liveid' ",$con);
 while($qww_data=mysql_fetch_array($qww))
 	
		
		$live_bowl_runout = $qww_data['run_out'];
		
	$usman1=$live_bowl_runout+$live_total_out;
 ?> 
  <?php
  $qu=mysql_query("select sum(extra_run) as extra_run from live_score_bowling where liveid='$live_liveid' ",$con);
 while($qu_data=mysql_fetch_array($qu))
 	{
		$total_count = $qu_data['extra_run'];
	}
 //$sql = "SELECT COUNT(bowlid) from live_score_bowling where liveid = '$live_liveid' and (extra_run = 'W' or extra_run = 'N' or extra_run='L' or extra_run='O')"; 
					//$result3 = mysql_query($sql,$con); 
					//$data3 = mysql_fetch_row($result3); 
					//$total_count = $data3[0]; 
					$haji=$live_total_score+$total_count;
					//$haji1=$haji;
					//$asif=$haji/$live_total_over_cons;
					//$fahran = round($asif,2,PHP_ROUND_HALF_UP);	
					//$abid=$live_total_over-$live_total_over_cons;
					//$basit=$haji1-$haji;
					//$muneeb=($haji/$abid);
 ?> 
  <div class="team_cricket_live">
  <div class="team_cricket1_live">
 
<?php echo $live_team_name; ?> <?php echo $haji; ?>/ <?php echo $usman1; ?> (<?php echo $live_total_over_cons; ?> ov)<br />
<?php echo $live_match_with; ?><br />
<?php echo $live_toss; ?><br/>
<?php echo $live_play_at; ?><br />
Match no.<?php echo $live_match_no; ?> | 2014 season<br />
<?php echo $live_dates; ?> (<?php echo $live_total_over; ?>-over match)<br />

</div>
 
 </div>

 <div class="team_cricket">
  <div class="team_cricket1">
  <?php
  $news='';
  $q5=mysql_query("select * from university",$con);
  while($q5_data=mysql_fetch_array($q5))
  {
	  $news=$q5_data['news'];
  }
  ?>
 <?php echo $news; ?>
</div>
 
 </div>
  
  <!-- start -->
  <div style="width:100%;">
 <div id="teams_point_table">
 <div class="Result_bar">
 <div class="teams_live">
 <?php echo $live_team_name; ?> innings (<?php echo $live_total_over; ?> overs max)
 </div>
 <div class="teams_live">
 OUT BY
 </div>
 <div class="teams1_live">
 Runs
 </div>
 <div class="teams1_live">
 Midden balls
 </div>
 <div class="teams1_live">
 Balls
 </div>
 <div class="teams1_live">
 4s
 </div>
 <div class="teams1_live">
 6s
 </div>
 <div class="teams1_live">
 Strike Rate
 </div>
 </div>
 <div class="teams_main">
 <?php
 
 $q2=mysql_query("select sum(run) as run, sum(midden)as midden, sum(ball) as ball, sum(fours) as fours, sum(sixs) as sixs , player_name, outs from live_score_detail where  liveid='$live_liveid'  group by player_name order by livedetailid asc ",$con);
 while($q2_data= mysql_fetch_array($q2))
 	{
		//$livedetailid=$q1_data['livedetailid'];
		$p_name = $q2_data['player_name'];
		$out_by = $q2_data['outs'];
		$live_run = $q2_data['run'];
		$live_midden = $q2_data['midden'];
		$live_ball = $q2_data['ball'];
		$live_fours = $q2_data['fours'];
		$live_sixs = $q2_data['sixs'];
		if($live_ball == 0 )
		{
		$live_strike1='0';	
		}
		if($live_ball != 0 )
		{
		$live_strike1 = ($live_run / $live_ball) * 100;
		}
	$live_strike = round($live_strike1,2,PHP_ROUND_HALF_UP);	
	
	$qq=mysql_query("select  outs,p_out from live_score_detail where player_name = '$p_name' order by livedetailid asc",$con);
	$outt='';
	while($qq_data=mysql_fetch_array($qq))
		{
		$outt = $qq_data['outs'];
		$outtt=$qq_data['p_out'];	
		
		}
 ?>
 <div class="match_schedule_cricket">
 <div class="teams_live">
 <?php echo $p_name; ?>
 </div>
 
 <div class="teams_live">
 
 <?php if($outt != '') { echo $outt; } if($outtt != '') { echo $outtt; }?>
 </div>
 <div class="teams1_live">
 <?php echo $live_run; ?>
 </div>
 <div class="teams1_live">
 <?php echo $live_midden; ?>
 </div>
 <div class="teams1_live">
 <?php echo $live_ball; ?>
 </div>
 <div class="teams1_live">
 <?php echo $live_fours; ?>
 </div>
 <div class="teams1_live">
 <?php echo $live_sixs; ?>
 </div>
 <div class="teams1_live">
 <?php echo $live_strike; ?>
 </div>

 <div class="clear"></div>
 
 
 </div>
 <?php } ?>
 
 
 
 
 
 
 <div class="clear"></div>
 </div>
 <!-------
<div class="team_cricket_fall">
  <div class="team_cricket1_fall">
Fall of wickets<br />

</div>
 
 </div> 
--------->
 
 <div class="clear"></div>
 
 <div class="clear"></div>
 
 <div class="clear"></div>
 </div>
 <!-- ***************************** -->
 
  <div class="clear"></div>
 
  <div class="clear"></div>
 
 
  <div class="clear"></div>
  
  <div class="clear"></div>
  
 
 
 
  <div class="clear"></div>
  
  <div class="clear"></div>
  
 
  <div class="clear"></div>
  
  <div class="clear"></div>
  
  
 
 
  <div class="clear"></div>
  
  <div class="clear"></div>
 
  <div class="clear"></div>
  
  <div class="clear"></div>
 
  <div class="clear"></div>
  
  <div class="clear"></div>
   <div class="clear"></div>
  <div class="clear"></div>
 
  <div class="clear"></div>
  
  <div class="clear"></div>
  
 <div id="teams_point_table_live">
 <div class="Result_bar">
 <div class="teams_live">
 Bowling
 </div>
 
 <div class="teams1_live2">
 Overs
 </div>
 <div class="teams1_live2">
 Midden Overs
 </div>
 <div class="teams1_live2">
 Runs
 </div>
 <div class="teams1_live2">
 Wickets
 </div>
 <div class="teams1_live2">
 Economy
 </div>
 
 </div>
 <div class="teams_main">
 <?php
 
 $q3=mysql_query("select sum(midden) as midden, sum(runs) as runs, sum(wicket) as wicket, bowler_name, sum(ball) as ball from live_score_bowling where liveid='$live_liveid' group by bowler_name order by bowlid asc",$con);
 while($q3_data=mysql_fetch_array($q3))
 	{
		$live_bowl_name = $q3_data['bowler_name'];
		$live_bowl_ball = $q3_data['ball'];
		$live_bowl_midden = $q3_data['midden'];
		$live_bowl_run = $q3_data['runs'];
		$live_bowl_wicket = $q3_data['wicket'];
		


$over = $live_bowl_ball/ 6;
$arry= explode(".",$over);
list($ovr) = $arry;

$rem_ball = $live_bowl_ball % 6;
$over_cons = $ovr.".".$rem_ball;		
if($over_cons == 0)
{
$ecno1='0';	
}
if($over_cons != 0)
{
	if($live_bowl_ball <6)
	{
	$ecno1 = $live_bowl_run / $live_bowl_ball;	
	}
	if($live_bowl_ball > 5)
	{	
	$ecno1 = $live_bowl_run / $over_cons;
	}
}

$ecno = round($ecno1,2,PHP_ROUND_HALF_UP);	

 ?>
 <div class="match_schedule_cricket">
 <div class="teams_live">
 <?php echo $live_bowl_name; ?>
 </div>
 
  <div class="teams1_live2">
 <?php echo $over_cons; ?>
 </div>
 <div class="teams1_live2">
 <?php echo $live_bowl_midden; ?>
 </div>
 <div class="teams1_live2">
 <?php echo $live_bowl_run; ?>
 </div>
 <div class="teams1_live2">
 <?php echo $live_bowl_wicket; ?>
 </div>
 <div class="teams1_live2">
<?php echo $ecno; ?>
 </div>
 
 <div class="clear"></div>
 </div>
 <?php } ?>
 
 <div class="match_schedule_cricket">

 <div class="teams_live">
 Extra Runs
 </div>
   <?php
   $qu=mysql_query("select sum(extra_run) as extra_run from live_score_bowling where liveid='$live_liveid' ",$con);
 while($qu_data=mysql_fetch_array($qu))
 	{
		$total_count = $qu_data['extra_run'];
	}
 //$sql = "SELECT COUNT(bowlid) from live_score_bowling where liveid = '$live_liveid' and (extra_run = 'W' or extra_run = 'N' or extra_run='L' or extra_run='O')"; 
					//$result3 = mysql_query($sql,$con); 
					//$data3 = mysql_fetch_row($result3); 
					//$total_count = $data3[0]; 
					
 ?>
  <div class="teams1_live2">
 <?php echo $total_count; ?>
 </div>

 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">

 <div class="teams_live">
 Run Out
 </div>
  <?php
 $live_bowl_runout='';
 $qw=mysql_query("select sum(run_out) as run_out  from live_score_bowling where liveid='$live_liveid'",$con);
 while($qw_data=mysql_fetch_array($qw))
 	{
		
		$live_bowl_runout = $qw_data['run_out'];
		//$wicketss=$qw_data['wicket'];
		//$usman=$live_bowl_runout+$wicketss;

?>
  <div class="teams1_live2">
 <?php echo $live_bowl_runout; ?>
 </div>
<?php } ?>
 <div class="clear"></div>
 </div>
 <div class="clear"></div>
 </div>
 

 
 <div class="clear"></div>
 
 </div>
  <div class="clear"></div>
  
 <?php } ?>
 </div>
 <!-- end first team ************************************ -- >
 
  
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>


</body>
</html>
