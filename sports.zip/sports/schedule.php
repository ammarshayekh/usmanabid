<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
SCHEDULE
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="main_bar">
 <div class="time">
 Time
 </div>
 <div class="time">
 Date
 </div>
 <div class="schedule_programs">
  MATCHES
 </div>
 <div class="announcement">
13TH OCT - 03 NOV 2014
 </div>
 <div class="clear"></div>
 
 
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from cricket_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from cricket_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $crscheduleid=$q_data['crsid'];
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
  
	 
	 ?>
	 
	 
	 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1" style="width:728px;">
<?php echo $team; ?>
 </div>
 <div class="time_cricket" style="width:37px;">
 <a href="groups.php" style="color:#000; text-decoration:underline;">group</a>
 </div>
 
 
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from football_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from football_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['fb_time'];
		 $cr_date=$q_data['fb_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1">
<?php echo $team; ?>
 </div>
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from basketball_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from basketball_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1">
<?php echo $team; ?>
 </div>
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from vollyball_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from vollyball_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1">
<?php echo $team; ?>
 </div>
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from badmintion_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from badmintion_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1">
<?php echo $team; ?>
 </div>
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from squash_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from squash_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1">
<?php echo $team; ?>
 </div>
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from sprints_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from sprints_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1">
<?php echo $team; ?>
 </div>
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from athletics_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from athletics_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1">
<?php echo $team; ?>
 </div>
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from tennis_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from tennis_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1" style="width:728px;">
<?php echo $team; ?>
 </div>
 <div class="time_cricket" style="width:37px;">
 <a href="groups_tennis.php" style="color:#000; text-decoration:underline;">group</a>
 </div>
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket_main">
 <?php
  
	 $q=mysql_query("select * from tugofwar_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 
		 $program=$q_data['program'];
		
		 
	 
	 }
	 ?> 
 
 <div class="Schedule_cricket">
 <?php echo $program; ?>
 </div>

 <?php
  
	 $q=mysql_query("select * from tugofwar_schedule",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $cr_time=$q_data['cr_time'];
		 $cr_date=$q_data['cr_date'];
		 $team=$q_data['team_name'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="time_cricket">
 <?php echo $cr_time; ?>
 </div>
 
 <div class="time_cricket">
 <?php echo $cr_date; ?>
 </div>
 <div class="schedule_programs_cricket1">
<?php echo $team; ?>
 </div>
 
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>
</body>
</html>
