<?php include('config.php'); ?>
<?php
$team_name=$_REQUEST['team_name'];
$program=$_REQUEST['program'];
$action=$_REQUEST['action'];
$athi_id=$_REQUEST['atid'];
$tournament='Athletics';
$batch=$_REQUEST['batch'];
$contactnumber=$_REQUEST['contactnumber'];
$player1=$_REQUEST['player1'];
$reg1=$_REQUEST['reg1'];
/*
echo "Program=".$program."<br>";
echo "Batch=".$batch."<br>";
echo "Contact Number=".$contactnumber."<br>";
echo "Player One=".$playerone."<br>";
echo "Registeration=".$registeration."<br>";
*/


$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into athletics (userid,team_name,tournament,program,batch,cnumber,player1,reg_no1,dates,session_id) values ('$u_id','$team_name','$tournament','$program','$batch','$contactnumber','$player1','$reg1','$date','$ses_id')",$con);
$q=mysql_query("select * from athletics where session_id='$ses_id'",$con);
while($q_data=mysql_fetch_array($q))
{
	$athi_id=$q_data['atid'];
}
$update=mysql_query("udate athletics set session_id='0' where session_id='$ses_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=report/rpt_athletics.php?id=$athi_id\">";
}
if($action == 'edit')
{
	$update=mysql_query("update athletics set team_name='$team_name', program='$program', batch='$batch',cnumber='$contactnumber',player1='$player1',reg_no1='$reg1' where atid='$athi_id'" ,$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_athletics.php\">";
}

?>

<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html>