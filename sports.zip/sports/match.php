<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
<div id="scedule_text">
MATCH
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
<div class="clear"></div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Cricket
</div>
 
 </div>
  <div class="clear"></div>
 
 <div class="team_cricket">
  <div class="team_cricket1">
 Air University, Islamabad
</div>
 
 </div>
  <div class="clear"></div>
 <div id="teams_point_table">
 <div class="Result_bar">
 <div class="match">
 Player Name
 </div>
 <div class="bowler">
 Bowler
 </div>
 <div class="teams1">
 R
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 B
 </div>
 <div class="teams1">
 4s
 </div>
 <div class="teams1">
 6s
 </div>
 <div class="teams1">
 SR
 </div>
 </div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 

 <div class="points_match">
 Foundation University
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="bowling_points">
 Bowling
 </div>
 <div class="bowling1_points">
 O
 </div>
  <div class="bowling1_points">
 M
 </div>
 <div class="bowling1_points">
 R
 </div>
 <div class="bowling1_points">
 W
 </div>
 <div class="bowling1_points">
 Econ
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="bowling_points">
 10:00
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket">
 <div class="bowling_points">
 10:00
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="bowling_points">
 10:00
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="bowling_points">
 10:00
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="clear"></div>
 </div> 

 <div class="clear"></div>
 </div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Football
</div>
 
 </div>
  <div class="clear"></div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Air University, Islamabad
</div>
 
 </div>
  <div class="clear"></div>
 <div id="teams_point_table">
 <div class="Result_bar">
 <div class="match">
 Player Name
 </div>
 <div class="bowler1">
 GP
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 GD
 </div>
 </div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="match">
 10:00
 </div>
 
 <div class="bowler1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 

 <div class="points_match">
 Foundation University
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="bowling_points">
 Bowling
 </div>
 <div class="bowling1_points">
 O
 </div>
  <div class="bowling1_points">
 M
 </div>
 <div class="bowling1_points">
 R
 </div>
 <div class="bowling1_points">
 W
 </div>
 <div class="bowling1_points">
 Econ
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="bowling_points">
 10:00
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="match_schedule_cricket">
 <div class="bowling_points">
 10:00
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="bowling_points">
 10:00
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="bowling_points">
 10:00
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="bowling1_points">
 2
 </div>
 <div class="clear"></div>
 </div>
 <div class="clear"></div>
 </div> 

 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>



</body>
</html>
