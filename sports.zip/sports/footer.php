<div class="footer">
<div class="footer1">
<div class="footer1_imges">
<div class="icon_img">
<a href="index.php" style="cursor:pointer;">  <img src="css/img/home.png" width="35" height="35" title="Home"/></a>
    </div>
    <div class="icon_img">
  <a href="https://www.facebook.com/TECHNO.CATIONS/" style="cursor:pointer;">  <img src="css/img/fb.png" width="35" height="35" title="Facebook" /></a>
    </div>
    <div class="icon_img">
  <a href="" style="cursor:pointer;">  <img src="css/img/twitter.png" width="35" height="35" title="Twitter" /></a>
    </div>
    <div class="icon_img">
  <a href="schedule.php" style="cursor:pointer;">  <img src="css/img/calendar_icon1.png" width="35" height="35" title="Schedule" /></a>
    </div>
 
 <div class="icon_img">
  <a href="photo_gallery.php" style="cursor:pointer;">  <img src="css/img/cameria_icon.png" width="35" height="35" title="Photogallery"/></a>
    </div>
 <div class="icon_img">
  <a href="contact.php" style="cursor:pointer;">  <img src="css/img/ContactusIconLarge.png" width="35" height="35" title="Contact Us" /></a>
    </div>
 <div class="icon_img">
  <a href="feedback_comments.php" style="cursor:pointer;">  <img src="css/img/guestbook.png" width="35" height="35" title="Feedback"/></a>
    </div>
 
 </div>
 <div class="clear"></div>
</div>
<!----------footer1 end------------>
<!------footer2 start------->
<div id="footer2">
<div id="footer2_grid1">
   <div id="grid1_text">
   About Us
   </div>
   <div id="grid1_text1">
   Introduction
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!------GRID2 START--------->
<div id="footer2_grid1">
    
   <div id="grid1_text">
   Home
   </div>
   <div id="grid1_text1">
 <a style="text-decoration:none;"href="contact.php">  Contact Us</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!--------GRID2END---------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Cricket
   </div>
   <div id="grid1_text1">
  <a style="text-decoration:none;" href="cricket_rules.php"> Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!------GRID3 END---------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Football
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="football_rules.php">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!---------GRID4END--------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Basketball
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="basketball_rules.php">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!----------GRID5END--------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Tennis
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="tennis_rules.php">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!----------GRID6END---------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Tug of War
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="#">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!---------------GRID7END---------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Sprints
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="#">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!-----------GRID8END------------->
<div id="footer2_grid1">
   <div id="grid1_text">
  Volly Ball
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="#">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!-------------grid9end----------->
<div id="footer2_grid1">
   <div id="grid1_text">
  Athletics
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="#">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!---grid10end------->
<div id="footer2_grid1">
   <div id="grid1_text">
  Badmintion
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="badmintion_rules.php">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!--------grid11end-------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Squash
   </div>
   <div id="grid1_text1">
   <a style="text-decoration:none;" href="squash_rules.php">Rules</a>
   </div>
   <div id="grid1_text1">
    <a style="text-decoration:none;" href="feedback.php"> Feedback</a>
   </div>
</div>
<!--------------grid12end----------->

<!--------------grid13end------------>

<!----grid14end--------->
</div>
<!------footer2 end------->
<!------endbar start------->
<div class="endbar">
<div class="endbar_text">
All Rights Reserved Copyright © 2018 FURC <span style="margin-left:300px;"><a href="https://www.facebook.com/TECHNO.CATIONS/" target="_blank">Developed By TECHNOCATION</a></span>
</div>
</div>
<!------endbar close------->
</div>

<!-- My Ads -->


