<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<?php
if($session_id == $ses_id)
{
?>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php'); ?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
ACCOUNT  
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="wrapper">
    <?php        include('sidebar.php');     ?>
     
     <div id="dasbord">
      <div id="dasbord_inner4">
     Upload Payement Proof/Slip
     </div>
     
     </div>
	  
	  <div id="dasbord_main">
     <div id="dasbord_inner">
     <div id="dasbord_inner1_note">
     Note:
     </div>
     <div id="dasbord_inner2_note">
     Now you can upload payement Proof/Slip here.Only upload (jpg.png.gif) images
     </div>
     </div>
     <?php
	 $updat_id=$_REQUEST['update_id'];
	 $form_value=$_REQUEST['form_value'];
	 ?>
  <form action="cp_upload_insert.php" method="post" enctype="multipart/form-data">
  <input type="hidden" name="update_id" value="<?php echo $updat_id; ?>" />
  <input type="hidden" name="form_value" value="<?php   echo $form_value; ?>" />
     <div id="dasbord_inner3">  
     <div  id="dasbord_inner5" style="text-align:right; padding-top:5px;">
     Select image
     </div>
     <div id="dasbord_inner5">
    <input type="file" name="image_upload" />
     </div>
      </div>
      <div id="dasbord_inner3">  
     
     <input type="submit" name="upload" value="Upload" />
    <input type="button" name="cancel" onclick="location.href='cp_cricket.php'" value="Cancel" />
      </div>
     
</form>
     
     
     </div>
      <div class="clear"></div>
    </div>
   
  
 
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php'); ?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>


<?php
}
else
{
?>
<div style="width:960px; height:auto; padding-top:250px; padding-left:300px; margin:0 auto;">
<img src="images/invalid.jpg" />
</div>	
<?php
}
?>





</body>
</html>
