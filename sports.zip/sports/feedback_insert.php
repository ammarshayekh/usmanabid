<?php include('config.php'); ?>
<?php
$usernam=$_REQUEST['username'];
$email=$_REQUEST['email'];
$subject=$_REQUEST['subject'];
$msgg=$_REQUEST['message'];
$captcha=$_REQUEST['captcha'];
$code="koeqf";

/*echo "Your Name=".$usernam."<br>";
echo "Your Email=".$email."<br>";
echo "Country=".$country."<br>";
echo "Yur Message=".$msg."<br>";
echo "Your character=".$captcha."<br>";*/
if($captcha !=$code)
{
	echo "Captcha is inccrrect.<br>";
	exit();
}





$date=date('d-m-Y');
$insert=mysql_query("insert into feedback (name,email_address,subject,message,dates,session_id) values ('$usernam','$email','$subject','$msgg','$date','$ses_id')",$con);


/*$q=mysql_query("select * from feedback  ",$con);
while($q_data=mysql_fetch_array($q))
{
	$fedid=$q_data['feeid'];
}*/
//$update=mysql_query("udate feedback set where session_id='$ses_id and feeid='$fedid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=feedback_comments.php\">";

?>


<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html>