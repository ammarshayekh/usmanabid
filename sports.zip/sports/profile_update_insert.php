<?php   include('config.php');  ?>
<?php

$fname=$_REQUEST['fname'];
$uname=$_REQUEST['username'];
$email=$_REQUEST['email'];
$uniname=$_REQUEST['uniname'];
$password=$_REQUEST['password'];
$cpass=$_REQUEST['cpassword'];

/*echo $fname;
echo $uname;
echo $email;
echo $uniname; 
echo $password;
echo $cpass;*/

$q=mysql_query("select * from tb_user where session_id='$ses_id'",$con);
while($q_data=mysql_fetch_array($q))
{
	$uid=$q_data['userid'];
}

if($password == $cpass)
{
	//echo "correct";
$update=mysql_query("update tb_user set full_name='$fname', user_name='$uname',email_address='$email', password='$password',university_name='$uniname' where userid='$uid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=cpanel.php\">";
	
}
else
{
	echo " Your current password is incorrect";
	exit();
}



//$insert=mysql_query("insert into tb_user (full_name,user_name,email_address,password,university_name) valuess('$fname','$uname','$email','$password','$uniname')",$con);




?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html