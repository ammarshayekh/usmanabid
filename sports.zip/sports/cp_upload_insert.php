<?php include('config.php'); ?>

<?php

$update_id=$_REQUEST['update_id'];
$form_value=$_REQUEST['form_value'];
//=======================================
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$target_path = "proof/";
$target_path = $target_path . basename( $_FILES['image_upload']['name']);
$Target = $target_path;
move_uploaded_file($_FILES['image_upload']['tmp_name'], $target_path);
//=========================================
if($form_value == 'cricket')
{
	$update=mysql_query("update cricket set proof='$Target' where userid='$u_id' and crid='$update_id'",$con );
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_cricket.php\">";
}
if($form_value == 'basketball')
{
	$update=mysql_query("update basketball set proof='$Target' where userid='$u_id' and baid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_basketball.php\">";
}
if($form_value == 'football')
{
	$update=mysql_query("update football set proof='$Target' where userid='$u_id' and fbid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_football.php\">";
	
}
if($form_value == 'table_tennis')
{
	$update=mysql_query("update table_tennis set proof='$Target' where userid='$u_id' and tabid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_tabletennis.php\">";
}
if($form_value == 'vollyball')
{
	$update=mysql_query("update vollyball set proof='$Target' where userid='$u_id' and vbid='$update_id'",$con);
            echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_vollyball.php\">";
}
if($form_value == 'squash')
{
	$update=mysql_query("update squash set proof='$Target' where userid='$u_id' and sqid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_squash.php\">";
}
if($form_value == 'sprints')
{
	$update=mysql_query("update sprints set proof='$Target' where userid='$u_id' and spid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_sprints.php\">";
}
if($form_value == 'badmintion')
{
	$update=mysql_query("update badmintion set proof='$Target' where userid='$u_id' and bid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_badmintion.php\">";
}
if($form_value == 'tugofwar')
{
	$update=mysql_query("update tug_of_war set proof='$Target' where userid='$u_id' and tugid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_tugofwar.php\">";
}
if($form_value == 'athletics')
{
	$update=mysql_query("update athletics set proof='$Target' where userid='$u_id' and atid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_athletics.php\">";
}
if($form_value == 'furc_society')
{
	$update=mysql_query("update furc_society set proof='$Target' where userid='$u_id' and furcid='$update_id'",$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_society.php\">";
}

?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html