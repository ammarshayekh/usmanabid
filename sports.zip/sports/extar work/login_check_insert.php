<?php  include('config.php'); ?>
<?php
$un=$_REQUEST['username'];
$pass=$_REQUEST['password'];
//echo $un."<br>";
//echo $pass."<br>";
$q=mysql_query("select * from tb_user where user_name='$un' and password='$pass'",$con);
$unn="";
$passs="";
while($q_data=mysql_fetch_array($q))
{
	$unn=$q_data['user_name'];
	$passs=$q_data['password'];
}
if(($un == $unn) && ($pass == $passs))
{
	//echo "user name and password  is correct";
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cpanel.php\">";
	
}

else
{
	echo " user name and password is  incorrect";
	
}
$update=mysql_query("update tb_user set session_id='$ses_id' where user_name='$un' and password='$pass'",$con);

?>