<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
RESULT
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div class="clear"></div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Cricket
</div>
 
 </div>
  <div class="clear"></div>
  
 <div id="teams_point_table">
 <div class="Result_bar">
 <div class="teams">
 Teams
 </div>
 <div class="teams1">
 Match
 </div>
 <div class="teams1">
 Won
 </div>
 <div class="teams1">
 Lost
 </div>
 <div class="teams1">
 Tied
 </div>
 <div class="teams1">
 N/R
 </div>
 <div class="teams1">
 Pts
 </div>
 <div class="teams1">
 NetRR
 </div>
 </div>
 
 
 <div class="teams_main">
 <?php  
 $q=mysql_query("select * from cricket_result order by pts desc",$con);
 while($q_data=mysql_fetch_array($q))
 {
	  $team=$q_data['team'];
		 $play=$q_data['play'];
		 $won=$q_data['won'];
		 $lost=$q_data['lost'];
		 $tied=$q_data['tied'];
		 $noresult=$q_data['no_result'];
		 $pts=$q_data['pts'];
		 $netrunrate=$q_data['net_runrate'];
 
 
 ?>
 
 <div class="match_schedule_cricket">
 <div class="teams">
 <?php echo $team; ?>
 </div>
 
 <div class="teams1">
 <?php echo $play; ?>
 </div>
 <div class="teams1">
 <?php echo $won; ?>
 </div>
 <div class="teams1">
 <?php echo $lost; ?>
 </div>
 <div class="teams1">
 <?php echo $tied; ?>
 </div>
 <div class="teams1">
 <?php echo $noresult; ?>
 </div>
 <div class="teams1">
 <?php echo $pts; ?>
 </div>
 <div class="teams1">
 <?php echo $netrunrate; ?>
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 <?php } ?>
 </div>
 

 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 <?php
	 $q=mysql_query("select * from cricket_day",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
		 
	 
	 
	 ?> 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php echo $resultdate; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $pts1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team2; ?>
 </div>
 <div class="teams2_points ">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
 <?php echo $pts2; ?>
 </div>
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php } ?>
 
 
 
 <div class="clear"></div>
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="team_cricket">
  <div class="team_cricket1">
 Football
</div>
 
 </div>
  <div class="clear"></div>
 <div id="teams_point_table">
 <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div>
 <div class="teams_main">
 <?php
	 $q=mysql_query("select * from football_result order by pts desc",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $team=$q_data['team_name'];
		 $play=$q_data['play'];
		 $won=$q_data['won'];
		 $draw=$q_data['draw'];
		 $lost=$q_data['lost'];
		 $gf=$q_data['gf'];
		 $ga=$q_data['ga'];
		 $gd=$q_data['gd'];
		 $pts=$q_data['pts'];
	 ?>
 <div class="match_schedule_cricket">
 <div class="football">
 <?php echo $team; ?>
 </div>
 
 <div class="teams1">
 <?php echo $play; ?> </div>
 <div class="teams1">
 <?php echo $won; ?>
 </div>
 <div class="teams1">
 <?php echo $draw; ?>
 </div>
 <div class="teams1">
 <?php echo $lost; ?>
 </div>
 <div class="teams1">
 <?php echo $gf; ?>
 </div>
 <div class="teams1">
 <?php echo $ga; ?>
 </div>
 <div class="teams1">
 <?php echo $gd; ?>
 </div>
 <div class="teams1">
 <?php echo $pts; ?>
 </div>
 <div class="clear"></div>
 </div>
<?php } ?>
 <div class="clear"></div>
 </div>
 

 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
   <?php
	 $q=mysql_query("select * from football_day",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
	 ?> 
 
 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php echo $resultdate; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team1;  ?>
 </div>
 <div class="teams1_points">
 <?php echo $pts1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team2; ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
 <?php echo $pts2; ?>
 </div>
 
 
 
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Tennis
</div>
 
 </div>
  <div class="clear"></div>
 
 <div id="teams_point_table">
<!------- <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div> 
 ------->
 
<!----------- <div class="teams_main">
   
 <div class="match_schedule_cricket">
 <div class="football">
 
 </div>
 
 <div class="teams1">
 
 </div>
 <div class="teams1">
 
 </div>
 <div class="teams1">
 
 </div>
 <div class="teams1">
 
 </div>
 <div class="teams1">
 
 </div>
 <div class="teams1">
 
  </div>
 <div class="teams1">
 
 </div>
 <div class="teams1">
 
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div> --------------->
 

 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 <?php
	 $q=mysql_query("select * from tennis_day ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
		 
	 
	 
	 ?> 
 
 
 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php echo $resultdate; ?>
 </div>
 <div class="teams1_points">
<?php echo $team1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $pts1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team2; ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
 <?php echo $pts2; ?>
 </div>
 
 
 
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Basketball
</div>
 
 </div>
  <div class="clear"></div>
    <div id="teams_point_table">
  <!------------------
 <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div>
 ----------------->
 <!------------------------------
 <div class="teams_main">
 
 
 
 
 
 
 <div class="match_schedule_cricket">
 <div class="football">
 10:00
 </div>
 
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 ----------------------------->

 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 
 
 <?php
	 $q=mysql_query("select * from basketball_day ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php echo $resultdate; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $pts1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team2; ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
 <?php echo $pts2; ?>
 </div>
 
 
 
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Volly Ball
</div>
 
 </div>
  <div class="clear"></div>
 <div id="teams_point_table">
 <!---------------------------
 <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div>
 --------------------------------->
 <!---------------------------------
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="football">
 10:00
 </div>
 
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 -------------------------->

 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 
 
 
  <?php
	 $q=mysql_query("select * from vollyball_day ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
		 
	 
	 
	 ?> 
 <div class="match_schedule_cricket">
 <div class="teams_points">
<?php echo $resultdate; ?>
 </div>
 <div class="teams1_points">
<?php echo $team1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $pts1; ?>
 </div>
 <div class="teams1_points">
<?php echo $team2; ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
 <?php echo $pts2; ?>
 </div>
 
 
 
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Squash
</div>
 
 </div>
  <div class="clear"></div>
   
 <div id="teams_point_table">
 
 <!-------------------------------
 <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="football">
 10:00
 </div>
 
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 -------------------------->

 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 
 
 <?php
	 $q=mysql_query("select * from squash_day ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php   echo $resultdate;  ?>
 </div>
 <div class="teams1_points">
 <?php   echo $team1;  ?>
 </div>
 <div class="teams1_points">
 <?php   echo $pts1;  ?>
 </div>
 <div class="teams1_points">
<?php   echo $team2;  ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
 <?php   echo $pts2;  ?>
 </div>
 
 
 
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php  } ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
 
 <div class="team_cricket">
  <div class="team_cricket1">
 Badminton
</div>
 
 </div>
  <div class="clear"></div>
    
 <div id="teams_point_table">
 
 <!-----------------------------
 <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="football">
 10:00
 </div>
 
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2

 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 
------------------------------>
 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 
  <?php
	 $q=mysql_query("select * from badmintion_day ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php echo $resultdate; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $pts1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team2; ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
 <?php echo $pts2; ?>
 </div>
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php   } ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Athletics
</div>
 
 </div>
  <div class="clear"></div>
 <div id="teams_point_table">
 <!-------------------------------
 
 <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="football">
 10:00
 </div>
 
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 
-------------------------->
 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
  <?php
	 $q=mysql_query("select * from athletics_day ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		
		 
	 
	 
	 ?> 
 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php  echo $resultdate; ?>
 </div>
 <div class="teams1_points">
 <?php  echo $team1; ?>
 </div>
 <div class="teams1_points">
<?php  echo $pts1; ?>
 </div>
 <div class="teams1_points">
<?php  echo $team2; ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
 <?php  echo $pts2; ?>
 </div>
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php  }  ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Sprints
</div>
 
 </div>
  <div class="clear"></div>
   
 <div id="teams_point_table">
 <!--------------------------------
 <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="football">
 10:00
 </div>
 
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 
--------------------->
 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 
  <?php
	 $q=mysql_query("select * from sprints_day ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
		 
	 
	 
	 ?> 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php echo $resultdate; ?>
 </div>
 <div class="teams1_points">
<?php echo $team1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $pts1; ?>
 </div>
 <div class="teams1_points">
 <?php echo $team2; ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
<?php echo $pts2; ?>
 </div>
 </div>
 </div>
 <div class="clear"></div>
 </div>
 <?php } ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
 <div class="team_cricket">
  <div class="team_cricket1">
 Tug of War
</div>
 
 </div>
  <div class="clear"></div>
  
  
  
 <div id="teams_point_table">
 
 <!------------------------------------
 
 <div class="Result_bar">
 <div class="football">
 Teams
 </div>
 <div class="teams1">
 M
 </div>
 <div class="teams1">
 W
 </div>
 <div class="teams1">
 D
 </div>
 <div class="teams1">
 L
 </div>
 <div class="teams1">
 GF
 </div>
 <div class="teams1">
 GA
 </div>
 <div class="teams1">
 GD
 </div>
 <div class="teams1">
 Pts
 </div>
 </div>
 <div class="teams_main">
 <div class="match_schedule_cricket">
 <div class="football">
 10:00
 </div>
 
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="teams1">
 2
 </div>
 <div class="clear"></div>
 </div>
 
 <div class="clear"></div>
 </div>
 
--------------------->
 <div class="points_match">
 Points by match
 </div>
 <div class="clear"></div>
 <div class="Result_bar">
 <div class="teams_points">
 Result Date
 </div>
 <div class="teams1_points">
 Team
 </div>
  <div class="teams1_points">
 Pts
 </div>
 <div class="teams1_points">
 Team
 </div>
 <div class="teams1_points">
 Pts
 </div>
 </div>
 <div class="clear"></div>
 <div class="teams_main">
 
 <?php
	 $q=mysql_query("select * from tuogwar_day",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $resultdate=$q_data['result_date'];
		 $team1=$q_data['team_name1'];
		 $pts1=$q_data['pts1'];
		 $team2=$q_data['team_name2'];
		 $pts2=$q_data['pts2'];
		 
		 
	 
	 
	 ?> 
 
 
 <div class="match_schedule_cricket">
 <div class="teams_points">
 <?php    echo $resultdate;      ?>
 </div>
 <div class="teams1_points">
  <?php    echo $team1;      ?>
 </div>
 <div class="teams1_points">
  <?php    echo $pts1;      ?>
 </div>
 <div class="teams1_points">
  <?php    echo $team2;      ?>
 </div>
 <div class="teams2_points">
 <div class="teams1_points_main">
 <div class="teams1_points_text">
  <?php    echo $pts2;      ?>
 </div>
 </div>
 </div>
 <div class="clear"></div>
 </div>
 
 <?php }  ?>
 <div class="clear"></div>
 </div>
 
 
 
 <div class="clear"></div>
 </div>
  
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>


</body>
</html>
