<?php include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
<?php
	require_once ('pagination/pagination_comment.php');
?>
<link rel="stylesheet" type="text/css" href="pagination/css/webinfopediaPagination.css" />

</head>

<body>

<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php'); ?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
COMMENTS
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <?php
//$fedid=$_REQUEST['id'];
	  
	$qty = '1';		
	//this script is developed by www.webinfopedia.com..  Vist to more example files and demos.............
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$page = ($page == 0 ? 1 : $page);
	$perpage = $qty;//limit in each page
	$startpoint = ($page * $perpage) - $perpage;
	

$sql = "SELECT COUNT(feeid) from feedback where status='1'"; 

$result3 = mysql_query($sql,$con); 
$data3 = mysql_fetch_row($result3); 
$total_records = $data3[0]; 
$total_pages = ceil($total_records / $perpage);


 require_once("pagination/config1.php");
?>                



 
 <?php 
$fedid='';
$q=mysql_query("select * from feedback where status='1' LIMIT $startpoint,$perpage",$con);
while($q_data=mysql_fetch_array($q))
{
	$fedid=$q_data['feeid'];
	$sess=$q_data['session_id'];
	$dat=$q_data['dates'];
	$nam=$q_data['name'];
	$email=$q_data['email_address'];
	$sub=$q_data['subject'];
	$msg=$q_data['message'];

	
?>
 <div id="main_scedule_inner">
 
 <div class="main_bar">
 
 
 
 <div class="comments">
 Comments by <?php echo $nam;  ?>  <?php  echo $dat; ?> 
 
 </div>
 
 <div class="comments_schedule_cricket">
 <div class="schedule_programs_comments">
<?php echo $msg; ?>
 </div>
 <div class="comments">
 <?php echo $sub; ?>
 </div>
 <div class="clear"></div>
 </div>
 
 
 </div>
 
 <div class="clear"></div>
 
 </div>
 <?php  } ?>
 <div class="clear"></div>
 <div style="margin-bottom:10px">
    	        <div class="pagination" style="float:left;">
    <?php  echo Pages($perpage,"feedback_comments.php?id=$fedid&");     ?>
        </div>
        </div>



<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>

</body>
</html>
