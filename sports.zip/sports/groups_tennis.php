<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
MATCH GROUPS
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 
 <div id="main_scedule_inner">
  
 <div class="main_bar">
 <div class="parti">
 S.No
 </div>
  <div class="participants_uni">
 GROUP A
 </div>
  <div class="match_schedule_cricket">
 <div class="parti_cricket">
 1
 </div>
 <div class="schedule_programs_cricket">
 MUHAMMAD FAWAD SABIR (BSEE)
</div>
 <div class="clear"></div>
 </div>
<div class="match_schedule_cricket">
 <div class="parti_cricket">
 2
 </div>
 <div class="schedule_programs_cricket">
OWAIS AFZAL JAN (BSEE)
</div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="parti_cricket">
 3
 </div>
 <div class="schedule_programs_cricket">
 HAROON ABID (BCSE-5D)
</div>
 <div class="clear"></div>
 </div>
 </div>
 </div>
 <div id="main_scedule_inner">
  
 <div class="main_bar">
 <div class="parti">
 S.No
 </div>
  <div class="participants_uni">
 GROUP B
 </div>
  <div class="match_schedule_cricket">
 <div class="parti_cricket">
 1
 </div>
 <div class="schedule_programs_cricket">
  SHAHRUKH(BCSE-1D)
</div>
 <div class="clear"></div>
 </div>
<div class="match_schedule_cricket">
 <div class="parti_cricket">
 2
 </div>
 <div class="schedule_programs_cricket">
  ALI IRSHAD(BBA)
</div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="parti_cricket">
 3
 </div>
 <div class="schedule_programs_cricket">
  UMER HAYAT kHAN (MBA 1.5)
</div>
 <div class="clear"></div>
 </div>
 </div>
 </div>
 <div id="main_scedule_inner">
  
 <div class="main_bar">
 <div class="parti">
 S.No
 </div>
  <div class="participants_uni">
 GROUP C
 </div>
  <div class="match_schedule_cricket">
 <div class="parti_cricket">
 1
 </div>
 <div class="schedule_programs_cricket">
  USMAN BUTT(BBA-1)
</div>
 <div class="clear"></div>
 </div>
<div class="match_schedule_cricket">
 <div class="parti_cricket">
 2
 </div>
 <div class="schedule_programs_cricket">
 MUHAMMAD NABI (MASS COMM.)
</div>
 <div class="clear"></div>
 </div>
 <div class="match_schedule_cricket">
 <div class="parti_cricket">
 3
 </div>
 <div class="schedule_programs_cricket">
 ZAID NAWAZ MALIK (BBA 1)
</div>
 <div class="clear"></div>
 </div>
 </div>
 </div>
 <div id="main_scedule_inner">
  
 <div class="main_bar">
 <div class="parti">
 S.No
 </div>
  <div class="participants_uni">
 GROUP D
 </div>
  <div class="match_schedule_cricket">
 <div class="parti_cricket">
 1
 </div>
 <div class="schedule_programs_cricket">
 A.MUGHEES( BCSE-5D)
</div>
 <div class="clear"></div>
 </div>
<div class="match_schedule_cricket">
 <div class="parti_cricket">
 2
 </div>
 <div class="schedule_programs_cricket">
 AZAZ UL HAQ (BBA 1)
</div>
 <div class="clear"></div>
 </div>
 
 </div>
 </div>
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>

</body>
</html>
