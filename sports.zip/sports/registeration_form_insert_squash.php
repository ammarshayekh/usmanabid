<?php include('config.php'); ?>
<?php
$team_name=$_REQUEST['team_name'];
$program=$_REQUEST['program'];
$action=$_REQUEST['action'];
$sq_id=$_REQUEST['sqid'];
$tournament='Squash';
$batch=$_REQUEST['batch'];
$contactnumber=$_REQUEST['contactnumber'];
$player1=$_REQUEST['player1'];
$reg1=$_REQUEST['reg1'];
$player2=$_REQUEST['player2'];
$reg2=$_REQUEST['reg2'];


/*echo "Program=" .$program."<br>";
echo "Batch=" .$batch."<br>";
echo "Contact Number=" .$contactnumber."<br>";
echo "Player1=".$player1."<br>";
echo "Regiseration No1=".$reg1."<br>";*/

$date=date('d-m-Y');
if($action == 'add')
{
$insert=mysql_query("insert into squash (userid,team_name,tournament,program,batch,cnumber,player1,reg_no1,player2,reg_no2,dates,session_id) values ('$u_id','$team_name','$tournament','$program','$batch','$contactnumber','$player1','$reg1','$player2','$reg2','$date','$ses_id')",$con);

$q=mysql_query("select * from squash where session_id='$ses_id'",$con);
while($q_data=mysql_fetch_array($q))
{
	$sq_id=$q_data['sqid'];
}
$update=mysql_query("update squash set where session_id='$ses_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=report/rpt_squash.php?id=$sq_id\">";
}
if($action == 'edit')
{
	$update=mysql_query("update squash set team_name='$team_name', program='$program', batch='$batch',cnumber='$contactnumber',player1='$player1',reg_no1='$reg1',player2='$player2',reg_no2='$reg2' where sqid='$sq_id'" ,$con);
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=cp_squash.php\">";
}


?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html>