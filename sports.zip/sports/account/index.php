<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sports :: Foundation University Rawalpindi Campus </title>
<link rel="stylesheet" type="text/css" href="../css/style.css" />
<link rel="stylesheet" type="text/css" href="../css/css-menu.css"/> 
</head>

<body>

<div class="wrap">
<!-- header start here -->
<div class="header">
 <div id="logo" >
 <img src="../images/PTVSportslogo.gif" width="210" height="90"/>
 </div>
 <div id="p">
 Foundation University Rawalpindi Campus
 </div>
 <div style="width:240px; height:auto; float:left; margin-top:15px; margin-left:115px;">
 <form action="" method="post">
 <div style="width:240px; height:22px; float:left; margin-bottom:0px;">
<div style="width:80px; height:22px; float:left; color: rgb(129,129,129);"> User name:</div>
<div style="width:158px; height:22px; float:left;">
<input type="text" name="username" value="" style="border: 1px solid #C0C0C0; height:20px; padding-left:2px;" placeholder="user name" required="required" />
</div>
<div style="width:240px; height:22px; float:left; padding-top:3px;">
<div style="width:80px; height:22px; float:left;color: rgb(129,129,129);"> Password:</div>
<div style="width:158px; height:22px; float:left;">
<input type="text" name="username" value="" style="border: 1px solid #C0C0C0; height:20px; padding-left:2px;" placeholder="password" required="required"/>
</div>
</div>
<div style="width:240px; height:22px; float:left; padding-top:3px;">
<div style="width:50px; height:22px; float:left; margin-left:80px;margin-top:3px;"> <input type="submit" name="submit" value="Login" style="width:60px; height:25px; background-color:#ccc; border: 1px solid #666;" /></div>
<div style="width:55px; height:22px; float:left; margin-left:35px;margin-top:3px;"> <input type="button" value="Sign up" style="width:60px; height:25px; background-color:#ccc; border: 1px solid #666;"/></div>

</div>

<div style="clear:both"></div>

 </div>
 
 </form>
 
 </div>
<div class="clear"></div>
 
</div>
<div class="clear"></div>
<!------newsbar start----->
<div class="newsbar">

     </div>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<div class="menubar">
<div class="menu2">
    <a href="indx.html">Home</a>
    <a href="schedule.html" class="current">Schedule</a>
    <a href="participants.html">Participants</a>
    <a href="registeration.html">Registeration</a>
    <a href="ambassadors.html">Ambassdor</a>
    <a href="society.html">Society Members</a>
    <a href="result.html">Results</a>
    <a href="live.html">Live Score</a>
    <a href="contact.html">Contact</a>
    <a class="dummy"> </a>
</div>
 </div>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
CREATE ACCOUNT 
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="../css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">
 <div class="main_bar1">
 <div class="society_members_name">
  Please Provide User Name and Password to Login
 </div>
 <form action="" method="post">
 
 <div class="form1">
 
 
 <div style="width:700px; height:30px;  margin-bottom:10px; margin-left:100px; margin-top:25px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; font:Arial;">User Name:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="username" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="program" required="required" />
</div>
<div class="clear"></div>
 </div>

 <div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px; margin-top:20px;">
<div style="width:300px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px;">Password:</div>
<div style="width:300px; height:30px; float:left; padding-left:20px; text-align:left;">
<input type="text" name="username" value="" style="border:1px solid #C0C0C0; height:25px; padding-left:5px; width:250px;" placeholder="batch name" required="required" />
</div>
<div class="clear"></div>
 </div>
 
<div style="width:700px; height:30px;  margin-bottom:5px; margin-left:100px;margin-top:20px; margin-bottom:25px;">
<div style="width:100px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:320px;"> <input type="button" value="Login" style="width:105px; height:25px;"  /></div>
<div style="width:105px; height:25px; float:left; color: rgb(129,129,129); text-align:right; padding-top:5px; margin-left:15px;"> <input type="button" name="button" value="Create Account" style="width:100px; height:25px;"  /></div>
<div class="clear"></div>
 </div>
 
 </div>
 
 </form>
<div class="clear"></div>
 </div>
 <div class="clear"></div>
 
 
 
 
 <!-------------------sartmaindiv------------>
  
 <!-------------endmaindiv--------------->
 </div>
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<div class="footer">
<div class="footer1">
<div class="footer1_imges">
<div class="icon_img">
<a href="" style="cursor:pointer;">  <img src="../css/img/home.png" width="35" height="35" title="Home"/></a>
    </div>
    <div class="icon_img">
  <a href="" style="cursor:pointer;">  <img src="../css/img/fb.png" width="35" height="35" title="Facebook" /></a>
    </div>
    <div class="icon_img">
  <a href="" style="cursor:pointer;">  <img src="../css/img/twitter.png" width="35" height="35" title="Twitter" /></a>
    </div>
    <div class="icon_img">
  <a href="" style="cursor:pointer;">  <img src="../css/img/calendar_icon1.png" width="35" height="35" title="Schedule" /></a>
    </div>
 
 <div class="icon_img">
  <a href="" style="cursor:pointer;">  <img src="../css/img/cameria_icon.png" width="35" height="35" title="Photogallery"/></a>
    </div>
 <div class="icon_img">
  <a href="" style="cursor:pointer;">  <img src="../css/img/ContactusIconLarge.png" width="35" height="35" title="Contact Us" /></a>
    </div>
 <div class="icon_img">
  <a href="" style="cursor:pointer;">  <img src="../css/img/guestbook.png" width="35" height="35" title="Feedback"/></a>
    </div>
 
 </div>
 <div class="clear"></div>
</div>
<!----------footer1 end------------>
<!------footer2 start------->
<div id="footer2">
<div id="footer2_grid1">
   <div id="grid1_text">
   About Us
   </div>
   <div id="grid1_text1">
   Introduction
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!------GRID2 START--------->
<div id="footer2_grid1">
    
   <div id="grid1_text">
   Home
   </div>
   <div id="grid1_text1">
   Contact Us
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!--------GRID2END---------->
<div id="footer2_grid1">
   <div id="grid1_text">
 <a href="registeration_form_cricket.html" style=" text-decoration:none; color:#DB9900;">  Cricket</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!------GRID3 END---------->
<div id="footer2_grid1">
   <div id="grid1_text">
  <a href="registeration_form _football.html" style=" text-decoration:none; color:#DB9900;"> Football</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!---------GRID4END--------->
<div id="footer2_grid1">
   <div id="grid1_text">
  <a href="registeration_form _basketball.html" style=" text-decoration:none; color:#DB9900;"> Basketball</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!----------GRID5END--------->
<div id="footer2_grid1">
   <div id="grid1_text">
  <a href="registeration_form _table_tennis.html" style=" text-decoration:none; color:#DB9900;"> Tennis</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!----------GRID6END---------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Tug of War
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!---------------GRID7END---------->
<div id="footer2_grid1">
   <div id="grid1_text">
 <a href="registeration_form _sprints.html" style=" text-decoration:none; color:#DB9900;">  Sprints</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!-----------GRID8END------------->
<div id="footer2_grid1">
   <div id="grid1_text">
  <a href="registeration_form _volly_ball.html" style=" text-decoration:none; color:#DB9900;">Volly Ball</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!-------------grid9end----------->
<div id="footer2_grid1">
   <div id="grid1_text">
  <a href="registeration_form _athletics.html" style=" text-decoration:none; color:#DB9900;">Athletics</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!---grid10end------->
<div id="footer2_grid1">
   <div id="grid1_text">
  <a href="registeration_form _badminton.html" style=" text-decoration:none; color:#DB9900;">Badmintion</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!--------grid11end-------->
<div id="footer2_grid1">
   <div id="grid1_text">
  <a href="registeration_form _squash.html" style=" text-decoration:none; color:#DB9900;"> Squash</a>
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!--------------grid12end----------->
<div id="footer2_grid1">
   <div id="grid1_text">
   Sprints
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!--------------grid13end------------>
<div id="footer2_grid1">
   <div id="grid1_text">
   Sprints
   </div>
   <div id="grid1_text1">
   Rules
   </div>
   <div id="grid1_text1">
    Feedback
   </div>
</div>
<!----grid14end--------->
</div>
<!------footer2 end------->
<!------endbar start------->
<div class="endbar">
<div class="endbar_text">
Haji Muhammad Usman Abid
</div>
</div>
<!------endbar close------->
</div>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>








</body>
</html>
