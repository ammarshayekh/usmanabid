<div class="menubar">
<div class="menu2">
    <a href="index.php">Home</a>
    <a href="schedule.php">Schedule</a>
    <a href="participants.php">Viedo</a>
    <a href="registeration.php">Registration</a>
    <a href="#">Event</a>
    <a href="society.php">Society Members</a>
    <a href="result.php">Results</a>
    <a href="live.php">Live Score</a>
    <a href="contact.php">Coordinator</a>
    <a class="dummy"> </a>
</div>
 </div>