<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
GAME RULES
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">

 
 
 
 
 
 <div class="comments_schedule_cricket">
 <div class="schedule_programs_comments" >
<img src="images/download.jpg" width="300" height="225" style="margin:5px;"/><br />
<b>Badmintion Rules</b><br />
1.TOSS shall be conducted before game starts. One who wins can choose between serving first or to start play at either end of the court. Your opponent can then exercise the remaining choice.<br />
2.The rules of badminton states that a badminton match shall consist of the best of 3 games.<br />
3.The first side to score 10 points wins the game.<br />
4.If the score becomes 10 all, the side which first scored 2 Extra points will win the game..<br />
5.The side winning a game serves first in the next game.<br />
6.You shall serve from, and receive in, the right service court when you or your opponent has scored an even number of points in that game.<br />
7.You shall serve from, and receive in, the left service court when you or your opponent has scored an odd number of points in that game.<br />
8.You and your opponent will hit the shuttle alternately until a 'fault' is made or the shuttle ceases to be in play.<br />
9.A let may be given for any unforeseen or accidental occurrences. <br />
<b>The rules of badminton consider the following as faults:</b><br />
 1.If the shuttle lands outside the boundaries of the court, passes through or under the net, fail to pass the net, touches the ceiling or side walls, touches the person or dress of a player or touches any other object or person.<br />
2.If the initial point of contact with the shuttle is not on the striker's side of the net. (The striker may, however, follow the shuttle over the net with the racket in the course of a stroke.)<br />
 3.If a player touches the net or its supports with racket, person or dress, invades an opponent's court over the net with racket or person except as permitted.<br />
4.If a player invades an opponent's court under the net with racket or person such that an opponent is obstructed or distracted or obstructs an opponent, that is prevents an opponent from making a legal stroke where the shuttle is followed over the net.<br />
5.If a player deliberately distracts an opponent by any action such as shouting or making gestures.<br />
6.If the shuttle is caught and held on the racket and then slung during the execution of a stroke.<br />
7.If the shuttle is hit twice in succession by the same player with two strokes.<br />
8.If the shuttle is hit by a player and the player's partner successively or touches a player's racket and continues towards the back of that player's court.<br />
9.If, on service, the shuttle is caught on the net and remains suspended on top, or, on service, after passing over the net is caught in the net.
<br />
10.Shirts for Engineering department will be (Blue), Social Sciences (White) and for Management will be (black). 
 </div>
 
 <div class="clear"></div>
 </div>
 
 
 
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>
</body>
</html>
