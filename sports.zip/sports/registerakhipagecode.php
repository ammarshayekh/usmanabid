<?php include('config.php'); 
include("ip.php");
//$came_from = $_SERVER['HTTP_REFERER'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php'); ?>
<?php include('ip-country.php'); ?>
</head>
<body>

<?php include('header.php'); ?>


<!--UserBar !-->
<!--End UserBar !-->
<table align="center" cellpadding="0" cellspacing="0" class="c-table">
<tr><td align="left" class="c-td">
	<?php		
if (!isset ($_POST['submit']))
	{
		
	if(isset($_GET['s'])) 
	{
    $error = $_GET['s'];
	} else 
	{
    $error = '0';
	}
	}//$error=$_GET['s'];	
		?>
        
  

	<table cellpadding="0" cellspacing="0" class="ci-top-table">
	<tr>
	<td align="left" style="vertical-align:middle;padding-left:10px;">Create  Account</td>
	<td align="right" style="vertical-align:middle;padding-right:10px;">
	<div style="float:right;">
	<a href="login.php" class="button-mini">LOGIN</a>
	</div>
	<div style="float:right;font:11px/24px Verdana,sans-serif;color:#444;padding-right:8px; color:#fff;"><!--Already a member?--></div>
	</td>
	</tr>
	</table>
    
 <?php
if(isset($_POST['submit']))
 {
	 
$name = $_POST['fullname'];
$email = $_POST['email'];
$user = $_POST['username'];
$pwd = $_POST['password'];
$year = $_POST['year'];
$refer = $_POST['refer'];
$tos = $_POST['tos']; 

$len_name=strlen($name);
$len_email=strlen($email);
$len_user=strlen($user);
$len_pwd=strlen($pwd);
$len_year=strlen($year);
$len_refer=strlen($refer);


$error=0;

if($len_name > 30 || $len_user > 15|| $len_pwd > 15 || $len_email > 50 || $len_year > 4 || $len_refer > 15 )
{
$error = 1;
$error_txt = 'Invalid Username or Password';	
}
if($len_name < 1 || $len_user < 1|| $len_pwd < 1 || $len_email < 1 || $len_year < 1 )
{
$error = 1;
$error_txt = '* All the fields are required.';	
}

if($tos == 'no')
{
$error = 1;
$error_txt = 'You must agree our Terms of Services agrement for registering new account.';	
}

if($error == 0)
{
if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) 
{
  $error=0;
} else {
$error = 1;
$error_txt = 'Invalid E-Mail address.';
  }
}
 
 /* 
if (!filter_var($year, FILTER_VALIDATE_INT) === false) 
{
  $error=0;
} else {
$error = 1;
$error_txt = 'Invalid Input. Please enter correct year.';
  }  
*/
if($error == 0)
{
$q1 = mysql_query("select * from tb_users where username = '$user'",$con);
$Username = 'abc';
	while($data1 = mysql_fetch_array($q1))
		{
		$Username = $data1['username'];
		}
	if($Username == $user)
	{
	$error = 1;
	$error_txt = 'Username already exist. Please choose another.';	
	}
}

if($error == 0)
{
$q2 = mysql_query("select * from tb_users where email = '$email'",$con);
$Email = 'abc';
	while($data2 = mysql_fetch_array($q2))
		{
		$Email = $data2['email'];
		}
	if($Email == $email)
	{
	$error = 1;
	$error_txt = 'E-mail already exist. Please choose another.';	
	}
}



if($error == 0)
{
$date= date('d-m-Y');
$account='Premium';
$ip=getRealIP();

$insert = mysql_query("insert into tb_users (fullname,username,password,email,referer,country,country_code,joindate,signupip,user_status,account,birth_year,v_code,vr_status) values ('$name','$user','$pwd','$email','$refer','$country','$country_code','$date','$ip','user','$account','$year','auto verify','verified')",$con);

$q1=mysql_query("select * from tb_users where username = '$user'",$con);
while($q_data1=mysql_fetch_array($q1))
	{
	$uzer_id = $q_data1['id'];
	$uzer_name = $q_data1['username'];		
	}
	
$plan_days=30;
$plan_detail='Premium';
$planid=1;
$start_date= date('d-m-Y');
$next = mktime(0, 0, 0, date("m"), date("d")+ $plan_days, date("y"));
$expire_on = date("d-m-Y", $next); 

$ins = mysql_query("insert into tb_user_membership (userid,plan_id,plan_detail,start_date,end_date,expir_after,status) values ('$uzer_id', '$planid', '$plan_detail', '$start_date','$expire_on','$plan_days','1')",$con);
	
$insert = mysql_query("insert into frm_avatar (userid,avatar,show_stats) values ('$uzer_id','./img/avatar.png','0')",$con);	

$history_desc='You registered at SoneXClix';
$history = mysql_query("insert into tb_history (userid,type,description) values ('$uzer_id','Registration','$history_desc')",$con);	

if($refer !='')
{
$q=mysql_query("select * from tb_users where username = '$refer'",$con);
while($q_data=mysql_fetch_array($q))
	{
	$refered_u_id = $q_data['id'];
	$refer_account = $q_data['account'];	
	$user_status = $q_data['user_status'];		
	}
if($refer_account == 'Standard')
{
	$limit_ref = 100;
}
if($refer_account == 'Premium')
{
	$limit_ref = 150;
}
if($refer_account == 'Golden')
{
	$limit_ref = 200;
}
if($refer_account == 'Ultimate')
{
	$limit_ref = 4000;
}

// total direct referrals					
					$sql = "SELECT COUNT(refer_id) from tb_direct_referrals where refer_id = '$refered_u_id'"; 
					$result3 = mysql_query($sql,$con); 
					$data3 = mysql_fetch_row($result3); 
					$t_dir_ref = $data3[0];

$q_dir=mysql_query("select * from tb_contest where userid = '$refered_u_id'",$con);
$ref_qty='';
				while($q_dir_data=mysql_fetch_array($q_dir))
					{
					$ref_qty = 	$q_dir_data['ref_qty'];
					}

if($t_dir_ref < $limit_ref)
{					
$ins= mysql_query("insert into tb_direct_referrals (refer_id,user_id,user_name,country,refer_since,reg_ip_address,came_from) values ('$refered_u_id','$uzer_id','$uzer_name','$country','$date','$ip','$came_from')",$con);	

// contest data start
if($ref_qty == '')
{
$insert = mysql_query("insert into tb_contest (userid,username,ref_qty) values ('$refered_u_id','$refered_u_name','1')",$con);	
}
if($ref_qty != '')
{
$update = mysql_query("update tb_contest set ref_qty= '$ref_qty' + 1 where userid = '$refered_u_id'",$con);	
}


$history_desc='You have got one new direct referral '."<b>".$uzer_name."</b>";
$history = mysql_query("insert into tb_history (userid,type,description) values ('$refered_u_id','Direct Referrals','$history_desc')",$con);	


}
}
	
$error = 2;
}

// echo $tos;
// echo $error;

if($error == 1)
{
?>
<div class="error_box" style=" text-align:justify; margin-top:5px; margin-bottom:5px;">
<?php echo $error_txt; ?>
</div>
<?php	
}

if($error == 2)
{
?>
<div class="success_box" style=" text-align:justify; margin-top:5px; margin-bottom:5px;">
Your account created successfully. Login to start work.
</div>
<?php	

}

	 
 }
 ?>   
<!--    	
<div class="error_box" style=" text-align:justify; margin-top:5px; margin-bottom:5px;">
Invalid Image Verification
</div>	
-->
	<table cellpadding="0" cellspacing="0" class="ci-bottom-table">
	<tr>
    <td align="center" class="ci-inside-td" >
		
		<form id="form1" action="register.php" method="post">

		<table align="center" cellpadding="0" cellspacing="10" class="ci-box" style=" width:360px;">
       
        <tr>
        <td align="center"><img src="images/newuserregistration.png" /></td>
        </tr>
        
        <tr>
        <td>Fullname</td>
        </tr>
        <tr>
			
            <td align="left" style="padding:0px 10px;">
			<input type="text" value="" id="fullname" name="fullname"  required="required"  spellcheck="false"  style="width: 280px;">
			</td>
		</tr>
        <tr>
        <td>Username</td>
        </tr>
				<tr>
			
            <td align="left" style="padding:0px 10px;">
			<input type="text" value="" id="username" name="username" required="required"  spellcheck="false"  style="width: 280px;">
			</td>
		</tr>
		<tr>
        <td>E-Mail Address</td>
        </tr>
		<tr>
			
            <td align="left" style="padding:0px 10px;">
			<input type="text" value="" id="email" name="email" required="required" spellcheck="false"  style="width: 280px;">
			</td>
		</tr>
        <tr>
        <td>Password</td>
        </tr>
		<tr>
			
            <td align="left" style="padding:0px 10px;">
			<input type="password" value="" id="password" name="password" required="required" style="width: 280px;">
			</td>
		</tr>
		
		
		
		<tr>
        <td>Birth year</td>
        </tr>
		<tr>
			
            <td align="left" style="padding:0px 10px;">
			<input type="text" value="" id="year" name="year" maxlength="4" required="required" style="width:150px;" placeholder="YYYY">
			</td>
		</tr>
        
       
        
          <?php
$r= $_SESSION['ref'];
	?>
     <tr>
     <td>Referrer</td>
     </tr>
        <tr>
			
            <td align="left" style="padding:0px 10px;">
			<input type="text" value="<?php echo $r; ?>" id="refer" name="refer" maxlength="15" spellcheck="false" placeholder="optional" readonly="readonly" style="width: 280px;">
			</td>
		</tr>
        
         <tr>
     <td>Do you agree our term of services?</td>
     </tr>
        <tr>
			
            <td align="left" style="padding:0px 10px;">
			<select name="tos" style="width:150px; border:1px solid #C0C0C0; padding:5px;">
            <option value="yes"> Yes </option>
            <option value="no"> No</option>
            </select>
			</td>
		</tr>
        
    <!--
    <tr>
        <td align="left" style="padding:0px 10px;"><div style="float:left; margin-top:20px;"><img src="CaptchaSecurityImages.php?width=120&height=25&characters=6" /></div><div style="float:left; margin-top:20px;"><input type="text" value=""  name="sc" style="width:135px;" placeholder="Enter Captcha" required="required" ></div> <div style="clear:both;"></div></td>
        </tr> 
      --> 
			
		<tr>
			<td style="padding-left:10px; padding-top:20px;">
			<input type="submit" name="submit" value="CREATE MY ACCOUNT" style="width:290px;" class="button-submit">
			</td>
		</tr>
        
		</table>
		</form>
						
 

						
	</td>
    </tr>
    </table>
    
</td></tr>
</table>

	
<?php include('footer.php'); ?>

</body>
</html>
