<?php include('config.php'); ?>
<?php
$program=$_REQUEST['program'];
$batch=$_REQUEST['batch'];
$contactnumber=$_REQUEST['contactnumber'];
$name=$_REQUEST['name'];
$regno=$_REQUEST['regno'];


echo "Program=" .$program."<br>";
echo "Batch=" .$batch."<br>";
echo "Contact Number=" .$contactnumber."<br>";
echo "Name=".$name."<br>";
echo "Regiseration No=".$regno."<br>";
?>
<html>
<head>
<title> </title>
</head>
<body>
<div style="width:200px; height:100px; margin-left:550px; margin-top:300px;">
<img src="images/preloader.gif" width="40" height="40" />
</div>
</body>
</html