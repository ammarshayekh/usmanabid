<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>


<div class="wrap">
<!-- header start here -->
<?php include('header.php');?>
<!------newsbar start----->
<?php include('newsbar.php');?>

<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!-----------start banner------->
<div id="banner">
<div id="sliderFrame">
        <div id="slider">
            <img src="Services/17211799_725269874320212_5444312531312582827_o.jpg" width="995" height="350" />
            <img src="Services/17240042_725269120986954_7081669253878470624_o.jpg" width="995" height="350" />
             <img src="Services/17353215_726454894201710_4098821178648052866_n.jpg" width="995" height="350" />
               <img src="Services/22519860_385779641840323_8894076461947893883_o.jpg" width="995" height="350" />
             
        </div>
        <!--Custom navigation buttons on both sides-->
        <div class="group1-Wrapper">
            <a onClick="imageSlider.previous()" class="group1-Prev"></a>
            <a onClick="imageSlider.next()" class="group1-Next"></a>
        </div>
        <!--nav bar-->
		
        <div style="text-align:center;padding:20px;z-index:20;">
            <a onClick="imageSlider.previous()" class="group2-Prev"></a>
            <a id='auto' onClick="switchAutoAdvance()"></a>
            <a onClick="imageSlider.next()" class="group2-Next"></a>
        </div>
    </div>
</div>
<!------------end banner-------->
<!------------main start---------->
<div id="main">
<div class="news">
LATEST NEWS
<img border="0" src="css/img/endbar.jpg" width="56" height="3">
</div>
<div id="newss">
TODAY ON SPORTS
<img border="0" src="css/img/endbar.jpg" width="56" height="3">
</div>

<!-----------inner main start------>

<div class="contain">
<!------main_contain start------->

<div class="main_contain" style="color: #00F;">
<marquee direction="left"scrolldelay="1" scrollamount="2" onMouseOver="this.stop();this.style.cursor='default';" onMouseOut="this.start();this.style.cursor='default';">
  <?php

 $q=mysql_query("select * from latest_news where status='1'",$con);
 while($q_data=mysql_fetch_array($q))
 {
	 //$name=$q_data['game_name'];
	 $new=$q_data['text'];
 
?>

  <div style="width:640px; height:auto; color:#00F;">
     <?php echo $new;?>
  </div>
  <?php } ?>
  </marquee>
<a href=""><h1 style="color:red;">POINTS TABLE</h1></a>
  </div>
  
  <!------main_contain end------->
  <!-------news_container1 start---->
  <!------
  <div id="news_container1">
   <div id="news_container1_img">
<img src="images/cricket.jpg" width="340" height="302" />
</div>
</div>
---------------->
<!----------news_container1 end------>
<!---------news_container2 start----->
<div id="news_container2">

<marquee direction="up"scrolldelay="1" scrollamount="2" onMouseOver="this.stop();this.style.cursor='default';" onMouseOut="this.start();this.style.cursor='default';">
<div class="news_container2_p">
<?php

 $q=mysql_query("select * from today_sports where status='1'",$con);
 while($q_data=mysql_fetch_array($q))
 {
	 $name=$q_data['game_name'];
	 $new=$q_data['news'];
 
?>
<?php echo $name; ?><br />
 <?php echo $new; ?>
  <br/>
 <?php
 }
 ?> 
 
 </div>
 </marquee>
 
</div>
<!---------news_container2 end------->
 </div>
 <!-----------inner main end-------->
 <!-----------banner start------------>
 <?php
$q=mysql_query("select * from banner_furc",$con);
 while($q_data=mysql_fetch_array($q))
 {
 //$name=$q_data['game_name'];
 $proof=$q_data['proof'];
 
 }
 
 ?>
 <div id="fixbanner">
 <img src="admin/<?php echo $proof; ?>" width="960" height="200" />
 </div>
 <!------------banner close----------->
 <!------------news_programs start--------->
 <div class="news_programs">
 <div id="news_text">
 PROGRAMMES ON FURC SPORTS
 </div>
 <img  style=" margin-left:895px; margin-top:12px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 
 <!-------------news_programs end-------->
 <!-----------program start----------->
 <div class="programs_main">
<marquee direction="left"scrolldelay="1" scrollamount="2" onMouseOver="this.stop();this.style.cursor='default';" onMouseOut="this.start();this.style.cursor='default';">
<?php
$q=mysql_query("select * from programs_furc",$con);
 while($q_data=mysql_fetch_array($q))
 {
 //$name=$q_data['game_name'];
 $proof=$q_data['proof'];
 
  
 
 ?>
 <div id="program">
 <img style="border:3px solid rgb(236,236,236);  padding-left:5px; padding-right:5px; padding-top:5px; padding-bottom:5px; margin-left:10px; margin-top:10px; margin-right:10px; margin-bottom:10px;" src="admin/<?php echo $proof; ?>" width="210" height="175" />
 </div>
 <?php } ?>
 </marquee>
 </div>
 <div class="clear"></div>
 <!-----------program close----------->
 <!------------------------------------------
<div class="videos_programs">
 <div id="news_text">
  FEATURED VIDEOS
 </div>
 <img  style=" margin-left:895px; margin-top:12px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div class="programs_videos_main">
 <div id="program_videos">
 <img style="border:3px solid rgb(236,236,236);  padding-left:5px; padding-right:5px; padding-top:5px; padding-bottom:5px; margin-left:10px; margin-top:10px; margin-right:10px; margin-bottom:10px;" src="images/images.jpg" width="210" height="175" />
 </div>
 <div id="program">
 <img style="border:3px solid rgb(236,236,236);  padding-left:5px; padding-right:5px; padding-top:5px; padding-bottom:5px; margin-left:10px; margin-top:10px; margin-right:10px; margin-bottom:10px;" src="images/football.jpg" width="210" height="175" />
 </div>
 <div id="program">
 <img style="border:3px solid rgb(236,236,236);  padding-left:5px; padding-right:5px; padding-top:5px; padding-bottom:5px; margin-left:10px; margin-top:10px; margin-right:10px; margin-bottom:10px;" src="images/table1.jpg" width="210" height="175" />
 </div>
 <div id="program">
 <img style="border:3px solid rgb(236,236,236);  padding-left:5px; padding-right:5px; padding-top:5px; padding-bottom:5px; margin-left:10px; margin-top:10px; margin-right:10px; margin-bottom:10px;" src="images/basketbal.jpg" width="220" height="175" />
 </div>
 
 </div>
 
 
</div>
<div class="clear"></div>
--------------------->
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>

</body>
</html>
