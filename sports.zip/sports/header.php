
<div class="header">
 <div id="logo" >
 <img src="images/complete2.gif" width="210" height="90"/>
 </div>
 <div id="p">
 Foundation University Rawalpindi Campus
 </div>
 
 <!----------start form------------->
 <?php
 if($session_id != $ses_id )
 {
 
 
 ?>
 <div style="width:240px; height:auto; float:left; margin-top:15px; margin-left:115px;">
 <form action="login_check_insert.php" method="post">
 <div style="width:240px; height:22px; float:left; margin-bottom:0px;">
<div style="width:80px; height:22px; float:left; color: rgb(129,129,129); font-weight:bold;"> User name:</div>
<div style="width:158px; height:22px; float:left;">
<input type="text" name="username" value="" style="border: 1px solid #C0C0C0; height:20px; padding-left:2px;" placeholder="user name" required="required"/>
</div>
<div style="width:240px; height:22px; float:left; padding-top:3px;">
<div style="width:80px; height:22px; float:left;color: rgb(129,129,129); font-weight:bold;"> Password:</div>
<div style="width:158px; height:22px; float:left;">
<input type="password" name="password" value="" style="border: 1px solid #C0C0C0; height:20px; padding-left:2px;" placeholder="password" required="required"/>
</div>
</div>
<div style="width:240px; height:22px; float:left; padding-top:3px;">
<div style="width:50px; height:22px; float:left; margin-left:80px;margin-top:3px;font-size:16px;"> <input type="submit" name="submit" value="Login" style="width:60px; height:25px; background-color:#ccc; border: 1px solid #666;font-size:14px;" /></div>


<div style="width:55px; height:23px; float:left; margin-left:15px;margin-top:3px; background-color:#ccc; border: 1px solid #666;text-align:center; font-size:16px;"> <a href="signup.php" style="color:#999; color:#000; ">Signup</a></div>

</div>

<div style="clear:both"></div>

 </div>
 
 </form>
 
 </div>
 <?php
 }
 if($session_id == $ses_id)
 {
 ?>
 
 <div style="width:135px; height:auto; float:left; margin-top:70px; margin-left:230px;">
 <div style="width:75px; height:20px; float:left; text-align:right;">
 <a style="color:#FF0000;font:  bold 14px Arial;" href="cpanel.php"> My deatail</a>
 </div>
 <div style="width:55px; height:20px; float:left; padding-left:5px;">
 <a style="color:#FF0000;font:  bold 14px Arial;" href="logout.php"> Logout</a>
 </div>
 <div style="clear:both"></div>
 </div>
 <?php } ?>
 <!----------end form------------->
 
<div class="clear"></div>
 
</div>