<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('meta_tag.php');?>
</head>

<body>
<script language=JavaScript> var message="Rights Reserved by FURC Sports Society"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
<div class="wrap">
<!-- header start here -->
<?php include('header.php'); ?>
<div class="clear"></div>
<!------newsbar start----->
<?php include('newsbar.php');?>
<!------newsbar close----->
<!-- header close here -->

<!-- menu start -->
<?php include('menu.php');?>
<!-- menu end -->
<!------------main start---------->
<div id="main_scedule">
<div class="scedule_programs">
 <div id="scedule_text">
GAME RULES
 </div>
 <img  style=" margin-left:908px; margin-top:8px; "border="0" src="css/img/endbar.jpg" width="56" height="3">
 </div>
 <div id="main_scedule_inner">

 
 
 
 
 
 <div class="comments_schedule_cricket">
 <div class="schedule_programs_comments" >
<img src="images/images2.jpg" width="300" height="225" style="margin:5px;"/>
Flat Race:
60m distance to be covered
Maintain your own track
Hitting  an opponent or changing your track means you are disqualify

  3 Leg Race:
60m distance to be covered
Participants with loosing sashes will be disqualified
Support irrespective of your partner will lead to disqualification
Distracting opponents is not allowed

Spoon Race:
60m distance to be covered
Balance a lemon with a tea spoon
spoon will be balanced with teeth only Any kind of support is not allowed
Falling lemon will lead to disqualification
Distracting opponents is not allowed

Chatty Race:
60m distance to be covered
Balance a chatty on your head without any support
Falling chatty will lead to disqualification
Maintain your track
Distracting opponents is not allowed

Skipping Race:
60m distance to be covered.
Single leg race.
In case, the competitor steps over the rope, they are disqualified.
Hitting  an opponent or changing your track means you are disqualify.

Tug of War:
Final participants will split into teams
Support of any object or unregistered person will lead to disqualification
Team losing the rope will be disqualified
Team crossing or touching the partitioning line will lose
Hitting an opponent is not allowed

 </div>
 
 <div class="clear"></div>
 </div>
 
 
 
 
 <div class="clear"></div>
 </div>
<div class="clear"></div>
<!-----------main close---------->
<!----------footer start------------>
<!----------footer1 start------------>
<?php include('footer.php');?>



<!---------footer close----------->
<div class="clear"></div>
<!-----------footer2 end----------->
</div>
</div>
</body>
</html>
