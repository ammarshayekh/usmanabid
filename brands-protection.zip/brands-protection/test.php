<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<form data-abide="ajax" id="order_form">
        <input type="alpha"  id="fName" name="fName" required>
<input type="alpha"  id="lName" name="lName" required>
<input type="alpha"  id="email" name="email" required>

<input type="submit" value="Submit" name="submit">
</form>

<div id="message"></div> // here i want to display the confirmation message

            


 <script type="text/javascript">

      $(document).ready(function() {
        
        $("#order_form").submit(function(){

             
            $.ajax({
              url: 'haal/order',
              type: 'POST',
              data:$('#order_form').serialize(),
              success: function(data) {
                    if(data == 'OK') {
                        console.log("ok");
                        $('#message').html('<p>Thank you for your order.</p>');
                   } else { $('#message').html('<p>There is something wrong with form submission.</p>'); }
              }
            });

        });
      });  
   </script>
</body>
</html>