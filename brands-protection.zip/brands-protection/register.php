 <?php
include("config.php");
$name=''; $email='';  $number='';  $address=''; $comname=''; $cmaill='';

   if(isset($_POST['name']) && !empty($_POST['name']) AND isset($_POST['address']) && !empty($_POST['address']) AND isset($_POST['email']) && !empty($_POST['email']) AND isset($_POST['password']) && !empty($_POST['password']) AND isset($_POST['number']) && !empty($_POST['number'])){
    $name = mysql_escape_string($_POST['name']); // Turn our post into a local variable
    $address = mysql_escape_string($_POST['address']); // Turn our post into a local variable
	 $email = mysql_escape_string($_POST['email']); // Turn our post into a local variable
	  $password = mysql_escape_string($_POST['password']); // Turn our post into a local variable
	   $number = mysql_escape_string($_POST['number']); // Turn our post into a local variable
	  // echo  $password;
	     $qq1=mysql_query("select * from companyregistration where cname='$name'",$con);
	 while($qq1_data=mysql_fetch_array($qq1))
	 {
		 
		$comname=$qq1_data['cname'];
		
		
	 }
	 
	 if($comname == $name)
	   {
		   echo "<script>alert('Company Name is Already exit.Please Try Again!');</script>";
		   //echo "Company Name is Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   echo "<meta http-equiv=\"refresh\" content=\"0;URL=register.php\">";
		   exit();
	   }
	   
	     $qq11=mysql_query("select * from companyregistration where cmail='$email'",$con);
	 while($qq11_data=mysql_fetch_array($qq11))
	 {
		 
		
		$cmaill=$qq11_data['cmail'];
		
	 }
	   if($cmaill == $email)
	   {
		    echo "<script>alert('Email Address Already exit.Please Try Again!');</script>";
		   //echo "Email Address Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   echo "<meta http-equiv=\"refresh\" content=\"0;URL=register.php\">";
		     exit();
	   }
	   
	   mysql_query("insert into companyregistration(cname,ccontact,address,cmail,password,session_id) values ('$name','$number','$address','$email','$password','$ses_id')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('You are Successfully Registered!');</script>";
 
//echo "Successfully Submitted";
}




             
?>
<!DOCTYPE html>
<html>
<head>
<title>Brands Protection | Registeration</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Eshop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- cart -->
	<script src="js/simpleCart.min.js"> </script>
<!-- cart -->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

</head>
<body>

	<!-- header-section-starts -->
	<div class="header">
		<div class="header-top-strip">
			<div class="container">
				<div class="header-top-left">
					<ul>
						<li><a href="login.php"><span class="glyphicon glyphicon-user"> </span>Login</a></li>
						<li><a href="register.php"><span class="glyphicon glyphicon-lock"> </span>Create an Account</a></li>			
					</ul>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<div class="inner-banner">
		<div class="container">
			<div class="banner-top inner-head">
				<nav class="navbar navbar-default" role="navigation">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
				<div class="logo">
					<h1><a href="index.html"><span>B</span> -rands</a></h1>
				</div>
	    </div>
	    <!--/.navbar-header-->
	
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	        <?php include("menu.php"); ?>
	    </div>
	    <!--/.navbar-collapse-->
	</nav>
	<!--/.navbar-->
</div>
	</div>
		</div>
		<!-- registration-form -->
<div class="registration-form">
	<div class="container">
	
		<h2>Registration</h2>
		<div class="registration-grids">
			<div class="reg-form">
				<div class="reg">
					 <p style="color:#000;">Welcome, please enter the following details to register your company.</p>
					 <p style="color:#000;">If you have previously registered with us, <a href="login.php">click here</a></p>
                     
					 <form  action="" method="post">
						 <ul>
							 <li class="text-info"> Company Name: </li>
							 <li><input type="text" value="" name="name" required></li>
						 </ul>
						 <ul>
							 <li class="text-info">Address : </li>
							 <li><input type="text" value="" name="address" required></li>
						 </ul>				 
						<ul>
							 <li class="text-info">Email: </li>
							 <li><input type="text" value="" name="email" required></li>
						 </ul>
						 <ul>
							 <li class="text-info">Password: </li>
							 <li><input type="password" value="" name="password" required></li>
						 </ul>
						
						 <ul>
							 <li class="text-info">Mobile Number:</li>
							 <li><input type="text" value="" name="number" required></li>
						 </ul>						
						 <input type="submit" value="REGISTER NOW">
						  
					 </form>
				 </div>
			</div>
			<div class="reg-right">
				 <h3><em>Company Registration</em></h3>
				 <div class="strip" style="text-justify:inter-word; text-align:justify">
				   <p style="color:#000;"><em><em><em>Companies will register with Brands Protection  System to save their brands from counterfeiting issues. Brands protection  system will provide end-to-end solutions that enable an enterprise to both  establish and defend their brands against multiple risks of counterfeiting. It  will generate revenue for company by resolving counterfeiting issues against  many fake agents, who are involved in such kind of acts. Brands protection  system provides a complete mechanism to deal with it.</em></em></em></p>
				 </div>
<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- registration-form -->

		
		<div class="footer">
		<div class="container">
		 <div class="footer_top">
			
		  </div>
		  
		  <div class="copyright text-center">
				<p>© 2016. All Rights Reserved | Designed by   <a href="#">  Brands Protection</a></p>
		  </div>
		</div>
		</div>
</body>
</html>