 <?php
include("config.php");
$cname=''; $location='';  $number='';  $code='';

   if(isset($_POST['cname']) && !empty($_POST['cname']) AND isset($_POST['location']) && !empty($_POST['location']) AND isset($_POST['number']) && !empty($_POST['number']) AND isset($_POST['code']) && !empty($_POST['code'])){
    $cname = mysql_escape_string($_POST['cname']); // Turn our post into a local variable
    $location = mysql_escape_string($_POST['location']); // Turn our post into a local variable
	 $number = mysql_escape_string($_POST['number']); // Turn our post into a local variable
	  $code = mysql_escape_string($_POST['code']); // Turn our post into a local variable
	  
	   $q=mysql_query("select * from productverification where uniquecode = '$code'",$con);
	
		 $productname='';
		 $manfdate='';$expdate='';
		 $uniquecode='';
		 $status='';
	 while($q1_data=mysql_fetch_array($q))
	 {
		 $productname=$q1_data['productname'];
		  $manfdate=$q1_data['manfdate'];
		   $expdate=$q1_data['expdate'];
		   //$cellno=$q_data['cellno'];
		    $uniquecode=$q1_data['uniquecode'];
			$status=$q1_data['status'];
	 }
	 $date=date('Y-m-d');
	  if ($status == 1) {
    echo "<script>alert('Product is Already Verified!');</script>";
} 
	 else if( $code == $uniquecode)
	 {
		 echo "<script>alert('Product Name=$productname Manufacture Date=$manfdate Expiry Date=$expdate');</script>";
   /*echo "product Name=".$productname."<br/>";
	 echo "Manufacture Date=".$manfdate."<br/>";
	 echo "Expiry Date=".$expdate."<br/>";*/
	 
	 $update=mysql_query("update productverification set verificationdate='$date',location='$location',cellno='$number',status='1' where uniquecode='$code'",$con);
	//echo "<meta http-equiv=\"refresh\" content=\"0;URL=all_games_show.php\">";
		 
	 }
	 else
	 {
		   mysql_query("insert into counterfitarea(uniquecode,location,cellno) values ('$code','$location','$number')",$con);
		   echo "<script>alert('Product is not Genuin!');</script>";
		
	 }
	 /////////////code verification///////////////
	 $result=mysql_query("SELECT verificationdate FROM productverification",$con);
//echo $result;
//$verificationdate=$q_data['verificationdate'];

$q_data=mysql_fetch_array($result);

	
	//echo $q_data['verificationdate'];
	$myDate = $q_data['verificationdate'];
	$count = 0;
	$query = mysql_query("SELECT verificationdate FROM productverification",$con);
	//mysql_query('TRUNCATE TABLE graph',$con);
	while($row = mysql_fetch_array($query)){
		
		if($myDate == $row['verificationdate']){
			$count++;
		}
		else{
			
			$i = mysql_query("insert into graph(category,value,companyid) VALUES('$myDate','$count','$cname')",$con);
			//echo "Different Value";
			$count=0;
			$myDate = $row['verificationdate'];
			$count++;
		}
		
	
	}
}




             
?>
<!DOCTYPE html>
<html>

<head>
<title>Brands Protection | Feedback</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Eshop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- cart -->
	<script src="js/simpleCart.min.js"> </script>
<!-- cart -->

<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
</head>
<body>
	<!-- header-section-starts -->
	<div class="header">
		<div class="header-top-strip">
			<div class="container">
				<div class="header-top-left">
					<ul>
						<li><a href="login.php"><span class="glyphicon glyphicon-user"> </span>Login</a></li>
						<li><a href="register.php"><span class="glyphicon glyphicon-lock"> </span>Create an Account</a></li>			
					</ul>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<div class="inner-banner">
		<div class="container">
			<div class="banner-top inner-head">
				<nav class="navbar navbar-default" role="navigation">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
				<div class="logo">
					<h1><a href="index.php"><span>B</span> -rands</a></h1>
				</div>
	    </div>
	    <!--/.navbar-header-->
	
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	         <?php include("menu.php"); ?>
	    </div>
	    <!--/.navbar-collapse-->
	</nav>
	<!--/.navbar-->
</div>
	</div>
		</div>
		
<!-- contact-page -->
<div class="contact">
	<div class="container">
	
		
		
		<div class="contact-form">
			<div class="contact-info">
				<h3>Code Verification</h3>
			</div>
            
			<form action="" method="post">
            
				<div class="contact-left" style="margin-left:400px;">
                <select name="cname">
                  <option selected>Select Company Name</option>
				<?php 
                                  $q=mysql_query("select * from companyregistration",$con);

                                  while($q_data=mysql_fetch_array($q))
                                  {
	
	
	                                     $cname=$q_data['cname'];
										  $cid=$q_data['cid'];

	
                               

                                     ?>
                                  <option value="<?php echo $cid;?>"><?php echo $cname;?></option>
                                 <?php } ?>
                </select>
                 
					<input type="text" placeholder="Location" name="location" required>
					
                    <input type="text" placeholder="Mobile Number" name="number" required>
					<input type="text" placeholder="Code" name="code" required>
				</div>
				
				<div class="clearfix"></div>
				<input type="submit" value="Search" style="margin-left:400px;">
			</form>
		</div>
	</div>
</div>
<!-- //contact-page -->

		
		<div class="footer">
		<div class="container">
		 <div class="footer_top">
			<div class="span_of_4">
				
				
				
				
				<div class="clearfix"></div>
				</div>
		  </div>
		  
		  <div class="copyright text-center">
				<p>© 2016. All Rights Reserved | Designed by   <a href="#">  Brands Protection</a></p>
		  </div>
		</div>
		</div>
</body>
</html>