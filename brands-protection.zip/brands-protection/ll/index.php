<?php
include_once 'dbconfig.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Dynamic Dependent Select Box using jQuery and PHP</title>
<script type="text/javascript" src="jquery-1.4.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
	$(".brand").change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
	
		$.ajax
		({
			type: "POST",
			url: "get_product.php",
			data: dataString,
			cache: false,
			success: function(html)
			{
				$(".product").html(html);
			} 
		});
	});
	
	
	$(".product").change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
	
		$.ajax
		({
			type: "POST",
			url: "get_brand.php",
			data: dataString,
			cache: false,
			success: function(html)
			{
				$(".city").html(html);
			} 
		});
	});
	
});
</script>

</head>

<body>


<label>Brand:</label> 
<select name="brand" class="brand">
<option selected="selected">--Select Brand-</option>
<?php
	$stmt = $DB_con->prepare("SELECT * FROM companyregistration");
	$stmt->execute();
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		?>
        <option value="<?php echo $row['cid']; ?>"><?php echo $row['cname']; ?></option>
        <?php
	} 
?>
</select>

<label>Product :</label> <select name="product" class="product">
<option selected="selected">--Select Product--</option>
</select>





</center>
</body>
</html>
