<?php
mysql_connect("localhost","root","");
mysql_select_db("test2");
if(isset($_POST['submit']) && $_POST['brand']!=""){
$brand = $_POST['brand'];
 $insert = "INSERT INTO brands (brand_name) VALUES ('{$_POST['brand']}')";
		 mysql_query($insert);
}?>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
Product Name : <input type="text" name="brand"></input>
<input type="submit" value="add product" name="submit"></input>
</form>
