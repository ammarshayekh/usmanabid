<?php
include("dbconfig.php");
//$cname=''; $pname='';  $ccname='';  $location=''; $name='';  $number='';  $email='';

 /* if(isset($_POST['cname']) && !empty($_POST['cname']) AND isset($_POST['pname']) && !empty($_POST['pname']) AND isset($_POST['ccname']) && !empty($_POST['ccname'])AND isset($_POST['city']) && !empty($_POST['city']) AND isset($_POST['location']) && !empty($_POST['location']) AND isset($_POST['name']) && !empty($_POST['name'])
   AND isset($_POST['number']) && !empty($_POST['number'])  AND isset($_POST['email']) && !empty($_POST['email'])
   AND isset($_POST['message']) && !empty($_POST['message'])){
    $cname = mysql_escape_string($_POST['cname']); // Turn our post into a local variable
    $pname = mysql_escape_string($_POST['pname']); // Turn our post into a local variable
	 $ccname = mysql_escape_string($_POST['ccname']); // Turn our post into a local variable
	 $city_id = mysql_escape_string($_POST['city']); // Turn our post into a local variable
	  $name = mysql_escape_string($_POST['name']); // Turn our post into a local variable
	  $location = mysql_escape_string($_POST['location']); // Turn our post into a local variable
	    $number = mysql_escape_string($_POST['number']); // Turn our post into a local variable
		 $message = mysql_escape_string($_POST['message']); // Turn our post into a local variable
		 $email = mysql_escape_string($_POST['email']); // Turn our post into a local variable
		echo $cname. "<br/>"; echo $pname. "<br/>"; echo $ccname. "<br/>";echo $city_id. "<br/>"; echo $name. "<br/>"; echo $location. "<br/>"; echo $number. "<br/>"; echo $message. "<br/>"; echo $email. "<br/>";
		//exit();
		 
		 "insert into feedback(companyid) values ('$cname')";


        
}*/

     
?>
<!DOCTYPE html>
<html>
<head>
<title>Brands Protection | Feedback</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Eshop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- cart -->
	<script src="js/simpleCart.min.js"> </script>
<!-- cart -->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

<script type="text/javascript" src="jquery-1.4.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{

	$(".state").change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
	
		$.ajax
		({
			type: "POST",
			url: "get_city.php",
			data: dataString,
			cache: false,
			success: function(html)
			{
				$(".city").html(html);
			} 
		});
	});
	$(".brand").change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
	
		$.ajax
		({
			type: "POST",
			url: "get_product.php",
			data: dataString,
			cache: false,
			success: function(html)
			{
				$(".product").html(html);
			} 
		});
	});
	
});
</script>
</head>
<body>
	<!-- header-section-starts -->
	<div class="header">
		<div class="header-top-strip">
			<div class="container">
				<div class="header-top-left">
					<ul>
						<li><a href="login.php"><span class="glyphicon glyphicon-user"> </span>Login</a></li>
						<li><a href="register.php"><span class="glyphicon glyphicon-lock"> </span>Create an Account</a></li>			
					</ul>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<div class="inner-banner">
		<div class="container">
			<div class="banner-top inner-head">
				<nav class="navbar navbar-default" role="navigation">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
				<div class="logo">
					<h1><a href="index.php"><span>B</span> -rands</a></h1>
				</div>
	    </div>
	    <!--/.navbar-header-->
	
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	         <?php include("menu.php"); ?>
	    </div>
	    <!--/.navbar-collapse-->
	</nav>
	<!--/.navbar-->
</div>
	</div>
		</div>
		
<!-- contact-page -->
<div class="contact">
	<div class="container">
	
		
		
		<div class="contact-form">
			<div class="contact-info">
				<h3>FEEDBACK</h3>
			</div>
			<?php 
mysql_connect("localhost","root","");
mysql_select_db("brands");
	
if(isset($_POST['submit'])){
	
	$cname = $_POST['cname']; // Turn our post into a local variable
    $pname = $_POST['pname']; // Turn our post into a local variable
	 $ccname = $_POST['ccname']; // Turn our post into a local variable
	 $city_id = $_POST['city']; // Turn our post into a local variable
	  $name = $_POST['name']; // Turn our post into a local variable
	  $location = $_POST['location']; // Turn our post into a local variable
	    $number = $_POST['number']; // Turn our post into a local variable
		 $message = $_POST['message']; // Turn our post into a local variable
		 $email = $_POST['email']; //
		// echo $cname;
    $insert = "INSERT INTO feedback (companyid,product_id,state_id,city_id,name,location,cellno,message,email) VALUES ('$cname','$pname','$ccname','$city_id','$name','$location','$number','$message','$email')";
	mysql_query($insert);
}
?>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
            
				<div class="contact-left">
                <select  name="cname" class="brand"> 
                 <option selected="selected">--Select Company-</option>
<?php
	$stmt = $DB_con->prepare("SELECT * FROM companyregistration");
	$stmt->execute();
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		?>
        <option value="<?php echo $row['cid']; ?>"><?php echo $row['cname']; ?></option>
        <?php
	} 
?></select>
<select name="pname" class="product">
<option selected="selected">--Select Product--</option>
</select>
                  
                  <select name="ccname" class="state">
                 <option selected="selected">--Select State-</option>
<?php
	$stmt = $DB_con->prepare("SELECT * FROM state");
	$stmt->execute();
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		?>
        <option value="<?php echo $row['state_id']; ?>"><?php echo $row['state_name']; ?></option>
        <?php
	} 
?>
                  </select>
                  <select name="city" class="city">
<option selected="selected">--Select City--</option>
</select>
					<input type="text" placeholder="Location" name="location" required>
					<input type="text" placeholder="Name" name="name" required>
                    <input type="text" placeholder="Mobile Number" name="number" required>
					<input type="text" placeholder="E-mail" name="email" required>
				</div>
				<div class="contact-right">
					<textarea placeholder="Message" name="message" required></textarea>
				</div>
				<div class="clearfix"></div>
				<input type="submit" value="SEND" name="submit">
			</form>
		</div>
	</div>
</div>
<!-- //contact-page -->

		
		<div class="footer">
		<div class="container">
		 <div class="footer_top">
			<div class="span_of_4">
				
				
				
				
				<div class="clearfix"></div>
				</div>
		  </div>
		  
		  <div class="copyright text-center">
				<p>© 2016. All Rights Reserved | Designed by   <a href="#">  Brands Protection</a></p>
		  </div>
		</div>
		</div>
</body>
</html>