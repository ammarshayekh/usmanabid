 <?php
include("config.php");
$name=''; $email='';  $subject='';  $message=''; $email_from=''; $cust_msg=''; $subjectt='';

   if(isset($_POST['name']) && !empty($_POST['name']) AND isset($_POST['email']) && !empty($_POST['email']) AND isset($_POST['subject']) && !empty($_POST['subject']) AND isset($_POST['message']) && !empty($_POST['message'])){
    $name = mysql_escape_string($_POST['name']); // Turn our post into a local variable
	 $email = mysql_escape_string($_POST['email']); // Turn our post into a local variable
	  $subjectt = mysql_escape_string($_POST['subject']); // Turn our post into a local variable
	   $message = mysql_escape_string($_POST['message']); // Turn our post into a local variable

$email_from = "zamboads@gmail.com";
 
 $subject = $_REQUEST['subject'];
 
 $to = $_REQUEST['email'];
 
 $cust_msg = $_REQUEST['message'];
 
 $headers = "From: $to";
 
 $sent = mail($to, $subject, $cust_msg, $headers);

 if($sent)
 
{ echo " Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly."; 
 }
 
 else
 
 {echo "email is not sent, there is some error!"; }
   }

?>
<!DOCTYPE html>
<html>
<head>
<title>Brands Protection | Contact Us</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Eshop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- cart -->
	<script src="js/simpleCart.min.js"> </script>
<!-- cart -->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
</head>
<body>
	<!-- header-section-starts -->
	<div class="header">
		<div class="header-top-strip">
			<div class="container">
				<div class="header-top-left">
					<ul>
						<li><a href="login.php"><span class="glyphicon glyphicon-user"> </span>Login</a></li>
						<li><a href="register.php"><span class="glyphicon glyphicon-lock"> </span>Create an Account</a></li>			
					</ul>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<div class="inner-banner">
		<div class="container">
			<div class="banner-top inner-head">
				<nav class="navbar navbar-default" role="navigation">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
				<div class="logo">
					<h1><a href="index.php"><span>B</span> -rands</a></h1>
				</div>
	    </div>
	    <!--/.navbar-header-->
	
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	         <?php include("menu.php"); ?>
	    </div>
	    <!--/.navbar-collapse-->
	</nav>
	<!--/.navbar-->
</div>
	</div>
		</div>
		
<!-- contact-page -->
<div class="contact">
	<div class="container">
	
		<div class="contact-info">
			<h2>FIND US HERE</h2>
		</div>
		<div class="contact-map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6632.248000703498!2d151.265683!3d-33.7832959!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12abc7edcbeb07%3A0x5017d681632bfc0!2sManly+Vale+NSW+2093%2C+Australia!5e0!3m2!1sen!2sin!4v1433329298259" style="border:0"></iframe>
		</div>
		<div class="contact-form">
			<div class="contact-info">
				<h3>CONTACT FORM</h3>
			</div>
			<form action="" method="post">
				<div class="contact-left">
					<input type="text" placeholder="Name" name="name" required>
					<input type="text" placeholder="E-mail" name="email" required>
					<input type="text" placeholder="Subject" name="subject" required>
				</div>
				<div class="contact-right">
					<textarea placeholder="Message" name="message" required></textarea>
				</div>
				<div class="clearfix"></div>
				<input type="submit" value="SUBMIT">
			</form>
		</div>
	</div>
</div>
<!-- //contact-page -->

		
		<div class="footer">
		<div class="container">
		 <div class="footer_top">
			<div class="span_of_4">
				
				
				
				
				<div class="clearfix"></div>
				</div>
		  </div>
		  
		  <div class="copyright text-center">
				<p>© 2016. All Rights Reserved | Designed by   <a href="#">  Brands Protection</a></p>
		  </div>
		</div>
		</div>
</body>
</html>