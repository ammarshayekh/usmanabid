-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2016 at 05:05 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `brands`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(10) NOT NULL AUTO_INCREMENT,
  `email_address` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email_address`, `password`, `session_id`) VALUES
(1, 'raiasif87@yahoo.com', 'asif123', '0');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `city_id` int(10) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(100) NOT NULL,
  `state_id` int(10) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_name`, `state_id`) VALUES
(2, 'Rawalpindi', 1),
(3, 'Islamabad', 1);

-- --------------------------------------------------------

--
-- Table structure for table `companyregistration`
--

CREATE TABLE IF NOT EXISTS `companyregistration` (
  `cid` int(20) NOT NULL AUTO_INCREMENT,
  `cname` text NOT NULL,
  `ccontact` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `cmail` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `companyregistration`
--

INSERT INTO `companyregistration` (`cid`, `cname`, `ccontact`, `address`, `cmail`, `password`, `session_id`) VALUES
(1, 'FFBL', '03000767314', 'DHA Phase 2', 'raiasif87@yahoo.com', '123', 'nrj5o1kecugcbtjq5taagf50k5'),
(2, 'FFC', '051-5151513', 'Sadar Rwp', 'ffc@yahoo.com', 'ffc123', '0'),
(3, 'Honda', '051-5151515', 'Harlas Street, Rwp', 'honda@yahoo.com', 'honda123', '0'),
(4, 'ffblc', '09871161', 'sadarr', 'ffblc@yahoo.com', '12345', '0'),
(5, 'telenor', '03000654321', 'sindh', 'tel@yahoo.com', '999', '0'),
(6, 'FFBL', '03009998887', 'Karachi', 'usmanabid90440@yahoo.com', '222', '0'),
(7, 'UFONE', '03009998887', 'Balochistan', 'ufone33@yahoo.com', '333', '0'),
(8, 'zong', '0346551125', 'peshwar', 'zong@yahoo.com', '123', '0');

-- --------------------------------------------------------

--
-- Table structure for table `counterfitarea`
--

CREATE TABLE IF NOT EXISTS `counterfitarea` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `uniquecode` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `cellno` varchar(60) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `counterfitarea`
--

INSERT INTO `counterfitarea` (`cid`, `uniquecode`, `location`, `cellno`) VALUES
(1, '99', 'karachi', '+923353438546'),
(2, '11', 'lahore', '03000767314');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `feed_id` int(10) NOT NULL AUTO_INCREMENT,
  `companyid` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `state_id` int(10) NOT NULL,
  `city_id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `location` varchar(50) NOT NULL,
  `cellno` varchar(40) NOT NULL,
  `message` text NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`feed_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feed_id`, `companyid`, `product_id`, `state_id`, `city_id`, `name`, `location`, `cellno`, `message`, `email`) VALUES
(1, 1, 1, 1, 2, 'Asif', 'New Lalazar', '03000767314', 'Your product is good.', 'raiasif87@yahoo.com'),
(2, 2, 2, 1, 3, 'Ahsan', 'Sadar, Rwp', '03000654321', 'Not satisfactory.', 'ahsan@yahoo.com'),
(3, 3, 3, 1, 2, 'Ali', 'Lahore', '0300098765', 'Shortage of mile.', 'ali@yahoo.com'),
(4, 3, 4, 1, 3, 'imran', 'karachi', '+923353438546', 'kkl', 'usmanabid900@yahoo.com'),
(5, 2, 5, 1, 2, 'Sherjeel', 'Multan', '0321-5011848', 'It was good.', 'indo@ffc.com'),
(6, 1, 7, 1, 3, 'asif', 'Dha phase 2', '426', 'how are you ', 'as@yahoo.com'),
(7, 1, 9, 1, 3, 'haji', 'isb', '09898877', 'jkjjkk', 'u@yahoo.com'),
(8, 1, 1, 1, 2, 'haji', 'Multan', '+923353438546', 'llll', 'usmanabid900@yahoo.com'),
(9, 4, 13, 1, 2, 'haji', 'karachi', '+923353438546', 'lll', 'usmanabid900@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `graph`
--

CREATE TABLE IF NOT EXISTS `graph` (
  `gid` int(10) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `value` int(10) NOT NULL,
  `companyid` int(10) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `graph`
--

INSERT INTO `graph` (`gid`, `category`, `value`, `companyid`) VALUES
(1, '2016-06-13', 10, 3),
(2, '2016-06-14', 1, 3),
(3, '2016-04-30', 1, 3),
(4, '2016-05-01', 2, 3),
(5, '2016-06-13', 10, 2),
(6, '2016-06-14', 2, 2),
(7, '2016-05-01', 2, 2),
(8, '2016-06-13', 10, 4),
(9, '2016-06-14', 2, 4),
(10, '2016-05-01', 2, 4),
(11, '2016-05-02', 1, 4),
(12, '2016-06-14', 1, 4),
(13, '2016-06-13', 19, 4),
(14, '2016-06-14', 2, 4),
(15, '2016-05-01', 2, 4),
(16, '2016-05-03', 8, 4),
(17, '2016-06-14', 28, 4);

-- --------------------------------------------------------

--
-- Table structure for table `my_chart_data`
--

CREATE TABLE IF NOT EXISTS `my_chart_data` (
  `category` date NOT NULL,
  `value1` int(11) NOT NULL,
  `value2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `my_chart_data`
--

INSERT INTO `my_chart_data` (`category`, `value1`, `value2`) VALUES
('2013-08-24', 417, 127),
('2013-08-25', 417, 356),
('2013-08-26', 531, 585),
('2013-08-27', 333, 910),
('2013-08-28', 552, 30),
('2013-08-29', 492, 371),
('2013-08-30', 379, 781),
('2013-08-31', 767, 494),
('2013-09-01', 169, 364),
('2013-09-02', 314, 476),
('2013-09-03', 437, 759),
('2013-11-03', 566, 786),
('2013-11-03', 566, 786),
('2013-12-03', 566, 777);

-- --------------------------------------------------------

--
-- Table structure for table `productregisteration`
--

CREATE TABLE IF NOT EXISTS `productregisteration` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `companyid` int(10) NOT NULL,
  `productname` varchar(200) NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `productregisteration`
--

INSERT INTO `productregisteration` (`id`, `companyid`, `productname`, `msg`) VALUES
(1, 1, 'Panadol', 'It is used to remove headache. '),
(2, 1, 'Rijix', 'It is used for flue problem.'),
(3, 1, 'Amoxal', 'It is used for pain.'),
(4, 2, 'Colgate ', 'It is used for teeth wash.'),
(5, 2, 'Aripiprazole', 'It is used for.'),
(6, 2, 'Adalimumab', 'It is used for.'),
(7, 2, 'Esomeprazole', 'It is used for.'),
(8, 3, 'CD-70', 'This is a bike.'),
(9, 3, 'Atlas 1.6', 'This is a car.'),
(10, 3, 'GLI ', 'This is a car. Its colour is black.'),
(11, 2, 'maxsol', 'thisi sii good '),
(12, 2, 'SSSS', 'Nice'),
(13, 4, 'ABC', 'Used for '),
(14, 2, 'pink', 'this is good product'),
(15, 2, 'injection', 'this is good injection'),
(16, 2, 'panafelx', 'very good'),
(17, 8, '300cared', 'this is isi isi isii ');

-- --------------------------------------------------------

--
-- Table structure for table `productverification`
--

CREATE TABLE IF NOT EXISTS `productverification` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `companyid` int(10) NOT NULL,
  `productid` int(10) NOT NULL,
  `uniquecode` varchar(200) NOT NULL,
  `productname` varchar(20) NOT NULL,
  `manfdate` varchar(20) NOT NULL,
  `expdate` varchar(20) NOT NULL,
  `verificationdate` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `cellno` varchar(15) NOT NULL,
  `status` int(5) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `productverification`
--

INSERT INTO `productverification` (`pid`, `companyid`, `productid`, `uniquecode`, `productname`, `manfdate`, `expdate`, `verificationdate`, `location`, `cellno`, `status`) VALUES
(1, 1, 1, '11221', 'Panadol', '2016-04-01', '2016-04-12', '2016-06-13', 'lahore', '+923353438546', 1),
(2, 1, 2, '11222', 'Rijix', '2016-04-02', '2016-04-06', '2016-06-13', 'karachi', '0346551125', 1),
(3, 1, 3, '11223', 'Amoxal', '2016-04-15', '2016-04-29', '2016-06-13', 'Multan', '+923353438546', 1),
(4, 2, 4, '11224', 'Colgate ', '2016-04-06', '2016-04-16', '2016-06-13', 'karachi', '+923353438546', 1),
(5, 2, 5, '11225', 'Aripiprazole', '2016-04-15', '2016-04-22', '2016-06-13', 'Faisalabad', '+923353438546', 1),
(6, 2, 6, '11226', 'Adalimumab', '2016-04-12', '2016-04-30', '2016-06-13', 'karachi', '+923353438546', 1),
(7, 2, 7, '11227', 'Esomeprazole', '2016-04-28', '2016-04-30', '2016-06-13', 'islmabad', '0346551125', 1),
(8, 3, 8, '11228', 'CD-70', '2016-03-29', '2016-04-23', '2016-06-13', 'Multan', '03316393246', 1),
(9, 3, 9, '11229', 'Atlas 1.6', '2016-04-04', '2016-04-16', '2016-06-13', 'islmabad', '0346551125', 1),
(10, 3, 5, '11331', 'Aripiprazole', '2016-04-05', '2016-04-29', '2016-06-13', 'lahore', '03316393246', 1),
(11, 3, 10, '11332', 'GLI ', '2016-04-29', '2016-04-30', '2016-06-14', 'Faisalabad', '03316393246', 1),
(12, 2, 11, '9090', 'maxsol', '2016-04-26', '2016-04-28', '2016-06-14', 'islmabad', '0346551125', 1),
(13, 2, 11, '099oop', 'maxsol', '2016-04-29', '2016-04-28', '2016-05-01', '', '', 0),
(14, 2, 12, '11220', 'Colgate ', '2016-04-06', '2016-04-22', '2016-05-01', '', '', 0),
(15, 2, 12, '766sj', 'Colgate ', '2016-06-08', '2016-06-10', '', '', '', 0),
(16, 4, 14, 'uui8989', 'pink', '2016-06-08', '2016-06-11', '2016-06-14', 'Faisalabad', '0346551125', 1),
(17, 4, 14, 'nmxc99', 'Adalimumab', '2016-06-08', '2016-06-12', '2016-06-14', 'lahore', '0346551125', 1),
(18, 4, 14, '123erd', 'Esomeprazole', '2016-06-08', '2016-06-12', '', '', '', 0),
(19, 4, 14, '2087d', 'Adalimumab', '2016-06-08', '2016-06-28', '', '', '', 0),
(20, 5, 14, '425fa', 'Aripiprazole', '2016-06-15', '2016-06-30', '', '', '', 0),
(21, 5, 14, '355ff0a148367b', 'Aripiprazole', '2016-06-08', '2016-06-29', '', '', '', 0),
(22, 5, 14, '2eb8713b7b4531', 'Aripiprazole', '2016-06-08', '2016-06-30', '', '', '', 0),
(23, 5, 14, 'c12b11c69f7959', 'SSSS', '2016-06-09', '2016-06-13', '', '', '', 0),
(24, 5, 16, '3d7f2c', 'injection', '2016-06-14', '2016-06-15', '', '', '', 0),
(25, 5, 16, '00326d', 'pink', '2016-06-14', '2016-06-16', '', '', '', 0),
(26, 2, 16, '8908d13012bc2c', 'Colgate ', '2016-06-16', '2016-06-16', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopkeeperverification`
--

CREATE TABLE IF NOT EXISTS `shopkeeperverification` (
  `spid` int(10) NOT NULL AUTO_INCREMENT,
  `scode` varchar(30) NOT NULL,
  `productname` varchar(30) NOT NULL,
  `manfdate` varchar(30) NOT NULL,
  `expdate` varchar(20) NOT NULL,
  `verificationdate` varchar(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `cellno` varchar(50) NOT NULL,
  PRIMARY KEY (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `state_id` int(10) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(200) NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`) VALUES
(1, 'Punjab'),
(2, 'Sindh');

-- --------------------------------------------------------

--
-- Table structure for table `uniquecode`
--

CREATE TABLE IF NOT EXISTS `uniquecode` (
  `coid` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) NOT NULL,
  `companyid` int(10) NOT NULL,
  PRIMARY KEY (`coid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `uniquecode`
--

INSERT INTO `uniquecode` (`coid`, `code`, `companyid`) VALUES
(1, 'c67f59c9c6b901', 1),
(2, 'e6916178e16a1b', 1),
(4, '3b5a0159a4c5fb', 2),
(5, 'b5b834b7e365b5', 3),
(6, 'aaceb0089cd8f5', 3),
(7, '39d4731329bdb6', 4),
(8, '914ea24bb1e162', 4),
(9, 'a07160d30f9964', 5),
(10, '55f73a90d6348f', 5),
(11, 'a50f3c78', 7),
(12, '502c5a97', 7),
(13, '94d04200', 7),
(14, 'c8f86078', 7),
(15, '130a9328', 7),
(16, 'e2602f1f94131d', 0),
(17, '6d2be3a2eee7ae', 0),
(18, '24cbbed8389139', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
