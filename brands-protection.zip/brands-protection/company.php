<?php include("config.php"); ?>
<!DOCTYPE html>
<html>
<head>
<title>Brands Protection | Company</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Eshop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<!-- for bootstrap working -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
<!-- cart -->
	<script src="js/simpleCart.min.js"> </script>
<!-- cart -->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
</head>
<body>
	<!-- header-section-starts -->
	<div class="header">
		<div class="header-top-strip">
			<div class="container">
				<div class="header-top-left">
					<ul>
						<li><a href="login.php"><span class="glyphicon glyphicon-user"> </span>Login</a></li>
						<li><a href="register.php"><span class="glyphicon glyphicon-lock"> </span>Create an Account</a></li>			
					</ul>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<div class="inner-banner">
		<div class="container">
			<div class="banner-top inner-head">
				<nav class="navbar navbar-default" role="navigation">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
				<div class="logo">
					<h1><a href="index.php"><span>B</span> -rands</a></h1>
				</div>
	    </div>
	    <!--/.navbar-header-->
	
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	         <?php include("menu.php"); ?>
	    </div>
	    <!--/.navbar-collapse-->
	</nav>
	<!--/.navbar-->
</div>
	</div>
		</div>
		<!-- content-section-starts -->
	<div class="content">
	<div class="container">			   
		   <div class="typrography">
		    <?php
		  $id=$_REQUEST['cid'];
		   $productname=''; $msg='';
	 $q1=mysql_query("select * from companyregistration where cid = '$id'",$con);
	 while($q1_data=mysql_fetch_array($q1))
	 {
		 $cname=$q1_data['cname'];
		
	 }
		 ?>
	      <h2 class="heading text-center"><?php echo $cname;?></h2>
         <div class="grid_3 grid_4">
		   <div class="bs-example">
				 <table class="table">
				  <tbody>
                   <?php
		  $id=$_REQUEST['cid'];
		   $productname=''; $msg='';
	 $q=mysql_query("select * from productregisteration where companyid = '$id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $productname=$q_data['productname'];
		 $msg=$q_data['msg'];
		 ?>
					<tr>
                     <td class="type-info"><?php echo $productname; ?></td>
					  <td><p><?php echo $msg; ?></p></td>
					 
					</tr>
				<?php } if (($productname == '') && ($msg == ''))
				{?>
                <tr>
                <td> Record Not Found</td>
                
                </tr>
                <?php } ?>
				  </tbody>
				 </table>
			 </div>
	      </div>
		  <div class="clearfix"></div>
				</div>
		  </div>
		  
		  <div class="copyright text-center">
				<p>© 2016. All Rights Reserved | Designed by   <a href="#">  Brands Protection</a></p>
		  </div>
		</div>
		</div>
</body>
</html>