<?php
include('dbconfig.php');
if($_POST['id'])
{
	$id=$_POST['id'];
	
	$stmt = $DB_con->prepare("SELECT * FROM productregisteration WHERE companyid=:id");
	$stmt->execute(array(':id' => $id));
	?><option selected="selected">Select Product :</option><?php
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		?>
		<option value="<?php echo $row['id']; ?>"><?php echo $row['productname']; ?></option>
		<?php
	}
}
?>