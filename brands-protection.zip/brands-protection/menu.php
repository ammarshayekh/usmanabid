<?php include('config.php'); ?>
<ul class="nav navbar-nav">
			<li><a href="index.php">Home</a></li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Registered Companies <b class="caret"></b></a>
		            <ul class="dropdown-menu multi-column columns-2">
			            <div class="row">
				            <div class="col-sm-4">
					            <ul class="multi-column-dropdown">
									<?php
	 $q=mysql_query("select * from companyregistration",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $companyid=$q_data['cid'];
		 $cname=$q_data['cname'];
		 
		 
	
	 
	 ?> 
						            <li><a href="company.php?cid=<?php echo $companyid; ?>"><?php echo $cname;?></a></li>
						           <?php } ?>
						            
					            </ul>
				            </div>
				           
				             
							<div class="clearfix"></div>
			            </div>
		            </ul>
		        </li>
		        
		        
					<li><a href="services.php">Services</a></li>
                    <li><a href="about.php">About</a></li>
					<li><a href="codesearch.php">Verification</a></li>
                    <li><a href="feedback.php">Feedback</a></li>
                    <li><a href="contact.php">Contact-Us</a></li>
	        </ul>