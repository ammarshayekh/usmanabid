 
<div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                   
                    <li>
                        <a   href="home.php"></i>Dashboard</a>
                    </li>
                    
                    <li>
                        <a href="graph.php">Graph </a>
                        
                    </li>
                    
                    
                   
                     
                     <li>
                        <a href="feedback.php">Feedback</a>
                    </li>
                   
                    <li>
                        <a href="#">Products <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                        
                              <li>
                                <a href="registerproductname.php">Register Products Name

</a>
                            </li>
                             <li>
                                <a href="registerproduct.php">Register Products 

</a>
                            </li>
                            <li>
                                <a href="viewproduct.php">View Products 

</a>
                            </li>
                            
                        </ul>
                    </li>
                     <li>
                        <a href="#">Products Category <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                     <?php   $qqv=mysql_query("select * from productregisteration where companyid='$c_id'",$con);
	 while($qqv_data=mysql_fetch_array($qqv))
	 {
		 
		$productnamev=$qqv_data['productname'];
		$id=$qqv_data['id'];
		
	
	 ?>
                              <li>
                                <a href="viewproductcate.php?id=<?php echo $id; ?>"><?php echo $productnamev; ?>

</a>
                            </li>
                            <?php } ?>
                            
                        </ul>
                    </li>
                
                </ul>
            </div>