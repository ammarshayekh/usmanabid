<?php include("config.php"); 

$code=''; $pname='';$mdate=''; $exdate=''; $uniquecode='';
   if(isset($_POST['code']) && !empty($_POST['code']) AND isset($_POST['pname']) && !empty($_POST['pname']) AND isset($_POST['mdate']) && !empty($_POST['mdate']) AND isset($_POST['exdate']) && !empty($_POST['exdate'])){
    $code = mysql_escape_string($_POST['code']); // Turn our post into a local variable
    $pname = mysql_escape_string($_POST['pname']); // Turn our post into a local variable
	$mdate = mysql_escape_string($_POST['mdate']); // Turn our post into a local variable
	$exdate = mysql_escape_string($_POST['exdate']); // Turn our post into a local variable
	$qqp=mysql_query("select * from productregisteration where companyid='$c_id'",$con);
	 while($qqp_data=mysql_fetch_array($qqp))
	 {
		 
		$ppid=$qqp_data['id'];
		
	 }
	 
	  $qq=mysql_query("select * from productverification where uniquecode='$code'",$con);
	 while($qq_data=mysql_fetch_array($qq))
	 {
		 
		$uniquecode=$qq_data['uniquecode'];
		
	 }
	 if($code == $uniquecode)
	 {
		  echo "<script>alert('Unique Code is already exit.Try Again!');</script>";
		  echo "<meta http-equiv=\"refresh\" content=\"0;URL=registerproduct.php\">";
		 //echo "Unique Code is already exit.Try Again.<a href='registerproduct.php'>Click Here</a>";
		 exit();
	 }
	   
	   mysql_query("insert into productverification(companyid,productid,uniquecode,productname,manfdate,expdate) values ('$c_id','$ppid','$code','$pname','$mdate','$exdate')",$con);
	   echo "<script>alert('Full Product Registered Successfully!');</script>";
	   
	   $del=mysql_query("delete from uniquecode where code = '$code' and companyid='$c_id'",$con);
   }


?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Brands Protection | Register Product</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
      <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    <div id="wrapper">
        <?php include("header.php"); ?>
        <!-- /. NAV TOP  -->
        <nav  class="navbar-default navbar-side" role="navigation">
             <?php include("left-sidebar.php"); ?>

        </nav>
        <!-- /. SIDEBAR MENU (navbar-side) -->
        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Product Registration </h1>
                    </div>
                </div>
                <div class="row" >
                    <div class="col-md-6" style="margin-left:250px;">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           Product Registeration
                        </div>
                        <div class="panel-body">
                       <form action="" method="post">
                      
  <div class="form-group">
    <label for="exampleInputEmail1">Unique Code</label>
    
   <select  class="form-control" name="code"><option selected>Select unique code</option>
   <?php 
                                  $qq1=mysql_query("select code from uniquecode where companyid='$c_id'",$con);

                                  while($qq1_data=mysql_fetch_array($qq1))
                                  {
	
	
	                                     $code=$qq1_data['code'];
								  
                                     ?>
                                     <option value="<?php echo $code; ?>"><?php echo $code; ?></option>
                                     <?php } ?>
   </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Product Name</label>
    
   <select  class="form-control" name="pname"><option selected>Select Product Name</option>
   <?php 
                                  $qq1=mysql_query("select * from productregisteration where companyid='$c_id'",$con);

                                  while($qq1_data=mysql_fetch_array($qq1))
                                  {
	
	
	                                     $prdname=$qq1_data['productname'];
								  
                                     ?>
                                     <option value="<?php echo $prdname; ?>"><?php echo $prdname; ?></option>
                                     <?php } ?>
   </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Manufacture Date</label>
   <input type="date" class="form-control" placeholder="Manufacture Date" name="mdate"/>
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1">Expiry Date</label>
   <input type="date" class="form-control" placeholder="Expiry Date" name="exdate"/>
  </div>
 
                          
 <button type="submit" class="btn btn-default" >Register Product</button>
                           <hr />




</form>
                            </div>
                            </div>
                    </div>
                    
                </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <footer >
         &copy; 2016 Brands Protection | Designed By : <a href="#" target="_blank">Rai Asif</a>
    </footer>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
