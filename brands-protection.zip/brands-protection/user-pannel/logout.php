<?php include('config.php'); ?>
<?php

$uupdate=mysql_query("update companyregistration set session_id='0' where session_id='$ses_id'",$con);
echo "<script>alert('You are Want to Logout!');</script>";
echo "<meta http-equiv=\"refresh\" content=\"0;URL=../login.php\">";
?>
