<?php include("config.php");
$pname=''; $msg='';

   if(isset($_POST['pname']) && !empty($_POST['pname']) AND isset($_POST['msg']) && !empty($_POST['msg'])){
    $pname = mysql_escape_string($_POST['pname']); // Turn our post into a local variable
    $msg = mysql_escape_string($_POST['msg']); // Turn our post into a local variable
	 
	   
	   mysql_query("insert into productregisteration(companyid,productname,msg) values ('$c_id','$pname','$msg')",$con);
	    echo "<script>alert('Product Name and Description is Registered Successfully!');</script>";
   }

 ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Brands Protection | Reg Product Name</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
      <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <div id="wrapper">
        <?php include("header.php"); ?>
        <!-- /. NAV TOP  -->
        <nav  class="navbar-default navbar-side" role="navigation">
             <?php include("left-sidebar.php"); ?>

        </nav>
        <!-- /. SIDEBAR MENU (navbar-side) -->
        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">  Product Registeration  </h1>
                    </div>
                </div>
                <div class="row" >
                    <div class="col-md-6" style="margin-left:250px;">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           Product Registeration 
                        </div>
                        <div class="panel-body">
                       <form action="" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Product Name</label>
   <input type="text" class="form-control" placeholder="Product Name" name="pname" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Description</label>
    <textarea class="form-control" rows="3" placeholder="Description About Product" name="msg"></textarea>
  </div>
  
  
 
                          
 <button type="submit" class="btn btn-default">Register Product</button>
                           <hr />




</form>
                            </div>
                            </div>
                    </div>
                    
                </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <footer >
         &copy; 2016 Brands Protection | Designed By : <a href="#" target="_blank">Rai Asif</a>
    </footer>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
