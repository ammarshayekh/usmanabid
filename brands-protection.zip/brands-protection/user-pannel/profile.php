<?php
include("config.php");
$cname=''; $address='';  $email='';  $number=''; $opassword=''; $npassword=''; $cpassword='';

   if(isset($_POST['cname']) && !empty($_POST['cname']) AND isset($_POST['address']) && !empty($_POST['address']) AND isset($_POST['email']) && !empty($_POST['email']) AND isset($_POST['number']) && !empty($_POST['number']) AND isset($_POST['opassword']) && !empty($_POST['opassword']) AND isset($_POST['npassword']) && !empty($_POST['npassword']) AND isset($_POST['cpassword']) && !empty($_POST['cpassword'])){
    $cname = mysql_escape_string($_POST['cname']); // Turn our post into a local variable
    $address = mysql_escape_string($_POST['address']); // Turn our post into a local variable
	 $email = mysql_escape_string($_POST['email']); // Turn our post into a local variable
	  $number = mysql_escape_string($_POST['number']); // Turn our post into a local variable
	   $opassword = mysql_escape_string($_POST['opassword']); // Turn our post into a local variable
	   $npassword = mysql_escape_string($_POST['npassword']); // Turn our post into a local variable
	   $cpassword = mysql_escape_string($_POST['cpassword']); // Turn our post into a local variable
	   
	   $qq=mysql_query("select * from companyregistration where session_id='$ses_id'",$con);
	 while($qq_data=mysql_fetch_array($qq))
	 {
		 
		$password=$qq_data['password'];
		
	 }
	   if($opassword != $password)
	   {
		   echo "Old Password Is Incorrect.Please Try Again.<a href='profile.php'>Click Here</a>";
		   exit();
	   }
	   if($npassword != $cpassword)
	   {
		   echo "New Password and Confirm Password Is not Matched.Please Try Again.<a href='profile.php'>Click Here</a>";
		     exit();
	   }
	   
	   $update=mysql_query("update companyregistration set cname='$cname', ccontact='$number',address='$address', cmail='$email',password='$npassword' where cid='$c_id'",$con);
   }

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Brands Protection | Profile</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
      <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <div id="wrapper">
        <?php include("header.php");?>
        <!-- /. NAV TOP  -->
        <nav  class="navbar-default navbar-side" role="navigation">
             <?php include("left-sidebar.php"); ?>

        </nav>
        <!-- /. SIDEBAR MENU (navbar-side) -->
        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Company Profile</h1>
                    </div>
                </div>
                <div class="row" >
                    <div class="col-md-6" style="margin-left:250px;">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                           Edit Profile
                        </div>
                    <?php  
	 
	 $q=mysql_query("select * from companyregistration where session_id='$ses_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $cname=$q_data['cname'];
		 $ccontact=$q_data['ccontact'];
		 $address=$q_data['address'];
		 $cmail=$q_data['cmail'];
		 
		// $password=$q_data['password'];
	 }
	  ?>     
                        <div class="panel-body">
                       <form action="" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Company  Name</label>
   <input type="text" class="form-control" name="cname" value="<?php echo $cname; ?>"/>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Address</label>
   <input type="text" class="form-control" name="address" value="<?php echo $address; ?>"/>
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1">E-mail</label>
   <input type="text" class="form-control" name="email" value="<?php echo $cmail; ?>"/>
  </div>
 <div class="form-group">
    <label for="exampleInputEmail1">Mobile #</label>
   <input type="text" class="form-control" name="number" value="<?php echo $ccontact; ?>"/>
  </div>
       <div class="form-group">
    <label for="exampleInputEmail1">Old Password</label>
   <input type="password" class="form-control" name="opassword" required/>
  </div>     
  <div class="form-group">
    <label for="exampleInputEmail1"> New Password</label>
   <input type="password" class="form-control" name="npassword" required/>
  </div>    
  <div class="form-group">
    <label for="exampleInputEmail1">Confirm Password</label>
   <input type="password" class="form-control" name="cpassword" required/>
  </div>          
 <button type="submit" class="btn btn-default">Edit</button>
                           <hr />




</form>
                            </div>
                            </div>
                    </div>
                    
                </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <footer >
         &copy; 2016 Brands Protection | Designed By : <a href="#" target="_blank">Rai Asif</a>
    </footer>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
