<?php include('config.php');  ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Brands Protection | Feedback</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
      <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <div id="wrapper">
        <?php include('header.php'); ?>
        <!-- /. NAV TOP  -->
        <nav  class="navbar-default navbar-side" role="navigation">
            <?php include('left_sidebar.php'); ?>

        </nav>
        <!-- /. SIDEBAR MENU (navbar-side) -->
        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Feedback</h1>
                    </div>
                </div>
                <div class="row">
                <div class="col-md-12">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Feedback
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>User Name</th>
                                             <th>Company Name</th>
                                            <th>Product Name</th>
                                            <th>City Name</th>
                                            <th>Location</th>
                                            <th>Mobile #</th>
                                            <th>E-Mail</th>
                                            <th>Message</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                             <?php  
	 $count = 1;
	 $q=mysql_query("SELECT feedback.companyid,feedback.name,feedback.location,feedback.cellno,feedback.message,feedback.email,feedback.city_id,feedback.feed_id,productregisteration.productname,productregisteration.id,feedback.product_id,feedback.city_id
FROM productregisteration
INNER JOIN feedback
ON productregisteration.id=feedback.product_id

          ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $name=$q_data['name'];
		 $comp_id=$q_data['companyid'];
		$location=$q_data['location'];
		 $cellno=$q_data['cellno'];
		 $message=$q_data['message'];
		  $email=$q_data['email'];
		   //$cname=$q_data['cname'];
		   $proname=$q_data['productname'];
		  $ciTYname=$q_data['city_id'];
		$feed_id=$q_data['feed_id'];
		$re=$count++;
		$q1=mysql_query("select * from companyregistration where cid = $comp_id",$con);
		while($q1_d=mysql_fetch_array($q1))
			{
			$cname=$q1_d['cname'];	
			}
		$q12=mysql_query("select * from city where city_id = $ciTYname",$con);
		while($q12_d=mysql_fetch_array($q12))
			{
			$city_name=$q12_d['city_name'];	
			}
	 
	  ?>                 
                                        <tr>
                                            <td><?php echo $re; ?></td>
                                            <td><?php echo $name; ?></td>
                                            <td><?php echo $cname; ?></td>
                                            <td><?php echo $proname; ?></td>
                                            <td><?php echo $city_name; ?></td>
                                             <td><?php echo $location; ?></td>
                                              <td><?php echo $cellno; ?></td>
                                               <td><?php echo $email ?></td>
                                               <td><?php echo $message ?></td>
                                               <td><a href="feedback_delete.php?fid=<?php echo $feed_id; ?>">Delete</a></td>
                                        </tr>
                                       <?php } ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>
                
            </div>
                
                

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <footer >
        &copy; 2016 Brands Protection | Designed By : <a href="https://www.facebook.com/usman.abid.549" target="_blank">Rai Asif</a>
    </footer>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
