<div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                   
                    <li>
                        <a   href="home.php"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="graph.php">Graph </a>
                    </li>
                    <li>
                        <a href="generatecode.php">Generate Code</a>
                    </li>
                     <li>
                        <a href="feedback.php">Feedback</a>
                    </li>
                     <li>
                        <a href="user.php">Users</a>
                    </li>
                   
                    <li>
                        <a href="#">Products <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                        
                            
                            <li>
                                <a href="viewproduct.php">View Products 

</a>
                            </li>
                            
                        </ul>
                    </li>
                
                </ul>
            </div>