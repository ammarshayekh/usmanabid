<?php include("config.php"); 

$name=''; $location=''; $city='';$address='';$number='';$email='';$cnic='';$image='';$book_menu='';

if(isset($_POST['name']) && !empty($_POST['name']) AND isset($_POST['location']) && !empty($_POST['location']) AND isset($_POST['city']) && !empty($_POST['city'])AND isset($_POST['address']) && !empty($_POST['address']) AND isset($_POST['number']) && !empty($_POST['number'])AND isset($_POST['email']) && !empty($_POST['email'])AND isset($_POST['cnic']) && !empty($_POST['cnic'])){
	//////////////////////////////////////////////////////////////
	  $target_path = "hotel_image/";
$target_path = $target_path . basename( $_FILES['image']['name']);
      $target_path = "hotel_image/";
$target_path = $target_path . basename( $_FILES['image']['name']);
      $Target = $target_path;
move_uploaded_file($_FILES['image']['tmp_name'], $target_path);
/////////////////////////////////////////////////////////////////
$target_path1 = "book_menu/";
$target_path1 = $target_path1 . basename( $_FILES['book_menu']['name']);
      $target_path1 = "book_menu/";
$target_path1 = $target_path1 . basename( $_FILES['book_menu']['name']);
      $Target1 = $target_path1;
move_uploaded_file($_FILES['book_menu']['tmp_name'], $target_path1);
//////////////////////////////////////////////////////////////

      $name = $_POST['name']; 
	  $location = $_POST['location']; 
	  $city = $_POST['city']; 
	  $address = $_POST['address']; 
	  $number = $_POST['number'];
	  $email = $_POST['email'];
	  $cnic = $_POST['cnic'];
	 // $image = $_POST['image'];
	 // $book_menu = $_POST['book_menu']; 
	  
 
 mysqli_query($conn,"INSERT INTO tb_addrestaurent(name,location,city,address,number,email,cnic,image,book_menu)values('$name','$location','$city','$address','$number','$email','$cnic','$Target','$Target1')");
 echo "<script>alert('Registered Succesfully');</script>";
  }
?>
<!DOCTYPE html>
<html>
<head>
<?php include("title.php"); ?>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
<script src="js/jquery.carouFredSel-6.1.0-packed.js"></script>
<script src="js/tms-0.4.1.js"></script>
<script>
 $(window).load(function(){
      $('.slider')._TMS({
              show:0,
              pauseOnHover:false,
              prevBu:'.prev',
              nextBu:'.next',
              playBu:false,
              duration:800,
              preset:'fade', 
              pagination:true,//'.pagination',true,'<ul></ul>'
              pagNums:false,
              slideshow:8000,
              numStatus:false,
              banners:false,
          waitBannerAnimation:false,
        progressBar:false
      })  
      });
      
     $(window).load (
    function(){$('.carousel1').carouFredSel({auto: false,prev: '.prev',next: '.next', width: 960, items: {
      visible : {min: 1,
       max: 4
},
height: 'auto',
 width: 240,

    }, responsive: false, 
    
    scroll: 1, 
    
    mousewheel: false,
    
    swipe: {onMouse: false, onTouch: false}});
    
    
    });      

     </script>
<script src="js/jquery.easydropdown.js"></script>
<script src="js/simpleCart.min.js"> </script>	
</head>
<body>
    <!-- header-section-starts -->
	<div class="header">
		<div class="container">
			<?php include("top_header.php"); ?>
		</div>
			<div class="menu-bar">
			<?php include("top_menu.php"); ?>
		</div>
		</div>
	<!-- header-section-ends -->
	<div class="order-section-page">
		<div class="ordering-form">
			<div class="container">
			<div class="order-form-head text-center wow bounceInLeft" data-wow-delay="0.4s">
						<h3>Add Restaurant</h3>
						<p>Ordering Food Was Never So Simple !!!!!!</p>
					</div>
				<div class="col-md-6 order-form-grids">
					
					<div class="order-form-grid  wow fadeInLeft" data-wow-delay="0.4s">
                    <form action="#" method="post" enctype="multipart/form-data">
						<h5>Restaurant Information</h5>
						<div>
				<input type="text" name="name" class="text" value="Restaurant Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Restaurant Name';}">
                        </div>
		              <div>
				<input type="text" name="location" class="text" value="Location" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Location';}">
                        </div>
					<div>
				<input type="text" name="city" class="text" value="City" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'City';}">
                        </div>
					<div>
				<input type="text" name="address" class="text" value="Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Address';}">
                        </div>
                     <div>
				<input type="text" name="number" class="text" value="Contact Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Contact Number';}">
                        </div>
                        <div>
				<input type="text" name="email" class="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}">
                        </div>
                        <div>
				<input type="text" name="cnic" class="text" value="Owner Cnic" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Owner Cnic';}">
                        </div>
                        <div>
                        <span>Upload Image</span>
				<input type="file" name="image" class="text" value="Upload Image" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Upload Image';}">
                        </div>
                        <span>Book Menu</span>
                        <div>
				<input type="file" name="book_menu" class="text" value="Book Menu" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Restaurant Name';}">
                        </div>
                         <span>Password</span>
                        <div>
				<input type="password" name="password" class="text" value="Book Menu" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Restaurant Name';}">
                        </div>
					<div class="wow swing animated" data-wow-delay= "0.4s">
					<input type="submit" value="Register now">
                    </form>
					</div>
					</div>
				</div>
				<div class="col-md-6 ordering-image wow bounceIn" data-wow-delay="0.4s">
					<img src="images/order.jpg" class="img-responsive" alt="" />
				</div>
                
			</div>
		</div>
<div class="special-offers-section">
			<div class="container">
				<div class="special-offers-section-head text-center dotted-line">
					<h4>Special Offers</h4>
				</div>
				<div class="special-offers-section-grids">
				 <div class="m_3"><span class="middle-dotted-line"> </span> </div>
				   <div class="container">
					  <ul id="flexiselDemo3">
						<li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p1.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>Olister Combo pack lorem</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								<div class="clearfix"></div>
							</div>
						</li>
						<li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p2.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>Chicken Jumbo pack lorem</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								<div class="clearfix"></div>
							</div>
						</li>
						<li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p1.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>Crab Combo pack lorem</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								
								<div class="clearfix"></div>
								</div>
						</li>
						<li>
							<div class="offer">
								<div class="offer-image">	
									<img src="images/p2.jpg" class="img-responsive" alt=""/>
								</div>
								<div class="offer-text">
									<h4>Chicken Jumbo pack lorem</h4>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. </p>
									<input type="button" value="Grab It">
									<span></span>
								</div>
								
								<div class="clearfix"></div>
								</div>
					    </li>
					 </ul>
				 <script type="text/javascript">
					$(window).load(function() {
						
						$("#flexiselDemo3").flexisel({
							visibleItems: 3,
							animationSpeed: 1000,
							autoPlay: true,
							autoPlaySpeed: 3000,    		
							pauseOnHover: true,
							enableResponsiveBreakpoints: true,
							responsiveBreakpoints: { 
								portrait: { 
									changePoint:480,
									visibleItems: 1
								}, 
								landscape: { 
									changePoint:640,
									visibleItems: 2
								},
								tablet: { 
									changePoint:768,
									visibleItems: 3
								}
							}
						});
						
					});
				    </script>
				    <script type="text/javascript" src="js/jquery.flexisel.js"></script>
				</div>
			</div>
		</div>
		</div>
	</div>
	<!-- footer-section-starts -->
	<div class="footer">
		<?php include("footer.php"); ?>
	</div>
	<!-- footer-section-ends -->
	  <script type="text/javascript">
						$(document).ready(function() {
							/*
							var defaults = {
					  			containerID: 'toTop', // fading element id
								containerHoverID: 'toTopHover', // fading element hover id
								scrollSpeed: 1200,
								easingType: 'linear' 
					 		};
							*/
							
							$().UItoTop({ easingType: 'easeOutQuart' });
							
						});
					</script>
				<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

</body>
</html>