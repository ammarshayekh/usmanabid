﻿<?php

include("config.php");


$sts = $_REQUEST['s'];
$oid = $_REQUEST['cid'];
$order_id=$_POST["orderid"];
$deliverytime=$_POST["time"];
echo $order_id;
echo $deliverytime;
mysqli_query($conn,"insert into tb_time(orderid,timetable)values('$order_id','$deliverytime')");

$update= mysqli_query($conn,"update tb_customer_order set status = '$sts' where cid = '$oid'");
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=orderprocess.php\">";

?>