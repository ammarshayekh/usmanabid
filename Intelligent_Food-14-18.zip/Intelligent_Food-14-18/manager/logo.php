<div class="logo">
					<a href="index.php">
						<h1>IFOS</h1>
						<span>Manager Panel</span>
					</a>
				</div>