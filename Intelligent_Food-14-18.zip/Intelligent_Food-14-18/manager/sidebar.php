<div class="navbar-collapse">
				<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
					<ul class="nav" id="side-menu">
						<li>
							<a href="#" class="active"><i class="fa fa-home nav_icon"></i>Dashboard</a>
						</li>
						<li>
							<a href="#">Home <span class="fa arrow"></span></a>
							<ul class="nav nav-second-level collapse">
								<li>
									<a href="orderprocess.php">Order Processing</a>
								</li>
								<li>
									<a href="add_promotions.php">Add Promotions </a>
								</li>
							</ul>
							<!-- /nav-second-level -->
						</li>
					
						</li>
						
						<li>
							<a href="add_item.php">Add Item</a>
						</li>
                        <li>
							<a href="nutrients.php">Add Nutrients</a>
						</li>
					</ul>
					<!-- //sidebar-collapse -->
				</nav>
			</div>