<?php
//session_start();
//$ses_id=session_id();
    if (!isset($_SESSION)) {
    session_start();
    }
	$ses_id = session_id();
$conn = mysqli_connect("localhost","root","","ifos");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
//=======================================================================================
$q=mysqli_query($conn,"select * from tb_addrestaurent where session_id='$ses_id'");
$u_name="";
$u_pass="";
$session_id="abc";
while($q_data=mysqli_fetch_array($q))
{
	$u_name=$q_data['name'];
	$u_id=$q_data['id'];
	$u_pass=$q_data['password'];
	$session_id=$q_data['session_id'];
}

?>