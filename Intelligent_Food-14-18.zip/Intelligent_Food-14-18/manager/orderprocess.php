<?php include("config.php"); ?>
<!DOCTYPE HTML>
<html>
<head>
<?php include("title.php"); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Novus Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		<div class=" sidebar" role="navigation">
            <?php include("sidebar.php"); ?>
		</div>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				<button id="showLeftPush"><i class="fa fa-bars"></i></button>
				<!--toggle button end-->
				<!--logo -->
				<?php include("logo.php"); ?>
				<!--//logo-->
				<!--search-box-->
				<div class="search-box">
					<?php include("searchbox.php"); ?>
				</div><!--//end-search-box-->
				<div class="clearfix"> </div>
			</div>
			<?php include("notification_menu.php"); ?>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<h3 class="title1">Orders Information</h3>
					
					
					<div class="bs-example widget-shadow" data-example-id="hoverable-table"> 
						<h4>Orders List:</h4>
						<table class="table table-hover"> 
                        <thead> 
                        <tr> 
                        <th>Order #</th> 
                        <th>Type Of Order</th> 
                        <th>Restaurent Name</th>
                         
                        <th>Mobile Number</th>
                        <th>Food</th>
                        <th>Quantity</th>
                         <th>Time</th>
                        <th>Action</th>
                         </tr> 
                          <?php
                           $q = mysqli_query($conn,"SELECT * from tb_customer_order where hotel='$u_name'");
                        while($q_data=mysqli_fetch_array($q)){
	                    $oid=$q_data['order_id'];
						$cid=$q_data['cid'];
						$food = $q_data["food"];
	                    $hotel = $q_data["hotel"];
                        $quantity = $q_data["quantity"];
                       // $useraddress = $q_data["u_address"];
						$userphone = $q_data["u_phone"];
                         $order_type = $q_data["order_type"];
					    $status = $q_data["status"];
						  
						   ?>  
                         </thead>
                          <tbody> 
                          <tr> 
                           <td><?php echo $oid; ?></td>
                            <td><?php echo $order_type; ?></td> 
                            <td><?php echo $hotel; ?></td> 
                            
                            <td><?php echo $userphone;?></td>
                            <td><?php echo $food; ?></td>
                              <td><?php echo $quantity; ?></td>
                            <td>
                            <form action="orderprocess_status.php" method="post"><input type="hidden" value="<?php echo $oid;?>" name="orderid"/><select name="time"><option selected>Select Time </option><option value="10">10 </option><option value="20">20 </option><option value="30">30 </option><option value="40">40 </option></select> <?php if($status == '0') { ?> <a  style="color:#666666; text-decoration:none;" href="orderprocess_status.php?s=1&amp;cid=<?php echo $cid; ?>"><button type="submit">Aprrove</a><?php } if ($status == '1') { ?> <a style="color:#666666; text-decoration:none;" href="orderprocess_status.php?s=0&amp;cid=<?php echo $cid; ?>">Disapprove </a> <?php } ?></button></form>
                            </td>
                           <!-- <td> <?php //if($status == '0') { ?> <a style="color:#666666; text-decoration:none;" href="orderprocess_status.php?s=1&amp;cid=<?php //echo $cid; ?>">Aprrove </a> <?php //} if ($status == '1') { ?> <a style="color:#666666; text-decoration:none;" href="orderprocess_status.php?s=0&amp;cid=<?php //echo $cid; ?>">Disapprove </a> <?php //} ?>
                            </td> -->
                            </tr>
                             <?php } ?>
                             </tbody> 
                                   </table>
					</div>
					
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php include("footer.php"); ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>