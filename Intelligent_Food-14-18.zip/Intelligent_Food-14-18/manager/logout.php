<?php include('config.php'); ?>
<?php

$uupdate=mysqli_query($conn,"update tb_addrestaurent set session_id='0' where session_id='$session_id'");
echo "<meta http-equiv=\"refresh\" content=\"0;URL=../index.php\">";
?>
