-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2018 at 07:02 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ifos`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(16) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'Asad', 'Asadzaman177@gmail.c', 'food', 'asdasa'),
(2, 'usman', 'usmanabid900@yahoo.com', 'Hotel', 'thsi isdiisd'),
(3, 'imran', 'usmanabid900@yahoo.com', 'Hotel', 'ssmsdkks'),
(4, 'imran', 'usmanabid900@yahoo.com', 'Hotel', 'klkk');

-- --------------------------------------------------------

--
-- Table structure for table `tb_addrestaurent`
--

CREATE TABLE IF NOT EXISTS `tb_addrestaurent` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `location` varchar(20) NOT NULL,
  `city` varchar(16) NOT NULL,
  `address` varchar(25) NOT NULL,
  `number` varchar(15) NOT NULL,
  `email` varchar(15) NOT NULL,
  `cnic` varchar(15) NOT NULL,
  `image` varchar(50) NOT NULL,
  `book_menu` varchar(50) NOT NULL,
  `password` varchar(19) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `re_status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tb_addrestaurent`
--

INSERT INTO `tb_addrestaurent` (`id`, `name`, `location`, `city`, `address`, `number`, `email`, `cnic`, `image`, `book_menu`, `password`, `session_id`, `re_status`) VALUES
(1, 'Laliza', 'Pakistan', 'islamabad', 'abc', '123', 'aa@gmail.com', '5456', 'hotel_image/2016-09-04-12-03-38.jpg', 'book_menu/Chapter 10-CS.pdf', '13', '0', 1),
(2, 'Kfc', 'abc', 'axd', 'sadas', '456', 'kfc7@gmail.com', '1234', 'hotel_image/', 'book_menu/', '11', 'dkkbe005uj6tir1pcjmvjk82o5', 1),
(3, 'Monal', 'islamabad', 'islamabad', 'islamabad', '789', 'monal@gmail.com', '456', 'hotel_image/2016-09-21-01-34-23(1).jpg', 'book_menu/Graham Hutton Programming in Haskell  20', '12', '0', 1),
(4, 'mcdonal', 'isb', 'isb', 'sector-b', '03000767314', 'mcdonal@gmail.c', '36502-3910867-7', 'hotel_image/java.jpg', 'book_menu/java.jpg', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_administrator`
--

CREATE TABLE IF NOT EXISTS `tb_administrator` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `session_id` int(255) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tb_administrator`
--

INSERT INTO `tb_administrator` (`aid`, `email`, `password`, `session_id`) VALUES
(1, 'administrator@gmail.com', '123', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_customer_order`
--

CREATE TABLE IF NOT EXISTS `tb_customer_order` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) NOT NULL,
  `food_id` int(10) NOT NULL,
  `food` varchar(15) NOT NULL,
  `hotel` varchar(20) NOT NULL,
  `quantity` int(16) NOT NULL,
  `price` varchar(30) NOT NULL,
  `order_type` varchar(30) NOT NULL,
  `u_phone` varchar(40) NOT NULL,
  `status` int(10) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tb_customer_order`
--

INSERT INTO `tb_customer_order` (`cid`, `order_id`, `food_id`, `food`, `hotel`, `quantity`, `price`, `order_type`, `u_phone`, `status`, `date`) VALUES
(1, 6, 3, 'arabian rice ', 'kfc', 1, '110 ', 'Delivery', '56789', 0, '0000-00-00'),
(2, 6, 1, 'hot wings', 'kfc', 1, '350 ', 'Delivery', '56789', 0, '0000-00-00'),
(3, 6, 4, 'zinger stacker ', 'kfc', 1, '350 ', 'Delivery', '56789', 0, '0000-00-00'),
(4, 6, 4, 'zinger stacker ', 'kfc', 1, '420 ', 'Delivery', '56789', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_deals`
--

CREATE TABLE IF NOT EXISTS `tb_deals` (
  `deals_id` int(10) NOT NULL AUTO_INCREMENT,
  `food_name` varchar(200) NOT NULL,
  `price` varchar(30) NOT NULL,
  `serving` varchar(50) NOT NULL,
  `hotel_name` varchar(200) NOT NULL,
  `quantity` varchar(200) NOT NULL,
  PRIMARY KEY (`deals_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `tb_deals`
--

INSERT INTO `tb_deals` (`deals_id`, `food_name`, `price`, `serving`, `hotel_name`, `quantity`) VALUES
(1, 'hot wings', '350 ', '3', 'kfc', '9pcs'),
(2, 'hot shots ', '300 ', '2', 'kfc', '1bowl'),
(3, 'arabian rice', '110 ', '1', 'kfc', '1burger'),
(4, 'zinger stacker', '420 ', '5', 'kfc', '1serv'),
(5, 'twister', '250 ', '5', 'kfc', '1serv'),
(6, 'fries', '130 ', '2', 'kfc', '1serv'),
(7, 'nuggets', '290 ', '9', 'kfc', '6pieces'),
(8, 'achari alo', '290 ', '4', 'monal', 'half'),
(9, 'mutton paya', '495 ', '4', 'monal', 'full'),
(10, 'mutton paya', '395 ', '2', 'monal', '2pcs'),
(11, 'mix grill', '645 ', '7', 'monal', '4pcs'),
(12, 'mix grill', '1645', '2', 'monal', '2serv'),
(13, 'mix grill', '3195 ', '4', 'monal', '4serv'),
(14, 'shahi platter', '1795 ', '2', 'monal', 'half'),
(15, 'shahi platter', '3595 ', '8', 'monal', 'full'),
(16, 'vegitarian platter', '645 ', '1', 'monal', 'each'),
(17, 'continental breakfast', '300 ', '1', 'monal', '1serv'),
(18, 'nali nihari', '350', '1', 'bala tika house', '1serv'),
(19, 'nali nihari', '350', '1', 'bala tika house', '1serv'),
(20, 'maghaz nihari', '310', '1', 'bala tika house', '1serv'),
(21, 'nihari full', '400', '2', 'bala tika house', '2serv'),
(22, 'nihari single', '200', '1', 'bala tika house', '1serv'),
(23, 'lahori channay', '100', '1', 'bala tika house', '1serv'),
(24, 'chicken channay', '120', '1', 'bala tika house', '1serv'),
(25, 'payee single', '150', '1', 'bala tika house', '1serv'),
(26, 'paye full', '300', '3', 'bala tika house', '3serv'),
(27, 'chicken malai boti', '1100', '5', 'bala tika house', 'per dozen'),
(28, 'chicken boti plain', '800', '4', 'bala tika house', 'per dozen'),
(29, 'chicken kabab lain', '760', '4', 'bala tika house', 'per dozen'),
(30, 'chicken tikka', '140', '1', 'bala tika house', '1serv'),
(31, 'kabab fry', '405', '3', 'bala tika house', 'per dozen'),
(32, 'mutton tikka plain', '1200', '6', 'bala tika house', 'per dozen'),
(33, 'mutton grill chanp', '200', '1', 'bala tika house', '1serv'),
(34, 'beef tikka', '650', '4', 'bala tika house', 'per dozen'),
(35, 'beef kabab mahkani', '700', '4', 'bala tika house', 'per dozen'),
(36, 'batair grill', '110', '1', 'bala tika house', '1serv'),
(37, 'chicken pulao', '160', '1', 'bala tika house', '1serv'),
(38, 'pulao kabab', '130', '1', 'bala tika house', '1serv'),
(39, 'chciken biryani', '180', '1', 'bala tika house', '1serv'),
(40, 'special mushka', '1000', '4', 'bala tika house', '4serv'),
(41, 'simon fish', '1000', '4', 'bala tika house', '4serv'),
(42, 'desi rahu fish', '800', '4', 'bala tika house', '4serv'),
(43, 'daal mash fry', '200', '1', 'bala tika house', '2serv'),
(44, 'daal mash fry mahkni', '200', '1', 'bala tika house', '1serv'),
(45, 'mix sabzi', '160', '1', 'bala tika house', '1serv'),
(46, 'aloo bhukara chatni', '50', '1', 'bala tika house', '1'),
(47, 'russian salad', '120', '1', 'bala tika house', '1'),
(48, 'green salad', '60', '1', 'bala tika house', '1'),
(49, 'green chatni', '70', '1', 'bala tika house', '1'),
(50, 'zeera raita', '130', '2', 'bala tika house', '2serv'),
(51, 'nestle raita', '120', '2', 'bala tika house', '2serv'),
(52, 'chapati', '10', '1', 'bala tika house', '1serv'),
(53, 'kulcha', '10', '1', 'bala tika house', '1serv'),
(54, 'lassi', '100', '2', 'bala tika house', '2serv'),
(55, 'tea', '20', '1', 'bala tika house', '1serv'),
(56, 'green tea', '30', '1', 'bala tika house', '1serv'),
(57, 'mineral water', '35', '1', 'bala tika house', '1serv'),
(58, 'soft drink ', '50', '2', 'bala tika house', '2serv'),
(59, 'fresh lime', '40', '1', 'bala tika house', '1serv'),
(60, 'Pizza', '1200', '6', 'monal', '12kg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_nutrients`
--

CREATE TABLE IF NOT EXISTS `tb_nutrients` (
  `nid` int(10) NOT NULL AUTO_INCREMENT,
  `food_name` varchar(50) NOT NULL,
  `quantity` varchar(30) NOT NULL,
  `calories` varchar(15) NOT NULL,
  `protein` varchar(30) NOT NULL,
  `fats` varchar(20) NOT NULL,
  `carbs` varchar(30) NOT NULL,
  `fibres` varchar(30) NOT NULL,
  `calcium` varchar(30) NOT NULL,
  `vitamins` varchar(30) NOT NULL,
  `sodium` varchar(15) NOT NULL,
  `citric_acid` varchar(15) NOT NULL,
  `others` varchar(15) NOT NULL,
  `healthy` varchar(15) NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tb_nutrients`
--

INSERT INTO `tb_nutrients` (`nid`, `food_name`, `quantity`, `calories`, `protein`, `fats`, `carbs`, `fibres`, `calcium`, `vitamins`, `sodium`, `citric_acid`, `others`, `healthy`) VALUES
(1, 'hot wings', '9pcs', '500g', '23g', '21g', 'nil', '12g', '12g', 'nil', '65g', '33g', '12g', '30%'),
(2, 'hot shots', '1bowl', '400g', 'nil', '45g', '23g', 'nil', 'nil', 'nil', '4g', '53g', '45g', '45%'),
(3, 'arabian rice', '1burger', '230g', '32g', '54g', '100', '8g', '4g', '80', '5g', '54g', '43g', '35%'),
(4, 'zinger stacker', '1serv', '330g', '12g', '65g', '42g', '54g', 'nil', 'nil', '6g', '45g', '76g', '76%'),
(5, 'twister', '1serv', '400g', 'nil', 'nil', '65g', '54g', 'nil', 'nil', '7g', '33g', '54g', '87%'),
(6, 'fries', '1serv', '300g', '35g', '65g', '53g', '54g', '98g', '33g', '8g', '33g', '43g', '98%'),
(7, 'muggets', '6pcs', '200g', '54g', '75g', 'nil', 'nil', '78g', '7g', '77g', '23g', '53g', '65%'),
(8, 'achari alo', 'half', '900g', '65g', '68g', '14g', '56g', '86g', '8g', '88g', '23g', '53g', '76%'),
(9, 'mutton paya', '2pcs', '123g', '65g', 'nil', '14g', '67g', '67g', '9g', '44g', '3g', '355g', '87%'),
(10, 'mutton paya ', '4pcs', '323g', '34g', '09g', '01g', 'nil', '57g', '45g', '3g', '64g', '23g', '98%'),
(11, 'mix grill', '4pcs', '121g', '45g', '87g', '87g', '45g', '46g', '23g', '2g', 'nil', '200g', '23%'),
(12, 'mix grill', '2serv', '535g', '33g', '98g', 'nil', '65g', '34g', 'nil', '1g', 'nil', '44g', '98%'),
(13, 'mix grill', 'half', '656g', '64g', '76g', '45g', '65g', '54g', '3g', '2g', 'nil', '098g', '45%'),
(14, 'shahi platter ', 'full', '565g', '56g', '56g', 'nil', 'nil', '76g', '4g', '3g', 'nil', '23g', '22%'),
(15, 'shahi platter', 'each', '677g', '32g', '65g', '45g', '76g', 'nil', '5g', '4g', 'nil', '756g', '32%'),
(16, 'vegitarian platter', '1serv', '536g', '42g', 'nil', '54g', '3g', 'nil', '6g', '6g', 'nil', '343g', '12%');

-- --------------------------------------------------------

--
-- Table structure for table `tb_promotion`
--

CREATE TABLE IF NOT EXISTS `tb_promotion` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `food_name` varchar(100) NOT NULL,
  `percentage_of` varchar(15) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tb_promotion`
--

INSERT INTO `tb_promotion` (`pid`, `food_name`, `percentage_of`, `message`) VALUES
(1, 'mix grill', '30', 'Hurry up');

-- --------------------------------------------------------

--
-- Table structure for table `tb_register`
--

CREATE TABLE IF NOT EXISTS `tb_register` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `cnic` varchar(16) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `password` varchar(20) NOT NULL,
  `session_id` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tb_register`
--

INSERT INTO `tb_register` (`id`, `username`, `email`, `cnic`, `phone`, `password`, `session_id`) VALUES
(1, 'Ali', 'asa@gmail.com', '123', '123', '11', '0'),
(2, 'Sajid', 'aa@g.com', '123', '456', 'aa', '0'),
(3, 'Naveed', 'Asadzaman187@gmail.c', '123', '21', 'aa', '0'),
(4, 'Qasim', 'Asadzaman17@gmail.com', '172015656', '03139313277', 'as', '0'),
(5, 'username', 'email', 'cnic', 'phone', 'password', '0'),
(6, 'Asad', 'Asadzaman177@gmail.com', '123456', '56789', 'aa', 'dkkbe005uj6tir1pcjmvjk82o5'),
(7, 'Pervaiz', 'Asadzaman178@gmail.com', '789', '444', '11', '0'),
(8, 'Usman', 'usman@gmail.com', '33334', '99494', '11', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tb_time`
--

CREATE TABLE IF NOT EXISTS `tb_time` (
  `tid` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` int(10) NOT NULL,
  `timetable` varchar(30) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tb_time`
--

INSERT INTO `tb_time` (`tid`, `orderid`, `timetable`) VALUES
(1, 0, ''),
(2, 0, ''),
(3, 0, ''),
(4, 0, ''),
(5, 0, ''),
(6, 0, ''),
(7, 0, ''),
(8, 8, 'Select Time'),
(9, 8, '20'),
(10, 0, ''),
(11, 0, ''),
(12, 0, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
