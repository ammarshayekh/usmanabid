// JavaScript Document
function validationform(){
	var username = document.registration.username;
	var email = document.registration.email;
	var cnic = document.registration.cnic;
	var phone = document.registration.phone;
	var password = document.registration.password;
	var confirmpassword = document.registration.confirmpassword;
	
	 if(username_validation(username))
	 {
        if(email_validation(email))
				 {
		   if(cnic_validation(cnic)){
				  if(phone_validation(phone))
				   {
					if(password_validation(password,confirmpassword))
					 {
			           }
						}
						 }
						  }
	 }
							return false;	
		}
		function username_validation(username){
		
	   var letters = /^[A-Za-z]+$/;   
		if(username.value.match(letters))
		{
		
			return true;
		}
		
	else 
	{  
       alert("User Name must have alphabet characters only!");  
       username.focus();  
       return false;  
     } 
		
     }
	
    function email_validation(email){
		
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
		if(email.value.match(mailformat))
		{
		
			return true;
		}
		
	else 
	{  
       alert("You have entered an invalid email address!");  
       email.focus();  
       return false;  
     } 
		
}
 function cnic_validation(cnic){
		var cnic_length = cnic.value.length;
		
	if(cnic_length==0)
		{
			alert("Enter your cnic number");
			cnic.focus();
			return false;
		}

	    return true;
	
	}
	function phone_validation(phone){
		var phone_length = phone.value.length;
		
	if(phone_length==0)
		{
			alert("Enter your phone number");
			phone.focus();
			return false;
		}

	    return true;
	
	}
	function password_validation(password,confirmpassword){
		var password_length = password.value.length;
		var confirmpassword_length = confirmpassword.value.length;
	    
		if(password_length==0 || confirmpassword_length==0)
		{
			alert("Enter password and confirm password");
			password.focus();
			confirmpassword.focus();
			return false
			}
		else if(password_length != confirmpassword_length)
		{
			alert("Passwords do not match.");
			confirmpassword.focus();
			return false;
		}
		
	   else
	   {	
	     alert("Form submitted Succesfully");
	     return true;
	    }	
		
		}
	
		