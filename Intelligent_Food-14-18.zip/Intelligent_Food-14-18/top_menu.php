<div class="top-menu">
					<ul>
						<li class="active"><a href="index.php" class="scroll">Home</a></li>|
						<li><a href="restaurants.php">Popular Restaurants</a></li>|
                        <li><a href="AddRestaurent.php">Add Restaurants</a></li>|
						<li><a href="order.php">Order</a></li>|
						<li><a href="contact.php">contact</a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
                <div class="container">
				
				<div class="login-section">
					<ul>
						<li><a href="login.php">User Sign In</a>  </li> |
						<li><a href="register.php">User Sign Up</a> </li> |
						<li><a href="manager_login.php">Manager Sign In</a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>