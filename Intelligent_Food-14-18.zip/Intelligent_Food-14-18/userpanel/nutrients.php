<?php include("config.php"); ?>

<!DOCTYPE HTML>
<html>
<head>
<?php include("title.php"); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Novus Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		<div class=" sidebar" role="navigation">
            <?php include("sidebar.php"); ?>
		</div>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				<button id="showLeftPush"><i class="fa fa-bars"></i></button>
				<!--toggle button end-->
				<!--logo -->
				<?php include("logo.php"); ?>
				<!--//logo-->
				<!--search-box-->
				<div class="search-box">
					<?php include("searchbox.php"); ?>
				</div><!--//end-search-box-->
				<div class="clearfix"> </div>
			</div>
			<?php include("notification_menu.php"); ?>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<h3 class="title1">Nutrients</h3>
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Food Incredients :</h4>
						</div>
						<div class="form-body">
							<form action="nutrients.php" method="post">
                             <div class="form-group"> 
                             <label for="exampleInputEmail1">Food Name</label> 
                             <input type="text" name="food" class="form-control" id="exampleInputEmail1">
                              </div> 
                             
                                <button type="submit" class="btn btn-default">Search</button>
                                 </form>
                                 <br> 
                                 <div>
                                 <table class="table table-bordered">
                         <thead> 
                         <tr> 
                         <th>#</th> 
                         <th>Food Name</th> 
                         <th>Quantity</th> 
                         <th>Calories</th> 
                         <th>Protein</th> 
                         <th>Fats</th> 
                         <th>Carbs</th>
                         <th>Fibres</th>
                         <th>Calcium</th>
                         <th>Vitamins</th>
                         <th>Sodium</th> 
                         <th>Citric Acid </th> 
                         <th>Others</th>
                         <th>Healthy</th>  
                         </tr> 
                         <?php
						  //$food_name='';
						 $food_name=$_POST['food'];
                        $q = mysqli_query($conn,"SELECT * from tb_nutrients where food_name='$food_name'");
                        while($q_data=mysqli_fetch_array($q)){
	 
	                    $id=$q_data['nid'];
						$food = $q_data["food_name"];
	                    $quantity = $q_data["quantity"];
						 $calories = $q_data["calories"];
                        $protein = $q_data["protein"];
                        $fats = $q_data["fats"];
                         $carbs = $q_data["carbs"];
						 $fibres = $q_data["fibres"];
						 $calciun = $q_data["calcium"];
						 $vitamins = $q_data["vitamins"];
						  $sodium = $q_data["sodium"];
						   $citric_acid = $q_data["citric_acid"];
						    $others = $q_data["others"];
							 $healthy = $q_data["healthy"];
                          ?>
                         </thead> 
                         <tbody> 
                         <tr>
                            <td><?php echo $id; ?></td>
                           <td><?php echo $food; ?></td>
                            <td><?php echo $quantity; ?></td>
                             <td><?php echo $calories; ?></td>
                             <td><?php echo $protein; ?></td> 
                             <td><?php echo $fats; ?></td> 
                             <td><?php echo $carbs; ?></td>
                              <td><?php echo $fibres; ?></td>
                               <td><?php echo $calciun; ?></td>
                                <td><?php echo $vitamins; ?></td>
                                 <td><?php echo $sodium; ?></td>
                                  <td><?php echo $citric_acid; ?></td>
                                   <td><?php echo $others; ?></td>
                                    <td><?php echo $healthy; ?></td>
                              
                               </tr>
                            <?php } ?>
                            </tbody>
                            </table>
                            </div>
						</div>
					</div>
					
					
					
					
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php include("footer.php"); ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>