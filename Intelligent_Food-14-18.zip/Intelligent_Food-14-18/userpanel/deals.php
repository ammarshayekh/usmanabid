<?php include("config.php"); ?>
<!DOCTYPE HTML>
<html>
<head>
<?php include("title.php"); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Novus Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		<div class=" sidebar" role="navigation">
            <?php include("sidebar.php"); ?>
		</div>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				<button id="showLeftPush"><i class="fa fa-bars"></i></button>
				<!--toggle button end-->
				<!--logo -->
				<?php include("logo.php"); ?>
				<!--//logo-->
				<!--search-box-->
				<div class="search-box">
					<?php include("searchbox.php"); ?>
				</div><!--//end-search-box-->
				<div class="clearfix"> </div>
			</div>
			<?php include("notification_menu.php"); ?>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
        <?php 
		$price=$_POST["price"];
		$qf=mysqli_query($conn,"select * from tb_deals where price<=$price");
while($qf_data=mysqli_fetch_array($qf))
{
	$food=$qf_data['food_name'];
	$deals_id=$qf_data['deals_id'];
	$hotel=$qf_data['hotel_name'];
	$serving=$qf_data['serving'];
	$pdre=$qf_data['price'];
		?>
			<div class="main-page general">
				<h3 class="title1">Deals</h3>
				<div class="panel-info widget-shadow">
					
					
					<div class="col-md-6 panel-grids">
						<div class="panel panel-primary"> 
                        <div class="panel-heading"> 
                        <h3 class="panel-title">Hotel Name: <?php echo $hotel; ?></h3>
                         </div> 
                        <div class="panel-body">
                      
                        <h4><b>Food Name</b>: <?php echo $food;?></h4>
                        <h4><b>Serving Person</b>: <?php echo $serving;?></h4>
                         <h4><b>Price</b>: <?php echo $pdre;?> Rs.</h4>
                          <form action="pre_order.php" method="post">
                          <input type="hidden" name="foodname" value="<?php echo $food;?>"/>
                            <input type="hidden" name="dealsid" value="<?php echo $deals_id;?>"/>
                          <input type="hidden" name="hotelname" value="<?php echo $hotel?>"/>
                          <input type="hidden" name="price" value="<?php echo $pdre?>"/>
                      <input type="submit" value="Order Now" class="btn btn-default">
                        </form>
                        
                         </div>
                      </div>
					</div>
					
					<div class="clearfix"> </div>
				</div>
			</div>
            <?php }?>
		</div>
		<!--footer-->
		<?php include("footer.php"); ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>