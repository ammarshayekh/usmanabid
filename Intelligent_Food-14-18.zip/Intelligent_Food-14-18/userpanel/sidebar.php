<div class="navbar-collapse">
				<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
					<ul class="nav" id="side-menu">
						<li>
							<a href="index.php" class="active"><i class="fa fa-home nav_icon"></i>Dashboard</a>
						</li>
						<li>
							<a href="home.php?search=''"><i class="fa fa-cogs nav_icon"></i>Home<span class="fa arrow"></span></a>
							
							<!-- /nav-second-level -->
						</li>
                        <li>
							<a href="#"><i class="fa fa-check-square-o nav_icon"></i>Budget Estimation<span class="fa arrow"></span></a>
							<ul class="nav nav-second-level collapse">
								<li>
									<a href="budget_estimation.php">Budget Estimation </a>
								</li>
                               <!--
								<li>
									<a href="validation.php">Validation</a>
								</li>
                                -->
                            
                               
							</ul>
							<!-- //nav-second-level -->
						</li>
						
						<li>
							<a href="nutrients.php?food=''"><i class="fa fa-th-large nav_icon"></i>Nutrient Food</a>
						</li>
						
						
						
						<li>
							<a href="#"><i class="fa fa-file-text-o nav_icon"></i>Profile<span class="fa arrow"></span></a>
							<ul class="nav nav-second-level collapse">
								
								<li>
									<a href="profile.php">Update Profile</a>
								</li>
								<li>
									<a href="changepassword.php">Change Password</a>
								</li>
							</ul>
							<!-- //nav-second-level -->
						</li>
						
					</ul>
					<!-- //sidebar-collapse -->
				</nav>
			</div>