<?php include('config.php');

$userid=''; $food=''; $hotel='';$quantity='';$price='';$ordertype='';

if(isset($_POST['userid']) && !empty($_POST['userid']) AND isset($_POST['food']) && !empty($_POST['food'])AND isset($_POST['deals_id']) && !empty($_POST['deals_id']) AND isset($_POST['hotel']) && !empty($_POST['hotel'])AND isset($_POST['quantity']) && !empty($_POST['quantity'])AND isset($_POST['price']) && !empty($_POST['price'])AND isset($_POST['ordertype']) && !empty($_POST['ordertype'])){
      $userid = $_POST['userid']; 
	  $food = $_POST['food'];
	   $deals_id = $_POST['deals_id']; 
	  $hotel = $_POST['hotel']; 
	  $quantity = $_POST['quantity']; 
	  $price = $_POST['price'];
	  $ordertype = $_POST['ordertype'];
      
   mysqli_query($conn,"insert into tb_customer_order(order_id,food_id,food,hotel,quantity,price,order_type,u_phone)values('$userid','$deals_id','$food','$hotel','$quantity','$price','$ordertype','$u_phone')");
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
echo "<script>alert('Your Request is Submitted.Please Wait for Manager Approval!');</script>"; 

}
$userid=''; $food=''; $hotel='';$quantity='';$price='';$ordertype1='';

if(isset($_POST['userid']) && !empty($_POST['userid']) AND isset($_POST['food']) && !empty($_POST['food']) AND isset($_POST['hotel']) && !empty($_POST['hotel'])AND isset($_POST['quantity']) && !empty($_POST['quantity'])AND isset($_POST['price']) && !empty($_POST['price'])AND isset($_POST['ordertype1']) && !empty($_POST['ordertype1'])){
      $userid = $_POST['userid']; 
	  $food = $_POST['food']; 
	  $hotel = $_POST['hotel']; 
	  $quantity = $_POST['quantity']; 
	  $price = $_POST['price'];
	  $ordertype1 = $_POST['ordertype1'];
      
   mysqli_query($conn,"insert into tb_customer_order(order_id,food,hotel,quantity,price,order_type,u_phone)values('$userid','$food','$hotel','$quantity','$price','$ordertype1','$u_phone')");
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
echo "<script>alert('Your Request is Submitted.Please Wait for Manager Approval!');</script>"; 


}
 ?>
<!DOCTYPE HTML>
<html>
<head>
<?php include("title.php"); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Novus Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		<div class=" sidebar" role="navigation">
            <?php include("sidebar.php"); ?>
		</div>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				<button id="showLeftPush"><i class="fa fa-bars"></i></button>
				<!--toggle button end-->
				<!--logo -->
				<?php include("logo.php"); ?>
				<!--//logo-->
				<!--search-box-->
				<div class="search-box">
					<?php include("searchbox.php"); ?>
				</div><!--//end-search-box-->
				<div class="clearfix"> </div>
			</div>
			<?php include("notification_menu.php"); ?>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page general">
				<h3 class="title1">Pre-Ordering</h3>
				<div class="panel-info widget-shadow">
					<div class="col-md-6 panel-grids">
						<div class="panel panel-primary">
                         <div class="panel-heading"> 
                         <h3 class="panel-title">Pre-Ordering</h3>
                          </div>
                          
                          <?php 
		               
	                    $food=$_POST['foodname'];
						$dealsid=$_POST['dealsid'];
	                    $hotel=$_POST['hotelname'];
	                    $pdre=$_POST['price'];
		                ?>
                          
                          <div class="form-body">
							<form action="pre_order.php" method="post">
                            <input type="hidden" name="userid" value="<?php echo $u_id;?>"/>
                             <input type="hidden" name="deals_id" value="<?php echo $$dealsid;?>"/>
                              <div class="form-group"> 
                              <label>Hotel Name:</label>
                               <select name="hotel" disabled> 
                                 <option value="<?php echo $hotel ?>"><?php echo $hotel ?></option>
                               
</select>  </div> 

                                 <div class="form-group">
                              <label>Food Name:</label> 
                              <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Food Name" name="food" value="<?php echo $food ?> " disabled> 
                              </div> 
                                <div class="form-group">
                                 <label>Quantity:</label>
                                 <select name="quantity" > 
                                 <option value="1">1</option>
                                 <option value="2">2</option>
                                 <option value="3">3</option>
                                 <option value="4">4</option>
                                 </select> 
                                 </div>
                                 <div class="form-group">
                              <label>Price:</label> 
                       <input type="text" class="form-control" id="exampleInputEmail1" name="price" value="<?php echo $pdre ?>" disabled> 
                              </div> 
                                   
  <button type="submit" name="ordertype" value="Delivery" class="btn btn-default" >Delivery</button> 
  <button type="submit" name="ordertype1" value="BookTable" class="btn btn-default">Book Table</button>
  <a href="budget_estimation.php"><button type="button" name="ordertype1" class="btn btn-default">Cancel</button></a>
                                  </form> 
						</div>
                   
                       
                     </div>
					</div>
					
					
					
					
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<!--footer-->
		<?php include("footer.php"); ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
   
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>