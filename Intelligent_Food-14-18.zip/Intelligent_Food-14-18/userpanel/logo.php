<div class="logo">
					<a href="index.php">
						<h1>IFOS</h1>
						<span>User Panel</span>
					</a>
				</div>