<?php include("config.php"); ?>
<!DOCTYPE HTML>
<html>
<head>
<?php include("title.php"); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Novus Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		<div class=" sidebar" role="navigation">
            <?php include("sidebar.php"); ?>
		</div>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				<button id="showLeftPush"><i class="fa fa-bars"></i></button>
				<!--toggle button end-->
				<!--logo -->
				<?php include("logo.php"); ?>
				<!--//logo-->
				<!--search-box-->
				<div class="search-box">
					<?php include("searchbox.php"); ?>
				</div><!--//end-search-box-->
				<div class="clearfix"> </div>
			</div>
			<?php include("notification_menu.php"); ?>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<div class="table-responsive bs-example widget-shadow">
						<h4>Registered Restaurents:</h4>
						<table class="table table-bordered">
                         <thead> 
                         <tr> 
                         <th>#</th> 
                         <th>Restaurent Name</th> 
                         <th>Location</th> 
                         <th>Contact Number</th> 
                         <th>Email</th> 
                         <th>Book Menu</th>
                         <th>Action</th>
                         </tr> 
                         <?php
                        $q = mysqli_query($conn,"SELECT * from tb_addrestaurent");
                        while($q_data=mysqli_fetch_array($q)){
	 
	                    $id=$q_data['id'];
						$name=$q_data["name"];
	                    $location=$q_data["location"];
                        $number=$q_data["number"];
                        $email=$q_data["email"];
                         $book_menu=$q_data["book_menu"];
						  $status=$q_data["re_status"];
                          ?>
                         </thead> 
                         <tbody> 
                         <tr>
                            <td><?php echo $id; ?></td>
                           <td><?php echo $name; ?></td>
                            <td><?php echo $location; ?></td>
                             <td><?php echo $number; ?></td> 
                             <td><?php echo $email; ?></td> 
                             <td><?php echo $book_menu; ?></td>
                            <td> <?php if($status == '0') { ?> <a style="color:#666666; text-decoration:none;" href="hotel_status.php?s=1&amp;cid=<?php echo $id; ?>">Aprrove </a> <?php } if ($status == '1') { ?> <a style="color:#666666; text-decoration:none;" href="hotel_status.php?s=0&amp;cid=<?php echo $id; ?>">Disapprove </a> <?php } ?></td>
                              
                               </tr>
                            <?php } ?>
                            </tbody>
                            </table>
					</div>
				</div>
			</div>
		</div>
		<!--footer-->
		<?php include("footer.php"); ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>