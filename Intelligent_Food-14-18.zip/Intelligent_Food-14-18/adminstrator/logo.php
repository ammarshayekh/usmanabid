<div class="logo">
					<a href="index.php">
						<h1>IFOS</h1>
						<span>Admin Panel</span>
					</a>
				</div>