﻿<?php
include("config.php");
$sts = $_REQUEST['s'];
$oid = $_REQUEST['cid'];
if($sts=='1')
{
$q=mysqli_query($conn,"select * from tb_addrestaurent");

while($q_data=mysqli_fetch_array($q))
{
	$emailad=$q_data['email'];
	$u_pass=$q_data['password'];
	
}
$subject = "Delivery";
 
 $to = "$emailad";
 
 $cust_msg ="Your Password is: $u_pass <br> and Your Email is:$emailad";
 
 $headers = "From: $to";
 
 $sent = mail($to, $subject, $cust_msg, $headers);
if($sent)
 
{ //echo " Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly.";
      echo "<script>alert('Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly.');</script>";
     $update= mysqli_query($conn,"update tb_addrestaurent set re_status = '$sts' where id = '$oid'");
     echo "<meta http-equiv=\"refresh\" content=\"0;URL=restaurents_record.php\">";
}

}
else
{
	$update= mysqli_query($conn,"update tb_addrestaurent set re_status = '$sts' where id = '$oid'");
    echo "<meta http-equiv=\"refresh\" content=\"0;URL=restaurents_record.php\">";
}
//Block 1
/*$user = "user_name"; 
$password = "password"; 
$host = "host_name"; 
$dbase = "database_name"; 
$table = "table_name"; 

//Block 2
$from= 'email_address';

//Block 3
$subject= $_POST['subject'];
$body= $_POST['body'];

//Block 4
$dbc= mysqli_connect($host,$user,$password, $dbase) 
or die("Unable to select database");

//Block 5
$query= "SELECT * FROM $table";
$result= mysqli_query ($dbc, $query) 
or die ('Error querying database.');

//Block 6
while ($row = mysqli_fetch_array($result)) {
$first_name= $row['first_name'];
$last_name= $row['last_name'];
$email= $row['email'];

//Block 7
$msg= "Dear $first_name $last_name,\n$body";
mail($email, $subject, $msg, 'From:' . $from);
echo 'Email sent to: ' . $email. '<br>';
}

//Block 8
mysqli_close($dbc);*/
?>