<div class="navbar-collapse">
				<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
					<ul class="nav" id="side-menu">
						<li>
							<a href="dashboard.php" class="active"><i class="fa fa-home nav_icon"></i>Dashboard</a>
						</li>
                      
						
						
						<li>
							<a href="restaurents_record.php"><i class="fa fa-table nav_icon"></i>Registered Restaurents<span class="nav-badge">05</span></a>
						</li>
						
						
					</ul>
					<!-- //sidebar-collapse -->
				</nav>
			</div> 