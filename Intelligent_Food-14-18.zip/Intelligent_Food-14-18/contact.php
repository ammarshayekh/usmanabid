<?php
include("config.php");

$name=''; $email=''; $subjectt='';$message='';

if(isset($_POST['name']) && !empty($_POST['name']) AND isset($_POST['email']) && !empty($_POST['email']) AND isset($_POST['subjectt']) && !empty($_POST['subjectt'])AND isset($_POST['message']) && !empty($_POST['message'])){
      $name = $_POST['name']; // Turn our post into a local variable
	  $email = $_POST['email']; // Turn our post into a local variable
	  $subjectt = $_POST['subjectt']; // Turn our post into a local variable
	  $message = $_POST['message']; // Turn our post into a local variable
	  $email_from = "zamboads@gmail.com";
 
 $subject = $_REQUEST['subjectt'];
 
 $to = $_REQUEST['email'];
 
 $cust_msg = $_REQUEST['message'];
 
 $headers = "From: $to";
 
 $sent = mail($to, $subject, $cust_msg, $headers);

 if($sent)
 
{ //echo " Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly.";
 echo "<script>alert('Thank your Sir/Madam for contacting us. Your email successfully sent. Our Team will contact you shortly.');</script>"; 
      
   mysqli_query($conn,"insert into contact_us(name,email,subject,message)values('$name','$email','$subjectt','$message')");
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
}
}
?>
<!DOCTYPE html>
<html>
<head>
<?php include("title.php"); ?>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->
<script src="js/wow.min.js"></script>
<link href="css/animate.css" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
<script src="js/simpleCart.min.js"> </script>	
</head>
<body>
    <!-- header-section-starts -->
	<div class="header">
		<div class="container">
			<?php include("top_header.php"); ?>
		</div>
			<div class="menu-bar">
			<?php include("top_menu.php"); ?>
		</div>
	<!-- header-section-ends -->
	<div class="contact-section-page">
		<div class="contact-head">
		    <div class="container">
				<h3>Contact</h3>
				<p>Home/Contact</p>
			</div>
		</div>
		<div class="contact_top">
			 		<div class="container">
			 			<div class="col-md-6 contact_left wow fadeInRight" data-wow-delay="0.4s">
			 				<h4>Contact Form</h4>
			 				<p>Dear user!
We are here to help you. All you need is to fill in the following form and our help providing centre will contact you shortly!!</p>
							  <form action="contact.php" method="post">
								 <div class="form_details">
					                 <input type="text" name="name" class="text" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}">
									 <input type="text" name="email" class="text" value="Email Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email Address';}">
									 <input type="text" name="subjectt" class="text" value="Subject" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Subject';}">
									 <textarea value="Message" name="message" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}">Message</textarea>
									 <div class="clearfix"> </div>
									 <div class="sub-button wow swing animated" data-wow-delay= "0.4s">
									 	<input name="submit" type="submit" value="Send message">
									 </div>
						          </div>
						       </form>
					        </div>
					        <div class="col-md-6 company-right wow fadeInLeft" data-wow-delay="0.4s">
					        	<div class="contact-map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1578265.0941403757!2d-98.9828708842255!3d39.41170802696131!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited+States!5e0!3m2!1sen!2sin!4v1407515822047"> </iframe>
		</div>
      
	  <div class="company-right">
					        	<div class="company_ad">
							     		<h3>Contact Info</h3>
							     		<span>Our customer support team provides the best service. We're always happy to help you in finding the solution of your needs. We will try our best to resolve your issues and fulfil your needs.</span>
			      						<address>
											 <p>email:<a href="mailto:info@example.com">info@ifos.com</a></p>
											 <p>phone:  +92 332 502 1480</p>
									   		<p>House # 38,</p>
									   		<p>Islamabad, Pakistan</p>
									 	 	
							   			</address>
							   		</div>
									</div>	
									<div class="follow-us">
										<h3>follow us on</h3>
										<a href="#"><i class="facebook"></i></a>
										<a href="#"><i class="twitter"></i></a>
										<a href="#"><i class="google-pluse"></i></a>
									</div>
			
							
							 </div>
						</div>
					</div>

	</div>
	<!-- footer-section-starts -->
	<div class="footer">
		<?php include("footer.php"); ?>
	</div>
	<!-- footer-section-ends -->
	  <script type="text/javascript">
						$(document).ready(function() {
							/*
							var defaults = {
					  			containerID: 'toTop', // fading element id
								containerHoverID: 'toTopHover', // fading element hover id
								scrollSpeed: 1200,
								easingType: 'linear' 
					 		};
							*/
							
							$().UItoTop({ easingType: 'easeOutQuart' });
							
						});
					</script>
				<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

</body>
</html>