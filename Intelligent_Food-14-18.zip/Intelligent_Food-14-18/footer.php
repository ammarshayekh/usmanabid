<div class="container">
			<p class="wow fadeInLeft" data-wow-delay="0.4s">&copy; 2018  All rights  Reserved | Designned by &nbsp;<a href="http://www.technocation.pk" target="target_blank">IFOS</a></p>
		</div>