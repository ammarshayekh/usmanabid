<?php
include("config.php");
$user_cnicno=''; $user_password='';
   if(isset($_POST['user_cnicno']) && !empty($_POST['user_cnicno']) AND isset($_POST['user_password']) && !empty($_POST['user_password'])){
   
	 $user_cnicno = mysql_escape_string($_POST['user_cnicno']); // Turn our post into a local variable
	  $user_password = mysql_escape_string($_POST['user_password']); // Turn our post into a local variable
	   


$ll=mysql_query("select * from amc_user where user_cnicno='$user_cnicno' and user_password='$user_password'",$con);
$cnicno="";
$passwordd="";
if($ll === FALSE) {
    die(mysql_error()); // TODO: better error handling
}
while($hh_data=mysql_fetch_array($ll))
{
	$cnicno=$hh_data['user_cnicno'];
	$passwordd=$hh_data['user_password'];
	
}
if(($user_cnicno == $cnicno) && ($user_password == $passwordd))
{
	echo "<script>alert('You are Successfull Login');</script>";
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_admin_panel/index.php\">";
	mysql_query("update amc_user set user_session_id='$ses_id' where user_cnicno='$user_cnicno' and user_password = '$user_password'",$con);
}
else
{
	echo "<script>alert('CNIC NO AND PASSWORD IS INCORRECT!');</script>";
	//echo "Email and Password is inCorrect";
	}
   }
   ?>
<html>
<head>
<title>User Login Form</title>
<style type="text/css">
h3{font-family: Calibri; font-size: 22pt; font-style: normal; font-weight: bold; color:#06F;
text-align: center; text-decoration: underline }
table{font-family: Calibri; color:white; font-size: 11pt; font-style: normal;
text-align:; background-color:#3391E7; border-collapse: collapse; border: 2px solid #3391E7;}
table.inner{border: 0px}
</style>
</head>
<body>
<h3>USER LOGIN FORM</h3>
<form action="" method="POST">
 
<table align="center" cellpadding = "10">
<!----- Last Name ---------------------------------------------------------->
<tr>
<td>CNIC NO</td>
<td><input type="text" name="user_cnicno" maxlength="30"/>
</td>
</tr>
<!----- Password ---------------------------------------------------------->
<tr>
<td>PASSWORD</td>
<td><input type="password" name="user_password" maxlength="15" />
</td>
</tr>
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" value="Login">
</td>
</tr>
</table>
 
</form>
 
</body>
</html>