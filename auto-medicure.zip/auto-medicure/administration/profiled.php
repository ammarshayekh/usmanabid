<?php
include('config.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Profile</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $adm_name;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
         <?php  
	 
	 $q=mysql_query("select * from amc_administration where session_id='$ses_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $drname =$q_data['adm_name'];
		 $drcnicno =$q_data['adm_cnicno'];
		
	 }
	  ?>     
        <div class="analyst_right" style="height:auto;border:1px solid #999;">
        
         <div style="width:460px; height:auto; margin-left:50px;">
         <form method="post" action="">
         
         <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:left; margin-top:10px;">NAME</div>
          <div style="width:115px; float:left; text-align:left;margin-top:7px;"><?php echo $drname;?></div>
          </div>
          <hr />
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:left; margin-top:10px;">CNIC #</div>
          <div style="width:115px; float:left; text-align:left;margin-top:7px;"><?php echo $drcnicno;?></div>
          </div>
          <hr />
         <div style="width:460px; height:40px;">
         <div style="width:50px;height:20px; float:left; padding-top:5px;border-radius:5px 5px 5px 5px; background-color:#36F; float:left; text-align:center; margin-top:10px; margin-left:230px;"><a href="profile.php" style="background-color:#36F;width:80px;  text-decoration:none;color:#FFF; height:25px;  border-color:#36F; cursor:pointer;">EDIT</a></div>
           <div style="width:150px;height:20px; float:left; padding-top:5px;border-radius:5px 5px 5px 5px; background-color:#36F; float:left; text-align:center; margin-top:10px; margin-left:10px;"><a href="changepassword.php" style="background-color:#36F;width:160px;  text-decoration:none;color:#FFF; height:25px;  border-color:#36F; cursor:pointer;">CHANGE PASSWORD</a></div>
           <div style="clear:both"></div>
          </div>
         </form>
         </div>
        
         
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>