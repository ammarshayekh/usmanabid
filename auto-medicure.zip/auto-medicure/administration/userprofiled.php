<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Profile</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $adm_name;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
         <?php  
	 $upfoid=$_REQUEST['upfoid'];
	 $q=mysql_query("select * from amc_user where user_id='$upfoid'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $username =$q_data['user_name'];
		 $usercnicno =$q_data['user_cnicno'];
		 $userage =$q_data['user_age'];
		 $useremail =$q_data['user_email'];
		 $usercellno =$q_data['user_cellno'];
		 $usergender =$q_data['user_gender'];
		 $useraddress =$q_data['user_address'];
		 $usercity =$q_data['user_city'];
		 $userpincode =$q_data['user_pincode'];
		 $userstate =$q_data['user_state'];
		 $usercountry =$q_data['user_country'];
		
	 }
	  ?>     
        <div class="analyst_right" style="height:auto; margin-top:0px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         
         <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $username;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CNIC #</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $usercnicno;?></div>
          </div>
            <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">AGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $userage;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">E-MAIL</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $useremail;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CELL #</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $usercellno;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">GENDER</div>
          <div style="width:57px; float:left; text-align:center;margin-top:7px; margin-left:15px;"><?php echo $usergender;?></div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">ADDRESS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $useraddress;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CITY</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $usercity;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">ZIP CODE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $userpincode;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">STATE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $userstate;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">COUNTRY</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $usercountry;?></div>
          </div>
          
          
          
          
         </form>
         </div>
        
         
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>