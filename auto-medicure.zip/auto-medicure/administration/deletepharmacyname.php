<?php include('config.php'); ?>
<?php
$phadid = $_REQUEST['phadid'];
$uupdate=mysql_query("delete from amc_pharmacy_name  where pharmacy_id='$phadid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=addpharmacyname.php\">";
echo "<script>alert('PHARMACY NAME REMOVE SUCCESSFULLY!');</script>";
?>
