<?php include('config.php'); ?>
<?php

$uupdate=mysql_query("update amc_administration set session_id='0' where session_id='$ses_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
?>
