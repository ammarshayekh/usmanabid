<?php
include('config.php');
$adm_opassword=''; $uname='';$uemail='';$adm_npassword='';$adm_cpassword='';

   if(isset($_POST['adm_password']) && !empty($_POST['adm_password'])AND isset($_POST['adm_npassword']) && !empty($_POST['adm_npassword'])AND isset($_POST['adm_cpassword']) && !empty($_POST['adm_cpassword'])){
	$adm_opassword = mysql_escape_string($_POST['adm_password']); // Turn our post into a local variable
	$adm_npassword = mysql_escape_string($_POST['adm_npassword']); // Turn our post into a local variable
	$adm_cpassword = mysql_escape_string($_POST['adm_cpassword']); // Turn our post into a local variable
	//echo $dr_cpassword;
	   
	   $qq=mysql_query("select * from amc_administration where session_id='$ses_id'",$con);
	 while($qq_data=mysql_fetch_array($qq))
	 {
		 
		$adm_password=$qq_data['adm_password'];
		
	 }
	   if($adm_opassword != $adm_password)
	   {
		   //echo "Old Password Is Incorrect.Please Try Again.<a href='profile.php'>Click Here</a>";
		   echo "<script>alert('Old Password Is Incorrect.Please Try Again!');</script>";
		    echo "<meta http-equiv=\"refresh\" content=\"0;URL=changepassword.php\">";
		   exit();
	   }
	   if($adm_npassword != $adm_cpassword)
	   {
		   //echo "New Password and Confirm Password Is not Matched.Please Try Again.<a href='profile.php'>Click Here</a>";
		   echo "<script>alert('New Password and Confirm Password Is not Matched!');</script>";
		    echo "<meta http-equiv=\"refresh\" content=\"0;URL=changepassword.php\">";
		     exit();
	   }
	   
	   $update=mysql_query("update amc_administration set adm_password='$adm_npassword' where administrator_id='$administrator_id'",$con);
	   echo "<script>alert('YOUR PASSWORD IS UPDATE SCUCCESSFULLY!');</script>";
	    echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Profile</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $adm_name;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
        
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">OLD PASSWORD</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="password" name="adm_password"/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">NEW PASSWORD</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="password" name="adm_npassword"/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CONFIRM PASSWORD</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="password" name="adm_cpassword" /></div>
          </div>
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="SAVE" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        
         
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>