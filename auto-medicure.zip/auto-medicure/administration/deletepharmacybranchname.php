<?php include('config.php'); ?>
<?php
$phbrdid = $_REQUEST['phbrdid'];
$uupdate=mysql_query("delete from amc_pharmacy_branch  where branch_id='$phbrdid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=addpharmacybranch.php\">";
echo "<script>alert('BRANCH NAME REMOVE SUCCESSFULLY!');</script>";
?>
