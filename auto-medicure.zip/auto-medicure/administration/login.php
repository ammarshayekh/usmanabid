<?php
include("config.php");
$adm_cnicno=''; $adm_password='';
   if(isset($_POST['adm_cnicno']) && !empty($_POST['adm_cnicno']) AND isset($_POST['adm_password']) && !empty($_POST['adm_password'])){
   
	 $adm_cnicno = mysql_escape_string($_POST['adm_cnicno']); // Turn our post into a local variable
	  $adm_password = mysql_escape_string($_POST['adm_password']); // Turn our post into a local variable
	   


$ll=mysql_query("select * from amc_administration where adm_cnicno='$adm_cnicno' and adm_password='$adm_password'",$con);
$cnicno="";
$passwordd="";
if($ll === FALSE) {
    die(mysql_error()); // TODO: better error handling
}
while($hh_data=mysql_fetch_array($ll))
{
	$cnicno=$hh_data['adm_cnicno'];
	$passwordd=$hh_data['adm_password'];
	
}
if(($adm_cnicno == $cnicno) && ($adm_password == $passwordd))
{
	echo "<script>alert('You are Successfull Login');</script>";
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
	mysql_query("update amc_administration set session_id='$ses_id' where adm_cnicno='$adm_cnicno' and adm_password = '$adm_password'",$con);
}
else
{
	echo "<script>alert('CNIC NO AND PASSWORD IS INCORRECT!');</script>";
	//echo "Email and Password is inCorrect";
	}
   }
   ?>
<html>
<head>
<title>Administrators Form</title>
<style type="text/css">
h3{font-family: Calibri; font-size: 22pt; font-style: normal; font-weight: bold; color:#06F;
text-align: center; text-decoration: underline }
table{font-family: Calibri; color:white; font-size: 11pt; font-style: normal;
text-align:; background-color:#3391E7; border-collapse: collapse; border: 2px solid #3391E7;}
table.inner{border: 0px}
</style>
</head>
<body>
<h3>ADMINISTRATION LOGIN FORM</h3>
<form action="" method="POST">
 
<table align="center" cellpadding = "10">
<!----- Last Name ---------------------------------------------------------->
<tr>
<td>CNIC NO</td>
<td><input type="text" name="adm_cnicno" maxlength="30"/>
</td>
</tr>
<!----- Password ---------------------------------------------------------->
<tr>
<td>PASSWORD</td>
<td><input type="password" name="adm_password" maxlength="15" />
</td>
</tr>
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" value="Login">
</td>
</tr>
</table>
 
</form>
 
</body>
</html>