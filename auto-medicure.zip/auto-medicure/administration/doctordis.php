<?php include('config.php'); ?>
<?php
$dsid = $_REQUEST['dsid'];
$uupdate=mysql_query("update amc_doctor set status='2' where dr_id='$dsid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=doctorapproval.php\">";
echo "<script>alert('DOCTOR DISAPPROVAL SUCCESSFULLY!');</script>";
?>
