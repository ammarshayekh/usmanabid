<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Prescription form</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $adm_name;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
       
        <div class="analyst_right" style="height:auto; margin-top:0px;">
        
         
         
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:220px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> USERS NAME</div>
         <div style="width:120px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">DATE</div>
          
          <div style="width:170px; float:left; text-align:center;color:#FFF;margin-top:7px;">ACTION</div>
         </div>
          <?php  
	 
	 $qdd=mysql_query("select * from amc_user",$con);
	 while($qdd_data=mysql_fetch_array($qdd))
	 {
		 $user_name =$qdd_data['user_name'];
		 $user_id =$qdd_data['user_id'];
		  $status =$qdd_data['status'];
		 
		 
	 
	  ?>     
      <?php if($status !=2){?>
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:220px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><a href="userprofiled.php?upfoid=<?php echo $user_id;?>" style="color:#FFF; text-decoration:none;"><?php echo $user_name?></a></div>
         <div style="width:120px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> 12-22-17  </div>
         <!--<div style="width:50px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><a href="userdis.php?usid=<?php //echo $user_id;?>" style="color:#FFF; text-decoration:none;">NO</a></div>--->
          <?php if($status == 0){?>
          <div style="width:80px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="userapp.php?uaid=<?php echo $user_id;?>" style="color:#FFF; text-decoration:none;">CONFIRM</a></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="userdelete.php?udid=<?php echo $user_id;?>" style="color:#FFF; text-decoration:none;">DELETE</a></div>
          <?php } ?>
           <?php if($status == 1){?>
          <div style="width:80px; float:left; text-align:center;color:#FFF;margin-top:7px;">APPROVED</div>
         
          <?php } ?>
         </div>
          <?php } ?>
         <?php }?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>