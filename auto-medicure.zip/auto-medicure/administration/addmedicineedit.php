<?php
include('config.php');
$username=''; $membername=''; 
   if(isset($_POST['medediteid']) && !empty($_POST['medediteid']) AND isset($_POST['medtype']) && !empty($_POST['medtype']) AND($_POST['medname']) && !empty($_POST['medname'])){
	   $mededite_id = mysql_escape_string($_POST['medediteid']); // Turn our post into a local variable
	   $med_type = mysql_escape_string($_POST['medtype']); // Turn our post into a local variable
    $med_name = mysql_escape_string($_POST['medname']); // Turn our post into a local variable
   
	
	//echo $username;$membername;
	  // mysql_query("insert into amc_medicines(med_type,med_name) values ('$med_type','$med_name')",$con);
	   $update=mysql_query("update amc_medicines set med_type='$med_type',med_name='$med_name' where med_id='$mededite_id'",$con);
	   echo "<script>alert('MEDICINE UPDATED SUCCESSFULLY!');</script>";
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=addmedicine.php\">";
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Prescription form</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $adm_name;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
       
        <div class="analyst_right" style="height:auto; margin-top:0px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <?php 
		 $medediteid=$_REQUEST['medediteid'];
	 $q=mysql_query("select * from amc_medicines where med_id='$medediteid'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $mtype =$q_data['med_type'];
		 $mname =$q_data['med_name'];
		  $med_id =$q_data['med_id'];
		 
	 
	 }
		 ?>
         <form method="post" action="">
         <input type="hidden" name="medediteid" value="<?php echo $med_id;?>" />
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">MEDCINE TYPE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="medtype" value="<?php echo $mtype;?>"/></div>
          </div>
          
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">MEDICINE NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="medname" value="<?php echo $mname;?>"/></div>
          </div>
          
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="UPDATE" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
         
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>