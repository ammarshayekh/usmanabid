<?php
include('config.php');
 
   if(isset($_POST['imgtype']) && !empty($_POST['imgtype']) AND ($_POST['imgdetail']) && !empty($_POST['imgdetail'])){
	   $imgtype =$_POST['imgtype'];
	    $imgdetail =$_POST['imgdetail'];
    
   //=======================================
$target_path = "images_category/";
$target_path = $target_path . basename( $_FILES['imgname']['name']);
$target_path = "images_category/";
$target_path = $target_path . basename( $_FILES['imgname']['name']);
$Target = $target_path;
move_uploaded_file($_FILES['imgname']['tmp_name'], $target_path);
//=========================================
	//echo $username;$membername;
	   mysql_query("insert into amc_category_image(image_id,image_path,symptoms)values('$imgtype','$Target','$imgdetail')",$con);
	   echo "<script>alert('IMGAE UPLOAD SUCCESSFULLY!');</script>";
	  // echo "<meta http-equiv=\"refresh\" content=\"0;URL=uploadimage.php\">";
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Upload-Image</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $adm_name;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
       
        <div class="analyst_right" style="height:auto; margin-top:0px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         
         <form method="post" action="" enctype="multipart/form-data">
        
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">IMAGE CATEGORY</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="imgtype">
         <?php $q=mysql_query("select * from amc_main_image",$con);
	 while($q_data=mysql_fetch_array($q))
	 { 
	 $imgtye=$q_data['img_type'];
	 $imgid=$q_data['imgid'];
	 ?>
          <option value="<?php echo $imgid;?>"><?php echo $imgtye;?></option>
          <?php } ?>
          </select></div>
          </div>
          
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">SELECT IMAGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="file" name="imgname" placeholder="enter medicine name e.g panadol"/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">IMAGE DETAIL</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="imgdetail" placeholder="enter image detail"/></div>
          </div>
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="ADD" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
         <!--<div style="width:560px; height:30px; float:left; margin-bottom:5px;  font-weight:bold;">
      LIST OF IMAGES
         </div>
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:220px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> IMAGE NAME</div>
         <div style="width:170px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">TYPE</div>
         
          
          
          <div style="width:120px; float:left; text-align:center;color:#FFF;margin-top:7px;">ACTION</div>
         </div>-->
          <?php  
	 
	/* $qdd=mysql_query("select * from amc_medicines",$con);
	 while($qdd_data=mysql_fetch_array($qdd))
	 {
		 $medid =$qdd_data['med_id'];
		 $medtype =$qdd_data['med_type'];
		 $medname =$qdd_data['med_name'];
		 
		 
	 */
	  ?>     
         <!--<div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:220px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php //echo $medname?></div>
         <div style="width:170px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php //echo $medtype;?> </div>
         
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="addmedicineedit.php?medediteid=<?php //echo $medid;?>" style="color:#FFF; text-decoration:none;">EDIT</a></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="addmeddelete.php?medid=<?php //echo $medid;?>" style="color:#FFF; text-decoration:none;">DELETE</a></div>
         </div>-->
         <?php //}?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>