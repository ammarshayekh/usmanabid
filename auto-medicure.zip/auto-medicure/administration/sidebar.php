<div class="center_left">
         <?php
		  include('config.php');
	/*$qqkq=mysql_query("select count(user_id) as user_id from amc_user",$con);
	 while($qqkq_data=mysql_fetch_array($qqkq))
	 {
		 $mm = $qqkq_data['user_id'];
		 
		
	 }
	 $doctor=mysql_query("select count(dr_id) as dr_id from amc_doctor",$con);
	 while($doctor_data=mysql_fetch_array($doctor))
	 {
		 $mmd = $doctor_data['dr_id'];
		 
		
	 }*/
	  ?>     
         <div class="features">   
           
                    <ul class="list">
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px; width:200px;">
                    <li><a href="index.php" style="color:
                    #FFF;">HOME</a></li></div>
                     <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="profiled.php" style="color:
                    #FFF;">PROFILE</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="area_name.php" style="color:
                    #FFF;">ADD AREA NAME</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="location_map.php" style="color:
                    #FFF;">ADD AREA LOCATION</a></li></div>
                 <!-- <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="doctorapproval.php" style="color:
                    #FFF;">DOCTORS APPROVAL (<?php //echo $mmd;?>)</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="userapproval.php" style="color:
                    #FFF;">USERS APPROVAL (<?php // echo $mm;?>)</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="addmedicine.php" style="color:
                    #FFF;">MEDICINES ADD</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="addpharmacy.php?branchid=0&pharmacyid=0" style="color:
                    #FFF;">PHA COMPLETE DETAIL ADD</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="addpharmacyname.php" style="color:
                    #FFF;">PHARMACY NAME ADD</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="addpharmacybranch.php" style="color:
                    #FFF;">PHARMACY BRANCH ADD</a></li></div>-->
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="uploadimage.php" style="color:
                    #FFF;">UPLOAD IMAGE</a></li></div>
                     <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="uploadimagecategory.php" style="color:
                    #FFF;">UPLOAD IMAGE CATEGORY</a></li></div>
                   
                    <!--<div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="changepassword.php" style="color:
                    #FFF;">CHANGE PASSWORD</a></li></div>--->
                    
                    
                    </ul> 
         </div> 
         
         
          
         
         
           
            
            
        </div>