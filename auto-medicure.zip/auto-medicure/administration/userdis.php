<?php include('config.php'); ?>
<?php
$usid= $_REQUEST['usid'];
$uupdate=mysql_query("update amc_user set status='2' where user_id='$usid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=userapproval.php\">";
echo "<script>alert('USER DISAPPROVAL SUCCESSFULLY!');</script>";
?>
