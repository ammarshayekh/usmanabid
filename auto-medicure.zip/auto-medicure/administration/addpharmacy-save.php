<?php
include('config.php');

$pharmapcyname = $_POST['pharmacy_id'];
	$branchname =$_POST['branch_id'];
	$medname =$_POST['medname'];
    $price =$_POST['price'];
    $availability = $_POST['availability'];
	 $cellno = $_POST['cellno'];
	  $timing =$_POST['timing'];
	$address = $_POST['address'];
	$date=date('d-m-Y');
	   mysql_query("insert into amc_pharmacy(med_id,pharmacy_id,branch_id,address,price,availability,cell_no,timing,date) values ('$medname','$pharmapcyname','$branchname','$address ','$price','$availability','$cellno','$timing','$date')",$con);
	   echo "<script>alert('PHARMACY ADD SUCCESSFULLY!');</script>";
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=addpharmacy.php?branchid=0&pharmacyid=0\">";
?>