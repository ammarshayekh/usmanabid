<?php
include('config.php');
$username=''; $membername=''; 
   if(isset($_POST['pharmacyname']) && !empty($_POST['pharmacyname']) AND isset($_POST['branchname']) && !empty($_POST['branchname'])){
	   $pharmacyname = mysql_escape_string($_POST['pharmacyname']); // Turn our post into a local variable
	   $branchname = mysql_escape_string($_POST['branchname']); // Turn our post into a local variable
	   $date=date('d-m-Y');
   
	   mysql_query("insert into amc_pharmacy_branch(pharmacy_id,branch_name,date) values ('$pharmacyname','$branchname','$date')",$con);
	   echo "<script>alert('PHARMACY BRANCH ADD SUCCESSFULLY!');</script>";
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=addpharmacybranch.php\">";
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Prescription form</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $adm_name;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
       
        <div class="analyst_right" style="height:auto; margin-top:0px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         
         <form method="post" action="">
        
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">PHARMACY NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;">
          <select name="pharmacyname"><option selected="selected">Select Pharmacy name</option>
          <?php  
	 
	 $q=mysql_query("select * from amc_pharmacy_name",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $pharmacy_name =$q_data['pharmacy_name'];
		 $pharmacy_id =$q_data['pharmacy_id'];
		 
	 
	  ?>     
          <option value="<?php echo $pharmacy_id;?>"><?php echo $pharmacy_name;?></option>
          <?php } ?>
          
          </select></div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">BRANCH NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="branchname" placeholder=" enter pharmacy name"/></div>
          </div>
          
          
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="ADD" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
         <div style="width:560px; height:30px; float:left; margin-bottom:5px;  font-weight:bold;">
      LIST OF BRANCH NAME
         </div>
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:200px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> PHARMACY NAME</div>
         <div style="width:190px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> BRANCH NAME</div>
          
          <div style="width:120px; float:left; text-align:center;color:#FFF;margin-top:7px;">ACTION</div>
         </div>
          <?php  
	 
	 $qdd=mysql_query("select * from amc_pharmacy_branch inner join amc_pharmacy_name on amc_pharmacy_branch.pharmacy_id = amc_pharmacy_name.pharmacy_id",$con);
	 while($qdd_data=mysql_fetch_array($qdd))
	 {
		 $branch_id =$qdd_data['branch_id'];
		 $branch_name =$qdd_data['branch_name'];
		  $pharmacy_name =$qdd_data['pharmacy_name'];
		
	  ?>     
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:200px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $pharmacy_name?></div>
          <div style="width:190px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $branch_name?></div>
         
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="editpharmacybranch.php?phnameediteid=<?php echo $branch_id;?>" style="color:#FFF; text-decoration:none;">EDIT</a></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="deletepharmacybranchname.php?phbrdid=<?php echo $branch_id;?>" style="color:#FFF; text-decoration:none;">DELETE</a></div>
         </div>
         <?php }?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>