<?php include('config.php'); ?>
<?php
$medid = $_REQUEST['medid'];
$uupdate=mysql_query("delete from amc_medicines  where med_id='$medid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=addmedicine.php\">";
echo "<script>alert('ADD MEDICINE SUCCESSFULLY!');</script>";
?>
