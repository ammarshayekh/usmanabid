<?php include('config.php'); ?>
<?php
$udid = $_REQUEST['udid'];
$uupdate=mysql_query("update amc_user set status='2'  where user_id='$udid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=userapproval.php\">";
echo "<script>alert('USER REMOVE SUCCESSFULLY!');</script>";
?>
