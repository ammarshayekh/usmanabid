<?php
include('config.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Prescription form</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $adm_name;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
       
        <div class="analyst_right" style="height:auto; margin-top:0px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <?php
		 $pharmacyid=$_GET['pharmacyid'];
		 $branchid=$_GET['branchid'];
		 
		 
		 ?> 
         <form method="get" action="addpharmacy.php">
         <input type="hidden" name="branchid" value="0" />
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">PHARMACY NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="pharmacyid" onchange="submit('parent')">
            <?php
		  if($userid == 0)
		  {
			?>
              <option>--Select Pharmacy name--</option>
            <?php  
		  }
          
	 
	 $q=mysql_query("select * from amc_pharmacy_name where pharmacy_id='$pharmacyid'",$con);
	 while($q_data=mysql_fetch_array($q))
	 { 
	 
	  ?>     
          
          <option selected="selected" value="<?php echo $pharmacyid; ?>"><?php echo $q_data['pharmacy_name']; ?></option>
          <?php } ?>
         <?php
		  
	$q=mysql_query("select * from amc_pharmacy_name",$con);
	while($q1_data=mysql_fetch_array($q))
	{
		?>
        <option value="<?php echo $q1_data['pharmacy_id']; ?>"><?php echo $q1_data['pharmacy_name']; ?></option>
        <?php
	} 
?>
          </select></div>
          </div>
          </form>
          <form method="get" action="addpharmacy.php">
           <input type="hidden" name="pharmacyid" value="<?php echo $pharmacyid; ?>" />
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">PHARMACY BRANCH</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="branchid" onchange="submit('parent')">
           <?php
	
	  if($memberid == 0)
		  {
			?>
              <option>--Select Branch Name--</option>
            <?php  
		  }
	 $qa=mysql_query("select * from amc_pharmacy_branch where branch_id='$branchid'",$con);
	 while($qa_data=mysql_fetch_array($qa))
	 {
	  ?>     
          
          <option selected="selected"  value="<?php echo $branchid; ?>"><?php echo $qa_data['branch_name']; ?></option>
          <?php } ?>
          
         <?php
		  
	$q3=mysql_query("select * from amc_pharmacy_branch where pharmacy_id = '$pharmacyid'",$con);
	while($q3_data=mysql_fetch_array($q3))
	{
		?>
        <option value="<?php echo $q3_data['branch_id']; ?>"><?php echo $q3_data['branch_name']; ?></option>
        <?php
	} 
?>
          </select>
          </div>
          </div>
          </form>
          <form method="post" action="addpharmacy-save.php">
          <input type="hidden" name="pharmacy_id" value="<?php echo $pharmacyid; ?>" />
          <input type="hidden" name="branch_id" value="<?php echo $branchid; ?>" />
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">MEDICINE TYPE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="medtype"><option selected="selected">Select Medcine Type</option>
          
           <?php  
	 //$pharid=$_REQUEST['pharmacyname'];
	 $qta=mysql_query("select * from amc_medicines",$con);
	 while($qta_data=mysql_fetch_array($qta))
	 {
		 $med_type =$qta_data['med_type'];
		//$med_id =$qta_data['med_id'];
		 
	 
	  ?>     
          <option value="<?php echo $med_type;?>"><?php echo $med_type;?></option>
          <?php } ?>
          </select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">MEDICINE NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="medname"><option selected="selected">Select Medicine Name</option>
          <?php  
	 //$medtype=$_REQUEST['medtype'];
	 $qtna=mysql_query("select * from amc_medicines",$con);
	 while($qtna_data=mysql_fetch_array($qtna))
	 {
		 $med_name =$qtna_data['med_name'];
		$med_id =$qtna_data['med_id'];
		 
	 
	  ?>     
          <option value="<?php echo $med_id;?>"><?php echo $med_name;?></option>
          <?php } ?>
          </select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">PRICE RS.</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="price" placeholder=" enter medicine price e.g 44 Rs."/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">AVAILABILITY</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="availability"><option selected="selected">Select Availability</option><option value="YES">YES</option><option value="NO">NO</option></select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CELL NO</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="cellno" placeholder=" enter cell no"/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">TIME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="timing" placeholder="enter time e.g 12:00 PM"/></div>
          </div>
          <div style="width:460px; height:80px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">ADDRESS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><textarea name="address" rows="4" cols="25"></textarea></div>
          </div>
          
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="ADD" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
         <div style="width:560px; height:30px; float:left; margin-bottom:5px;  font-weight:bold;">
      LIST OF PHARMACY
         </div>
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:220px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> MEDICINES NAME</div>
         <div style="width:170px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">TYPE</div>
         
          
          
          <div style="width:120px; float:left; text-align:center;color:#FFF;margin-top:7px;">ACTION</div>
         </div>
          <?php  
	 
	 $qdd=mysql_query("select * from amc_medicines",$con);
	 while($qdd_data=mysql_fetch_array($qdd))
	 {
		 $medid =$qdd_data['med_id'];
		 $medtype =$qdd_data['med_type'];
		 $medname =$qdd_data['med_name'];
		 
		 
	 
	  ?>     
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:220px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $medname?></div>
         <div style="width:170px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $medtype;?> </div>
         
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="addmedicineedit.php?medediteid=<?php echo $medid;?>" style="color:#FFF; text-decoration:none;">EDIT</a></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="addmeddelete.php?medid=<?php echo $medid;?>" style="color:#FFF; text-decoration:none;">DELETE</a></div>
         </div>
         <?php }?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>