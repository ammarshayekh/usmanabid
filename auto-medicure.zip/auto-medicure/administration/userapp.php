<?php include('config.php'); ?>
<?php
$uaid = $_REQUEST['uaid'];
$uupdate=mysql_query("update amc_user set status='1' where user_id='$uaid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=userapproval.php\">";
echo "<script>alert('USER APPROVAL SUCCESSFULLY!');</script>";
?>
