<?php include('config.php'); ?>
<?php
$id = $_REQUEST['ddid'];
$uupdate=mysql_query("update amc_doctor set status='2'  where dr_id='$id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=doctorapproval.php\">";
echo "<script>alert('DOCTOR REMOVE SUCCESSFULLY!');</script>";
?>
