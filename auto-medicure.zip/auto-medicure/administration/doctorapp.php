<?php include('config.php'); ?>
<?php
$daid = $_REQUEST['daid'];
$uupdate=mysql_query("update amc_doctor set status='1' where dr_id='$daid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=doctorapproval.php\">";
echo "<script>alert('DOCTOR APPROVAL SUCCESSFULLY!');</script>";
?>
