<?php 

$t1=$_REQUEST['t1'];
$t2=$_REQUEST['t2'];
$t3=$_REQUEST['t3'];
$t4=$_REQUEST['t4'];

echo $t1;
echo $t2;
echo $t3;
echo $t4;

?>