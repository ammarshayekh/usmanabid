<?php
include("config.php");
$user_name=''; $user_cnicno='';  $user_bday='';  $user_month=''; $user_year=''; $user_email='';$user_cellno='';$user_gender='';$user_address='';$user_city='';$user_pincode='';$user_state='';$user_country='';$user_password=''; $uname='';$uemail='';

   if(isset($_POST['user_name']) && !empty($_POST['user_name']) AND isset($_POST['user_cnicno']) && !empty($_POST['user_cnicno']) AND isset(  $_POST['user_bday']) && !empty($_POST['user_bday']) AND isset($_POST['user_month']) && !empty($_POST['user_month']) AND isset($_POST[  'user_year']) && !empty($_POST['user_year'])AND isset($_POST['user_email']) && !empty($_POST['user_email'])AND isset($_POST['user_cellno']) && !empty($_POST['user_cellno'])AND isset($_POST['user_gender']) && !empty($_POST['user_gender'])AND isset($_POST['user_address']) && !empty($_POST['user_address'])AND isset($_POST['user_city']) && !empty($_POST['user_city'])AND isset($_POST['user_pincode']) && !empty($_POST['user_pincode'])AND isset($_POST['user_state']) && !empty($_POST['user_state'])AND isset($_POST['user_country']) && !empty($_POST['user_country'])AND isset($_POST['user_password']) && !empty($_POST['user_password'])){
    $user_name = mysql_escape_string($_POST['user_name']); // Turn our post into a local variable
    $user_cnicno = mysql_escape_string($_POST['user_cnicno']); // Turn our post into a local variable
	$user_bday = mysql_escape_string($_POST['user_bday']); // Turn our post into a local variable
    $user_month = mysql_escape_string($_POST['user_month']); // Turn our post into a local variable
	$user_year = mysql_escape_string($_POST['user_year']); // Turn our post into a local variable
	$user_email = mysql_escape_string($_POST['user_email']); // Turn our post into a local variable
	$user_cellno = mysql_escape_string($_POST['user_cellno']); // Turn our post into a local variable
	$user_gender = mysql_escape_string($_POST['user_gender']); // Turn our post into a local variable
	$user_address = mysql_escape_string($_POST['user_address']); // Turn our post into a local variable
	$user_city = mysql_escape_string($_POST['user_city']); // Turn our post into a local variable
	$user_pincode = mysql_escape_string($_POST['user_pincode']); // Turn our post into a local variable
	$user_state = mysql_escape_string($_POST['user_state']); // Turn our post into a local variable
	$user_country = mysql_escape_string($_POST['user_country']); // Turn our post into a local variable
	$user_password = mysql_escape_string($_POST['user_password']); // Turn our post into a local variable
	echo $user_name;
	echo $user_cnicno;
	//exit();
	     $qq1=mysql_query("select * from amc_user where user_cnicno='$user_cnicno'",$con);
	 while($qq1_data=mysql_fetch_array($qq1))
	 {
		 $ucnic=$qq1_data['user_cnicno'];	
	 }
	  if($user_cnicno == $ucnic)
	       {
		   echo "<script>alert('User CNIC NO is Already exit.Please Try Again!');</script>";
		   //echo "Company Name is Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   //echo "<meta http-equiv=\"refresh\" content=\"0;URL=register.php\">";
		    exit();
			 }
	    $qq11=mysql_query("select * from amc_user where user_email='$user_email'",$con);
	 while($qq11_data=mysql_fetch_array($qq11))
	 {
		 
		
		$uemail=$qq11_data['user_email'];
		
	 }
	    if($user_email == $uemail)
	   {
		    echo "<script>alert('Email Address Already exit.Please Try Again!');</script>";
		   //echo "Email Address Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   //echo "<meta http-equiv=\"refresh\" content=\"0;URL=register.php\">";
		     exit();
			 }
	   
	  // mysql_query("insert into amc_user(user_name,user_cnicno,user_session_id) values ('$user_name','$user_cnicno','$ses_id')",$con);
	  mysql_query("insert into amc_user(user_name,user_cnicno,user_bday,user_month,user_year,user_email,user_cellno,user_gender,user_address,user_city,user_pincode,user_state,user_country,user_password,user_session_id) values ('$user_name','$user_cnicno','$user_bday','$user_month','$user_year','$user_email','$user_cellno','$user_gender','$user_address','$user_city','$user_pincode','$user_state','$user_country','$user_password','$ses_id')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=user_admin_panel/index.php\">";
echo "<script>alert('You are Successfully Registered!');</script>";
 
//echo "Successfully Submitted";
}           
?>
<html>
<head>
<title>Registration | Auto-Medicure</title>
<style type="text/css">
h3{font-family: Calibri; font-size: 22pt; font-style: normal; font-weight: bold; color:#06F;
text-align: center; text-decoration: underline }
table{font-family: Calibri; color:white; font-size: 11pt; font-style: normal;
text-align:; background-color:#3391E7; border-collapse: collapse; border: 2px solid #3391E7;}
table.inner{border: 0px}
</style>
<SCRIPT language=JavaScript>
<!--

//Accept terms & conditions script (by InsightEye www.insighteye.com)
//Visit JavaScript Kit (http://javascriptkit.com) for this script & more.


function checkCheckBox(f){


if (f.agree.checked == false )
{
alert('Please check the box to continue.');
return false;
}else
return true;

}
//-->
</SCRIPT>
</head>
<body>
<h3>USER REGISTRATION FORM</h3>
<form action="" method="POST" onSubmit="return checkCheckBox(this)">
 
<table align="center" cellpadding = "10">
 
<!----- First Name ---------------------------------------------------------->
<tr>
<td>NAME</td>
<td><input type="text" name="user_name" maxlength="30"/>
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Last Name ---------------------------------------------------------->
<tr>
<td>CNIC NO</td>
<td><input type="text" name="user_cnicno" maxlength="30"/>
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Date Of Birth -------------------------------------------------------->
<tr>
<td>DATE OF BIRTH</td>
 
<td>
<select name="user_bday" id="user_bday">
<option value="-1">Day:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
 
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
 
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
 
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
 
<option value="31">31</option>
</select>
 
<select id="user_month" name="user_month">
<option value="-1">Month:</option>
<option value="January">Jan</option>
<option value="February">Feb</option>
<option value="March">Mar</option>
<option value="April">Apr</option>
<option value="May">May</option>
<option value="June">Jun</option>
<option value="July">Jul</option>
<option value="August">Aug</option>
<option value="September">Sep</option>
<option value="October">Oct</option>
<option value="November">Nov</option>
<option value="December">Dec</option>
</select>
 
<select name="user_year" id="user_year">
 
<option value="-1">Year:</option>
<option value="2012">2012</option>
<option value="2011">2011</option>
<option value="2010">2010</option>
<option value="2009">2009</option>
<option value="2008">2008</option>
<option value="2007">2007</option>
<option value="2006">2006</option>
<option value="2005">2005</option>
<option value="2004">2004</option>
<option value="2003">2003</option>
<option value="2002">2002</option>
<option value="2001">2001</option>
<option value="2000">2000</option>
 
<option value="1999">1999</option>
<option value="1998">1998</option>
<option value="1997">1997</option>
<option value="1996">1996</option>
<option value="1995">1995</option>
<option value="1994">1994</option>
<option value="1993">1993</option>
<option value="1992">1992</option>
<option value="1991">1991</option>
<option value="1990">1990</option>
 
<option value="1989">1989</option>
<option value="1988">1988</option>
<option value="1987">1987</option>
<option value="1986">1986</option>
<option value="1985">1985</option>
<option value="1984">1984</option>
<option value="1983">1983</option>
<option value="1982">1982</option>
<option value="1981">1981</option>
<option value="1980">1980</option>
</select>
</td>
</tr>
 
<!----- Email Id ---------------------------------------------------------->
<tr>
<td>EMAIL ID</td>
<td><input type="text" name="user_email" maxlength="100" /></td>
</tr>
 
<!----- Mobile Number ---------------------------------------------------------->
<tr>
<td>MOBILE NUMBER</td>
<td>
<input type="text" name="user_cellno" maxlength="10" />
(10 digit number)
</td>
</tr>
 
<!----- Gender ----------------------------------------------------------->
<tr>
<td>GENDER</td>
<td>
Male <input type="radio" name="user_gender" value="M" />
Female <input type="radio" name="user_gender" value="F" />
</td>
</tr>
 
<!----- Address ---------------------------------------------------------->
<tr>
<td>ADDRESS <br /><br /><br /></td>
<td><textarea name="user_address" rows="4" cols="30"></textarea></td>
</tr>
 
<!----- City ---------------------------------------------------------->
<tr>
<td>CITY</td>
<td><input type="text" name="user_city" maxlength="30" />
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Zip Code ---------------------------------------------------------->
<tr>
<td>ZIP CODE</td>
<td><input type="text" name="user_pincode" maxlength="6" />
(6 digit number)
</td>
</tr>
 
<!----- State ---------------------------------------------------------->
<tr>
<td>STATE</td>
<td><input type="text" name="user_state" maxlength="30" />
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Country ---------------------------------------------------------->
<tr>
<td>COUNTRY</td>
<td><input type="text" name="user_country"/></td>
</tr>
<!----- Password ---------------------------------------------------------->
<tr>
<td>PASSWORD</td>
<td><input type="password" name="user_password" maxlength="15" />
(max 15 characters a-z and A-Z)
</td>
</tr>
<!----- Terms and conditions ---------------------------------------------------------->
<tr>

<tr>
<td>I agree with all </td>
<td> terms and conditions of registration and satisfied to be registered</td>

</tr>
</tr>
<tr>
<td></td>
<td><input type="checkbox" name="agree" />
Terms and Conditions
</td>
</tr>
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" value="REGISTER" style="background-color:#3391E7;width:85px; text-align:center;color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#3391E7; cursor:pointer;">
<input type="button" value="CANCEL" style="background-color:#3391E7;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#3391E7; cursor:pointer; text-align:center;">
</td>
</tr>
</table>
 
</form>
 
</body>
</html>