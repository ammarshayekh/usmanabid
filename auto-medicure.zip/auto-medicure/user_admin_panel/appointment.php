<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto; margin-top:30px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">SEARCH</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="searc_name" placeholder="ENTER SYMPTOMS" style="padding-left:5px;" /></div>
          </div>
          
       
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="Search" style="background-color:#36F; color:#FFF; height:25px;width:80px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Dr.Name</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="dname" style="padding-left:5px;">
           <?php  
	 $sname=$_REQUEST['searc_name'];
	 //$sname='abc';  
	 $aq=mysql_query("select * from amc_setslots where d_field='$sname'",$con);
	 while($aq_data=mysql_fetch_array($aq))
	 {
		 $dnamea =$aq_data['d_name'];
	  ?>     <a href="appointment.php?dname=<?php echo $dnamea;?>"><option value="<?php echo $dnamea;?>"><?php echo $dnamea;?></option></a><?php }?></select></div>
          </div>
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="Search" style="background-color:#36F; color:#FFF; height:25px;width:80px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
          
       
          
         </form>
         </div>
         
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         
          
          <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Days</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="days" style="padding-left:5px;">
           <?php  
	 $ddname=$_REQUEST['dname'];
	 //$sname='abc';  
	 $aaq=mysql_query("select * from amc_setslots where d_name='$ddname'",$con);
	 while($aaq_data=mysql_fetch_array($aaq))
	 {
		 $days =$aaq_data['days'];
	  ?>     <option value="<?php echo $days;?>"><?php echo $days;?></option><?php }?></select></div>
          </div>
       
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="Search" style="background-color:#36F; color:#FFF; height:25px;width:80px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         
          
          <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Date</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="days" style="padding-left:5px;">
           <?php  
	 $ddays=$_REQUEST['days'];
	 //$sname='abc';  
	 $aaaq=mysql_query("select * from amc_setslots where days='$ddays'",$con);
	 while($aaaq_data=mysql_fetch_array($aaaq))
	 {
		 $dtae =$aaaq_data['d_date'];
	  ?>     <option value=""><?php echo $dtae;?></option><?php }?></select></div>
          </div>
       
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="Search" style="background-color:#36F; color:#FFF; height:25px;width:80px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
          <?php
		  
	 $sname=$_REQUEST['searc_name'];
	 //$sname='abc';  
	 $q=mysql_query("select * from amc_setslots where d_field='$sname'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $dname =$q_data['d_name'];
		 $dfield =$q_data['d_field'];
		 $ddate =$q_data['d_date'];
		 $dtime =$q_data['d_time'];
		 $fid =$q_data['s_id'];
		  $status =$q_data['status'];
		 // $ac_status =$q_data['ac_status'];
		
		
	 
	  ?>     
        <div style="width:565px;height:80px;background-color:#36F;margin-bottom:10px;">
         <div style="width:530px;float:left;padding-left:10px;color:#FFF;margin-top:0px;background-color:#36F; margin-top:3px;">NAME:Dr.<?php echo $dname;?></div>
         <div style="width:530px;float:left;padding-left:10px;color:#FFF;margin-top:0px;background-color:#36F;">FIELD:<?php echo $dfield; ?></div>
         <div style="width:530px;float:left;padding-left:10px;color:#FFF;margin-top:0px;background-color:#36F;">DATE:<?php echo $ddate;?></div>
         <div style="width:530px;float:left;padding-left:10px;color:#FFF;margin-top:0px;background-color:#36F;margin-bottom:3px;">TIME:<?php echo $dtime;?></div>
        
         <div style="width:130px; margin-left:420px;float:left;padding-left:10px;color:#FFF;margin-top:0px;background-color:#36F;margin-bottom:3px;">
          <?php if($status=='0') {?>
         <a href="appointmentf.php?id=<?php echo $fid; ?>" style="color:#0F0; text-decoration:none; font-size:larger; padding-left:23px;">APPOINTMENT</a>
          <?php }  if($status == '1'){ ?>
          
         <a href="#" style="color:#0F0; text-decoration:none; font-size:larger;padding-left:30px;">PROCESSING</a>
         
         <?php } if($status == '2'){ ?>
          
         <a href="#" style="color:#0F0; text-decoration:none; font-size:larger;padding-left:16px;">NOT AVAILABLE</a>
         <?php  }?>
         
         </div>
        
         
         </div>
         <?php  } ?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>