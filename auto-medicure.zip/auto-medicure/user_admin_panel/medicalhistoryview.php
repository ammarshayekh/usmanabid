<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Profile</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
         <?php  
	 $medicalview=$_REQUEST['medicalview'];
	 $q=mysql_query("select * from amc_prescription inner join amc_addmembers on amc_prescription.member_id = amc_addmembers.m_id inner join amc_medicines on amc_prescription.medicines_id = amc_medicines.med_id inner join amc_doctor on amc_prescription.doc_id = amc_doctor.dr_id  where member_id='$medicalview'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $member_name =$q_data['member_name'];
		 $dr_namen =$q_data['dr_name'];
		 $member_age =$q_data['member_age'];
		 $med_name =$q_data['med_name'];
		 $symptoms =$q_data['symptoms'];
		 $time_m =$q_data['time_m'];
		 $time_a =$q_data['time_a'];
		 $time_e =$q_data['time_e'];
		 $time_n =$q_data['time_n'];
		 $total_days =$q_data['total_days'];
		 $date =$q_data['p_date'];
		
	 }
	  ?>     
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         
         <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">MEMBER NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $member_name;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">DR.NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $dr_namen;?></div>
          </div>
            <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">MEMBER AGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $member_age;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">MEDICINE NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $med_name;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">SYMPTOMS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $symptoms;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">TIMING</div>
          <div style="width:57px; float:left; text-align:center;margin-top:7px; margin-left:15px;"><?php echo $time_m."+".$time_a."+".$time_e."+".$time_n;?></div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">NO.OF DAYS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $total_days;?></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">DATE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><?php echo $date;?></div>
          </div>
         
         </form>
         </div>
        
         
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>