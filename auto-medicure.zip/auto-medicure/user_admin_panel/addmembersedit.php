<?php
include('config.php');
$dr_name=''; $dr_cnicno='';
   if(isset($_POST['member_name']) && !empty($_POST['member_name'])AND isset($_POST['member_age']) && !empty($_POST['member_age'])AND isset($_POST['addmemberid']) && !empty($_POST['addmemberid'])){
	  $member_name =$_POST['member_name']; // Turn our post into a local variable
	  $member_age = $_POST['member_age']; // Turn our post into a local variable
	  $addmemberid =$_POST['addmemberid']; // Turn our post into a local variable
	  $date=date('d-m-Y');
	
	  $update=mysql_query("update amc_addmembers set member_name='$member_name',member_age='$member_age',date=' $date' where m_id='$addmemberid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=addmembers.php\">";
echo "<script>alert('MEMBER UPDATE SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}           

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Addmembers</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        <?php  
	 $idaddmemedit=$_REQUEST['addmemedit'];
	 $q=mysql_query("select * from amc_addmembers where m_id='$idaddmemedit'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $mname =$q_data['member_name'];
		 $age =$q_data['member_age'];
		 $addmemberid =$q_data['m_id'];
		 
	 
	  ?>     
         
         <?php }?>
        <div class="analyst_right" style="height:auto; margin-top:30px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         <input type="hidden" name="addmemberid" value="<?php echo $addmemberid;?>" />
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="member_name" value="<?php echo $mname;?>" style="padding-left:5px;"/></div>
          </div>
          
       <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">AGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="date" name="member_age" value="<?php echo $age;?>" style="padding-left:5px;"/></div>
          </div>
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="UPDATE" style="background-color:#36F; width:80px;color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        
         
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>