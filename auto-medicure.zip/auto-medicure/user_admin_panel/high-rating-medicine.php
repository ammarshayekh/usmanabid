<?php
include('config.php');

include_once('rating2.php')
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Expert-System</title>
<link rel="stylesheet" type="text/css" href="style.css" />

<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.css" rel="stylesheet">
<link href="css/star-rating.min.css" media="all" rel="stylesheet" type="text/css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    
    <script src="js/star-rating.min.js" type="text/javascript"></script>
   
   
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:550px; height:auto; margin-left:10px;">
        
        
         <table border=1>
 
 <?php 
  $q=mysql_query("select sum(vote) as vote, product_id from rating_medicine group by product_id order by vote DESC ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 
		 $med_id =$q_data['product_id'];		
	 $q1=mysql_query("select * from amc_medicines where med_id='$med_id'",$con);
	 while($q_data1=mysql_fetch_array($q1))
	 {
		 $med_name =$q_data1['med_name'];
	 }
 ?>
 <tr>
 <td >
    MEDICINE NAME
    <h3><?php echo $med_name;  ?></h3> 
   <input value="<?= getRatingByProductId(connect(), $med_id); ?>" type="number" class="rating" min=0 max=5 step=0.1 data-size="md" data-stars="5" productId=<?php echo $med_id; ?>>
  </td>
  </tr>
  <?php } ?>
    </table>
    
     <script type="text/javascript">
        $(function(){
               $('.rating').on('rating.change', function(event, value, caption) {
                productId = $(this).attr('productId');
                $.ajax({
                  url: "rating2.php",
                  dataType: "json",
                  data: {vote:value, productId:productId, type:'save'},
                  success: function( data ) {
                     alert("rating saved");
                  },
              error: function(e) {
                // Handle error here
                console.log(e);
              },
              timeout: 30000  
            });
              });
           
        });
    </script>
         
         </div>
       
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>