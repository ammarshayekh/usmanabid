<?php
include('config.php');

   if(isset($_POST['confirmation']) && !empty($_POST['confirmation'])){
	  $confirmation = mysql_escape_string($_POST['confirmation']); // Turn our post into a local variable
	 // $userid = mysql_escape_string($_POST['user_id']); // Turn our post into a local variable
	
echo "<script>alert('WAIT FOR DOCTOR CONFIRMATION WAIT FOR 5 MINUTES!');</script>";
echo "<meta http-equiv=\"refresh\" content=\"0;URL=expertsystem.php\">";
 
//echo "Successfully Submitted";
}           


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Expert-System</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto; margin-top:30px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">SEARCH</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="searc_name" placeholder="ENTER SYMPTOMS" style="padding-left:5px;" /></div>
          </div>
          <!--<div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">ADDRESS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="address" placeholder="ENTER ADDRESS" style="padding-left:5px;" /></div>
          </div> -->
       
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="Search" style="background-color:#36F; color:#FFF; height:25px;width:80px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         
         </div>
         <div style="width:560px; height:15px; float:left; margin-bottom:5px;  font-weight:bold;">
     AVAILABLE PRESCRIPTION
         </div>
       <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:140px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Ref.Dr</div>
          <div style="width:130px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Medicince</div>
          <div style="width:130px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Timing</div>
          
          <div style="width:150px; float:left; text-align:center;color:#FFF;margin-top:7px;">No.of Days</div>
         </div>
          <?php  
		$sefield='';
	 $sefield=$_REQUEST['searc_name'];
	 //$cimgid=$_REQUEST['cimgid'];
	 
	  
	 $q=mysql_query("select * from amc_prescription inner join amc_medicines on amc_prescription.medicines_id = amc_medicines.med_id inner join amc_doctor on amc_prescription.doc_id = amc_doctor.dr_id where symptoms='$sefield'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		// $dname =$q_data['dr_name'];
		
		 
	 
	  ?>  
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:140px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['dr_name']; ?></div>
         <div style="width:130px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['med_name']; ?></div>
          <div style="width:130px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['time_m']; ?></div>
          
          <div style="width:100px; float:left; text-align:center;color:#FFF;margin-top:7px;"><?php echo $q_data['total_days']; ?></div>
         </div>
          <?php } ?> 
           <!--<div style="width:560px; margin-top:5px; height:15px; float:left; margin-bottom:5px;  font-weight:bold;">
     NEAR BY PHARMACY
         </div> -->
         <!--<div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:140px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Phar's Name</div>
          <div style="width:130px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Phar's Branch</div>
          <div style="width:130px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Address</div>
          
          <div style="width:50px; float:left; text-align:center;border-right:2px solid #FFF;color:#FFF;margin-top:7px;">Price</div>
          <div style="width:100px; float:left; text-align:center;color:#FFF;margin-top:7px;">Availability</div>
         </div> --> 
          <?php  
		/*$address='';
	 $address=$_REQUEST['address'];
	  
	 $qq=mysql_query("select * from amc_pharmacy inner join amc_pharmacy_name on amc_pharmacy.pharmacy_id = amc_pharmacy_name.pharmacy_id inner join amc_pharmacy_branch on amc_pharmacy.branch_id = amc_pharmacy_branch.branch_id where address='$address'",$con);
	 while($qq_data=mysql_fetch_array($qq))
	 {
		// $dname =$q_data['dr_name'];
		
		 */
	 
	  ?>   
         <!--<div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:140px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php //echo   $qq_data['pharmacy_name']; ?></div>
         <div style="width:130px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php //echo $qq_data['branch_name']; ?></div>
          <div style="width:130px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php //echo $qq_data['address']; ?></div>
          
          <div style="width:50px; float:left; text-align:center;border-right:2px solid #FFF;color:#FFF;margin-top:7px;"><?php //echo $qq_data['price']; ?></div>
          <div style="width:100px; float:left; text-align:center;color:#FFF;margin-top:7px;"><?php //echo $qq_data['availability']; ?></div>
         </div> -->
         <?php //} ?> 
         <form method="post" action="">
         <div style="width:460px; height:40px;">
        
          <div style="width:25px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" name="confirmation" value="yes"  style="padding-left:5px;" /></div> 
          <div style="width:150px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Ask Doctor for Confirmation </div> <div style="width:60px; float:left; text-align:right; margin-top:5px;"><input type="submit" name="name" value="OK" style="background-color:#36F; color:#FFF; height:25px;width:60px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          </div>
          
       
          
         </form>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>