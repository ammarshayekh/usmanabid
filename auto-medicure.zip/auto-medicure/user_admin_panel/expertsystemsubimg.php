<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Expert-System</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post">
         
          
       
          <div style="width:460px; height:auto;">
          <?php
		  $idimg=$_REQUEST['imgid'];
  $q=mysql_query("select * from amc_category_image where image_id='$idimg' ",$con);
 while($q_data=mysql_fetch_array($q))
 {
	 $imge_name=$q_data['image_path'];
	$cimgid=$q_data['cimgid'];
	$symptoms=$q_data['symptoms'];
 ?>
          <a href="expertsystemshow.php?cimgid=<?php echo $cimgid;?>&searc_name=<?php echo $symptoms;?>&address=">
         <div style="width:220px; height:100px; margin-bottom:10px; float:left; text-align:right; padding-right:10px; "><img src="../administration/<?php echo $imge_name; ?>" height="100" width="220" /></div>
         </a>
        
          <?php } ?>
          </div>
          
         </form>
         
         </div>
       
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>