<?php
include('config.php');
$dr_name=''; $dr_cnicno='';
   if(isset($_POST['member_name']) && !empty($_POST['member_name'])AND isset($_POST['member_age']) && !empty($_POST['member_age'])AND isset($_POST['user_id']) && !empty($_POST['user_id'])){
	  $member_name = mysql_escape_string($_POST['member_name']); // Turn our post into a local variable
	  $member_age = mysql_escape_string($_POST['member_age']); // Turn our post into a local variable
	  $userid = mysql_escape_string($_POST['user_id']); // Turn our post into a local variable
	  $date=date('d-m-Y');
	 // echo $member_name;
	  mysql_query("insert into amc_addmembers(user_id,member_name,member_age,date) values ('$userid','$member_name','$member_age','$date')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('MEMBER ADDED SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}           

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Addmembers</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         <input type="hidden" name="user_id" value="<?php echo $u_id;?>" />
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="member_name" placeholder="ENTER NAME" style="padding-left:5px;"/></div>
          </div>
          
       <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">AGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="date" name="member_age" placeholder="ENTER AGE" style="padding-left:5px;"/></div>
          </div>
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="Add" style="background-color:#36F; width:80px;color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:370px; float:left; padding-left:30px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Name</div>
          
          
          <div style="width:150px; float:left; text-align:center;color:#FFF;margin-top:7px;">Action</div>
         </div>
          <?php  
	 
	 $q=mysql_query("select * from amc_addmembers where user_id='$u_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $mname =$q_data['member_name'];
		 $age =$q_data['member_age'];
		 $addmemberid =$q_data['m_id'];
		 
	 
	  ?>     
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:220px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $mname;?></div>
         <div style="width:190px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $age;?></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="addmembersedit.php?addmemedit=<?php echo $addmemberid;?>" style="color:#FFF; text-decoration:none;">Edit</a></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="addmemberdelete.php?addmemid=<?php echo $addmemberid; ?>" style="color:#FFF; text-decoration:none;">Delete</a></div>
         </div>
         <?php }?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>