<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
        
         
       
       <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:120px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Date</div>
          <div style="width:70px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Days</div>
          <div style="width:130px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Time</div>
          <div style="width:120px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Member's Name</div>
          
          <div style="width:110px; float:left; text-align:center;color:#FFF;margin-top:7px;">Action</div>
         </div>
         <?php  
		 $current_date = date("Y-m-d");
	 $doctorid=$_REQUEST['id'];
	 $q=mysql_query("select * from amc_setslots inner join amc_timetable on  amc_setslots.s_id = amc_timetable.detail_id where doc_id='$doctorid' ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 //$dname =$q_data['dr_name'];
		
		
	  ?>  
      <form action="approval.php" method="post">
      <input type="hidden" name="id" value="<?php echo $q_data['doc_id']; ?>" />
      <input type="hidden" name="date" value="<?php echo $q_data['d_date']; ?>" />
      <input type="hidden" name="days" value="<?php echo $q_data['days']; ?>" />
      <input type="hidden" name="time" value="<?php echo $q_data['schedule']; ?>" />
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:120px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['d_date']; ?></div>
         <div style="width:70px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['days']; ?></div>
          <div style="width:130px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['schedule']; ?></div>
          
          <div style="width:120px; float:left; text-align:center;color:#FFF;margin-top:7px;border-right:2px solid #FFF;"> <select name="member_id"> 
<?php $member1=mysql_query("select * from amc_addmembers where user_id=$u_id",$con);
	  while($member1_data=mysql_fetch_array($member1))
	 {
		 //$member_name =$member1_data['member_name']; 
    ?>
	 <option value="<?php echo $member1_data['m_id'];?>"><?php echo $member1_data['member_name'];?> - <?php echo $member1_data['m_id'];?></option> <?php } ?>
     </select></div>
            
          <div style="width:110px; float:left; text-align:center;color:#FFF;margin-top:7px;"><input type="submit" name="submit" value="Approval" /></div>
         </div>
          </form>
     <?php } ?>     
     
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>