<?php include('config.php'); ?>
<?php
$addmemid = $_REQUEST['addmemid'];
$uupdate=mysql_query("delete from amc_addmembers  where m_id='$addmemid'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=addmembers.php\">";
echo "<script>alert(' MEMBERS DELETE SUCCESSFULLY!');</script>";
?>
