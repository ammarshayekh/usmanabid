<?php
include('config.php');
$uname=''; $doname='';$date='';$time='';
   if(isset($_POST['ssid']) && !empty($_POST['ssid'])AND($_POST['userid']) && !empty($_POST['userid'])AND($_POST['uname']) && !empty($_POST['uname'])AND($_POST['drname']) && !empty($_POST['drname'])AND($_POST['ddid']) && !empty($_POST['ddid'])AND isset($_POST['ddate']) && !empty($_POST['ddate'])AND isset($_POST['time']) && !empty($_POST['time'])){
	   $userid = mysql_escape_string($_POST['userid']); // Turn our post into a local variable
	    $uname = mysql_escape_string($_POST['uname']); // Turn our post into a local variable
	    $ssid = mysql_escape_string($_POST['ssid']); // Turn our post into a local variable
	  $dgname = mysql_escape_string($_POST['drname']); // Turn our post into a local variable
	  $doid = mysql_escape_string($_POST['ddid']); // Turn our post into a local variable
	 $date = mysql_escape_string($_POST['ddate']); // Turn our post into a local variable
	  $time = mysql_escape_string($_POST['time']); // Turn our post into a local variable
	 // echo $member_name;
	 //$date=date('d-m-y');
	  mysql_query("insert into amc_appointmentc(user_id,user_name,dr_name,d_id,d_date,d_time)values('$userid','$uname','$dgname','$doid','$date','$time')",$con);
	   $update=mysql_query("update amc_setslots set status='1' where s_id='$ssid'",$con);
 echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
echo "<script>alert('APPOINTMENT HAS BEEN CONFIRMED AT $time DATE:$date WITH Dr.$dgname!');</script>";
 
//echo "Successfully Submitted";
}           
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
         <?php
		 
	 $sid=$_REQUEST['id'];
	 $q=mysql_query("select * from amc_setslots where s_id='$sid'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $ddname =$q_data['d_name'];
		  $ddid =$q_data['d_id'];
		 //$dfield =$q_data['d_field'];
		 $ddate =$q_data['d_date'];
		 $dtime =$q_data['d_time'];
		 $ssid=$q_data['s_id'];
		 //$fid =$q_data['s_id'];
	 }
		
	 
	  ?>     
        <div class="analyst_right" style="height:auto; margin-top:30px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
          <input type="hidden" value="<?php echo $u_id; ?>" name="userid" />
           <input type="hidden" value="<?php echo $ssid; ?>" name="ssid" />
         <input type="hidden" value="<?php echo $unameQ; ?>" name="uname" />
         <input type="hidden" value="<?php echo $ddid; ?>" name="ddid" />
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">DR.NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="drname"  value="<?php echo $ddname; ?>"  style="padding-left:5px;" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">DATE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="ddate" value="<?php echo $ddate;?>"  style="padding-left:5px;" /></div>
          </div>
       <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">TIME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="time" value="<?php echo $dtime;?>"  style="padding-left:5px;" /></div>
          </div>
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px; float:left;"><input type="submit" name="name" value="Ok" style="background-color:#36F;width:80px; color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          <div style="width:80px;text-align:center;margin-top:7px; float:left;margin-left:5px;"><input type="button" name="button" value="cancel" onclick="location.href='appointment.php'"  style="background-color:#36F;width:80px; color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          </div>
         </form>
         </div>
         
        
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Copyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>