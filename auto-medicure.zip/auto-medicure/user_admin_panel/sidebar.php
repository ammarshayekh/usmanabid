<?php
/*$qqkq=mysql_query("select count(user_id) as user_id from amc_reuest where req_status='1'",$con);
	 while($qqkq_data=mysql_fetch_array($qqkq))
	 {
		 $mm = $qqkq_data['user_id'];
		 
		
	 }*/
	  ?>    
<div class="center_left">
        
         <div class="features">   
           
                    <ul class="list">
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px; width:200px;">
                    <li><a href="index.php" style="color:
                    #FFF;">HOME</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="profiled.php" style="color:
                    #FFF;">PROFILE</a></li></div>
                  <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="addmembers.php" style="color:
                    #FFF;">ADD MEMBERS</a></li></div>
                   <!-- <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="appointmentdemo.php?searc_name=''" style="color:
                    #FFF;">APPOINTMENT</a></li></div>--->
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="medicalhistory.php" style="color:
                    #FFF;">MEDICAL HISTORY</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="contextbase_searching.php?searc_name=''" style="color:
                    #FFF;">CONTEXT BASE SEARCHING</a></li></div>
                     <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="chemist.php" style="color:
                    #FFF;">CHEMIST</a></li></div>
                   
                    <!--<div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="appointmentstatus.php" style="color:
                    #FFF;">APPOINMENT STATUS (<?php //echo $mm;?>)</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="rating-medicine.php" style="color:
                    #FFF;">MEDICINE RATING</a></li></div>--->
                    <!--- <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="userrating.php" style="color:
                    #FFF;">DOCTOR RATING </a></li></div>
                     <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="expertsystem.php" style="color:
                    #FFF;">EXPERT SYSTEM</a></li></div>-->
                   
                    
                    </ul> 
         </div> 
         
         
          
         
         
           
            
            
        </div>