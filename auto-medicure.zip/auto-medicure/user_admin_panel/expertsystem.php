<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Expert-System</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="get" action="expertsystemshow.php">
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">SEARCH</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="searc_name" placeholder="ENTER SYMPTOMS" style="padding-left:5px;" /></div>
          </div>
          
       <!--<div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">ADDRESS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="address" placeholder="ENTER ADDRESS" style="padding-left:5px;" /></div>
          </div> -->
          <div style="width:460px; height:100px;">
          <?php
  $q=mysql_query("select * from amc_main_image",$con);
 while($q_data=mysql_fetch_array($q))
 {
	 $imge_name=$q_data['imge_name'];
	 $imgid=$q_data['imgid'];
 ?>
          <a href="expertsystemsubimg.php?imgid=<?php echo $imgid;?>">
         <div style="width:220px; height:100px; float:left; text-align:right; padding-right:10px; "><img src="../administration/<?php echo $imge_name; ?>" height="100" width="220" /></div>
         </a>
        
          <?php } ?>
          </div>
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="Search" style="background-color:#36F; color:#FFF; height:25px;width:80px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         
         </div>
       
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>