<?php
include('config.php');
$user_name=''; $user_cnicno='';  $user_age=''; $user_email='';$user_cellno='';$user_gender='';$user_address='';$user_city='';$user_pincode='';$user_state='';$user_country=''; $uname='';$uemail='';

   if(isset($_POST['user_name']) && !empty($_POST['user_name']) AND isset($_POST['user_cnicno']) && !empty($_POST['user_cnicno']) AND isset($_POST['user_age']) && !empty($_POST['user_age'])AND isset($_POST['user_email']) && !empty($_POST['user_email'])AND isset($_POST['user_cellno']) && !empty($_POST['user_cellno'])AND isset($_POST['user_gender']) && !empty($_POST['user_gender'])AND isset($_POST['user_address']) && !empty($_POST['user_address'])AND isset($_POST['user_city']) && !empty($_POST['user_city'])AND isset($_POST['user_pincode']) && !empty($_POST['user_pincode'])AND isset($_POST['user_state']) && !empty($_POST['user_state'])AND isset($_POST['user_country']) && !empty($_POST['user_country'])){
    $user_name = mysql_escape_string($_POST['user_name']); // Turn our post into a local variable
    $user_cnicno = mysql_escape_string($_POST['user_cnicno']); // Turn our post into a local variable
	$user_age = mysql_escape_string($_POST['user_age']); // Turn our post into a local variable
	$user_email = mysql_escape_string($_POST['user_email']); // Turn our post into a local variable
	$user_cellno = mysql_escape_string($_POST['user_cellno']); // Turn our post into a local variable
	$user_gender = mysql_escape_string($_POST['user_gender']); // Turn our post into a local variable
	$user_address = mysql_escape_string($_POST['user_address']); // Turn our post into a local variable
	$user_city = mysql_escape_string($_POST['user_city']); // Turn our post into a local variable
	$user_pincode = mysql_escape_string($_POST['user_pincode']); // Turn our post into a local variable
	$user_state = mysql_escape_string($_POST['user_state']); // Turn our post into a local variable
	$user_country = mysql_escape_string($_POST['user_country']); // Turn our post into a local variable
	
	   
	   $update=mysql_query("update amc_user set user_name='$user_name',user_cnicno='$user_cnicno',user_age='$user_age',user_email='$user_email',user_cellno='$user_cellno',user_gender='$user_gender',	user_address='$user_address',user_city='$user_city',user_pincode='$user_pincode',user_state='$user_state',user_country='$user_country' where user_id='$u_id'",$con);
	   echo "<script>alert('PROFILE UPDATED SUCCESSFULLY!');</script>";
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Profile</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
         <?php  
	 
	 $q=mysql_query("select * from amc_user where user_session_id='$ses_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $username =$q_data['user_name'];
		 $usercnicno =$q_data['user_cnicno'];
		 $userage =$q_data['user_age'];
		 $useremail =$q_data['user_email'];
		 $usercellno =$q_data['user_cellno'];
		 $usergender =$q_data['user_gender'];
		 $useraddress =$q_data['user_address'];
		 $usercity =$q_data['user_city'];
		 $userpincode =$q_data['user_pincode'];
		 $userstate =$q_data['user_state'];
		 $usercountry =$q_data['user_country'];
		
	 }
	  ?>     
        <div class="analyst_right" style="height:auto; margin-top:30px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_name" value="<?php echo $username;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CNIC #</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_cnicno" value="<?php echo $usercnicno;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">AGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_age" value="<?php echo $userage;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">E-MAIL</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_email" value="<?php echo $useremail;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CELL #</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_cellno" value="<?php echo $usercellno;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">GENDER</div>
          <div style="width:57px; float:left; text-align:center;margin-top:7px;">M<input type="radio" name="user_gender" value="<?php echo $usergender;?>" /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">F<input type="radio" name="user_gender" value="<?php echo $usergender;?>" /></div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">ADDRESS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_address" value="<?php echo $useraddress;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CITY</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_city" value="<?php echo $usercity;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">ZIP CODE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_pincode" value="<?php echo $userpincode;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">STATE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_state" value="<?php echo $userstate;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">COUNTRY</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="user_country" value="<?php echo $usercountry;?>" /></div>
          </div>
          
          
          
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="SAVE" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        
         
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>