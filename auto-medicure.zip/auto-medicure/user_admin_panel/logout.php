<?php include('config.php'); ?>
<?php

$uupdate=mysql_query("update amc_user set user_session_id='0' where user_session_id='$ses_id'",$con);

echo "<meta http-equiv=\"refresh\" content=\"0;URL=../login.php\">";
?>
