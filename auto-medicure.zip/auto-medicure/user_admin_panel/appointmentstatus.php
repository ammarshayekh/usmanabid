<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment Status</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
    
      <div class="analyst_right" style="height:auto;">
        
         
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:140px; float:left; text-align:center;  border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Member's Name</div>
         <div style="width:140px; float:left;text-align:center;   border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Doctor's Name</div>
          <div style="width:80px; float:left;text-align:center;  border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Date</div>
          <div style="width:80px; float:left;text-align:center;  border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Time</div>
          
          <div style="width:110px; float:left; text-align:center; text-align:center;color:#FFF;margin-top:7px;">Status</div>
         </div>
          <?php  
	 
	 $q=mysql_query("select * from amc_reuest where user_id='$u_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		
		  $doc_id =$q_data['doc_id'];
		  $member_id =$q_data['member_id'];
		  $date =$q_data['req_date'];
		   $time =$q_data['timetable'];
		    $status =$q_data['req_status'];
	
	$q1=mysql_query("select * from amc_addmembers where m_id = '$member_id'",$con);
	while($q1_data=mysql_fetch_array($q1))
		{
		$member_name = $q1_data['member_name'];	
		}
		 $q11=mysql_query("select * from amc_doctor where dr_id = '$doc_id'",$con);
	while($q11_data=mysql_fetch_array($q11))
		{
		$doctor_name = $q11_data['dr_name'];	
		}
	 
	  ?>     
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:140px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $member_name;?></div>
         <div style="width:140px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $doctor_name;?></div>
          <div style="width:80px; float:left; text-align:center;color:#FFF;margin-top:7px;border-right:2px solid #FFF; color:#FFF;"><?php echo $date;?></div>
          <div style="width:80px; float:left; text-align:center;color:#FFF;margin-top:7px;border-right:2px solid #FFF; color:#FFF;"><?php echo $time;?></div>
          <?php if($status == 1){?>
          <div style="width:110px; float:left; text-align:center;color:#FFF;margin-top:7px;">Approved</div>
          <?php }  if($status == 0){ ?>
          <div style="width:110px; float:left; text-align:center;color:#FFF;margin-top:7px;">Pending</div>
          <?php } if($status == 2){ ?>
          <div style="width:110px; float:left; text-align:center;color:#FFF;margin-top:7px;">Canceled</div>
          <?php }?>
          
         </div>
         <?php }?>
        </div>
       
        
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>   
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>