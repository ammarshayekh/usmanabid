<?php include('config.php'); ?>
<?php

 $id=$_REQUEST['id'];
 $date=$_REQUEST['date'];
 $days=$_REQUEST['days'];
 $time=$_REQUEST['time'];
 $member_id=$_REQUEST['member_id'];
	   mysql_query("insert into amc_reuest(user_id,doc_id,member_id,req_date,days,timetable)values('$u_id','$id','$member_id','$date','$days','$time')",$con);
       echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
        echo "<script>alert('PLEASE WAITING FOR APPROVAL AND AFTER CONFIRMATION OF APPROVAL THEN SEND SMS THAT YOUR REQUEST IS APPROVED FOR APPOINTMENT!');</script>";
 
?>
