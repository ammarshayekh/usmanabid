<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment Status</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
     <?php     
	 $q=mysql_query("select * from amc_reuest where user_id='$u_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		$status =$q_data['status'];
		
		 
	 }
	  ?>  
        <?php
		if($status == 1)
		{
			?>
        <div class="center_right" style="width:550px; text-align:center; padding-top:50px; font-weight:1000;">
       Your Appointment Request Has been Confirmed
        </div>  
		<?php }
		
		if($status == 2){?>
		
        <div class="center_right" style="width:550px; text-align:center; padding-top:50px; font-weight:1000; color:#F00;">
       Your Appointment Request Has been Canceled
        </div>
        <?php } if($status == 0) {?>
        
        <div class="center_right" style=" width:550px; text-align:center; padding-top:50px; font-weight:1000;">
       Your Appointment Request is Processing Please wait...
        </div>
        <?php } ?>
        
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>   
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>