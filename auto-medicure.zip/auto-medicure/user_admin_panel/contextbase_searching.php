<?php
include('config.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Expert-System</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="contextbase_searching.php">
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">SEARCH</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="searc_name" placeholder="CONTEXT BASE SEARCHING" style="padding-left:5px;" size="30" /></div>
          </div>
          
       
          
          <div style="width:460px; height:40px; margin-top:5px;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:120px;"><input type="submit" name="name" value="Search" style="background-color:#36F; color:#FFF; height:25px;width:80px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         
         </div>
       <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:370px; float:left; padding-left:30px; color:#FFF; margin-top:7px;">Medicine Name</div>
           <?php  
		   
	 $searchname=$_POST['searc_name'];
	
	 $q=mysql_query("select * from amc_prescription where symptoms='$searchname' ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		
		  $symptoms =$q_data['symptoms'];
		 
		 $q3= mysql_query("select * from amc_medicines where med_type='$symptoms'",$con);
	     while($q3_data=mysql_fetch_array($q3))
		 {
			 $medname=$q3_data['med_name'];
		 }
	  ?>     
          
          <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         
         <div style="width:190px; float:left; text-align:center; padding-left:10px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $medname;?></div>
          
         </div>
          <?php }?>
         </div>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>