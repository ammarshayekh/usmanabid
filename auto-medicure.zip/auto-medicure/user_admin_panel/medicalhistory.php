<?php
include('config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Addmembers</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         
         </div>
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:200px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">User's Name</div>
           <div style="width:200px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Member's Name</div>
          
          <div style="width:150px; float:left; text-align:center;color:#FFF;margin-top:7px;">Action</div>
         </div>
          <?php  
	 
	 $q=mysql_query("select * from amc_prescription where user_id='$u_id' ",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		// $doid =$q_data['doc_id'];
		  $useridd =$q_data['user_id'];
		  $memberid =$q_data['member_id'];
		  //$mid =$q_data['pres_id'];
		 
		 $q2= mysql_query("select * from amc_user where user_id='$useridd'",$con);
	     while($q2_data=mysql_fetch_array($q2))
		 {
			 $usernname=$q2_data['user_name'];
		 }
		 $q3= mysql_query("select * from amc_addmembers where m_id='$memberid'",$con);
	     while($q3_data=mysql_fetch_array($q3))
		 {
			 $membername=$q3_data['member_name'];
		 }
	  ?>     
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:200px; text-align:center; float:left;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $usernname;?></div>
         <div style="width:190px; float:left; text-align:center; padding-left:10px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $membername;?></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="medicalhistoryview.php?medicalview=<?php echo $memberid; ?>" style="color:#FFF; text-decoration:none;">View</a></div>
         </div>
         <?php }?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>