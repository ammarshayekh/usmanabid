<?php
//$dob='1984-10-02';
$orderdate = explode('-', $dob);
$year1 = $orderdate[0];
$month1   = $orderdate[1];
$day1  = $orderdate[2];


error_reporting(0);
function leapYearFeb($year, $mon) //Leap year checking
{
    $flag = 0;
    if ($year % 100 == 0) 
    {
        if ($year % 400 == 0) 
        {
            if ($mon == 2) 
            {
                $flag = 1;
            }
        }
    } 
    else if ($year % 4 == 0) 
    {
        if ($mon == 2) 
        {
            $flag = 1;
        }
    }
    return ($flag);
}
 $daysInMon = array(31, 28, 31, 30, 31, 30,31, 31, 30, 31, 30, 31);  

$day=$day1;
$month=$month1;
$year=$year1;

//echo "\nDate of Birth: ".$day. "/" .$month. "/" .$year;

//echo "\nCurrent Date: ".date("d"). "/" .date("m"). "/" .date("Y");

if (leapYearFeb($year, $month)) //Checking the given year Leap or not
{
    $days = $days + 1;
}
    $days1 = $days + date("d");
    $month1 = (12 - $month) + date("m");
    $year1 = date("Y")- $year-1;

if (leapYearFeb(date("Y"), (date("m") + 1))) 
{
    if ($days >= ($daysInMon[date("m")] + 1)) 
    {
        $days = $days - ($daysInMon[date("m")] + 1);
        $month = $month + 1;
    }
} 
else if ($days >= $daysInMon[date("m")]) 
{
    $days = $days - ($daysInMon[date("m")]);
    $month = $month + 1;
}

if ($month >= 12) 
{
    $year = $year + 1;
    $month = $month - 12;
}

//echo "\nAge :" .$year1."years". $month1. "months" .$days1."days";

/*
$dateOfBirth = "1984-10-02";
$today = date("Y-m-d");
$diff = date_diff(date_create($dateOfBirth), date_create($today));
echo 'Age is '.$diff->format('%y');
*/

?>