<?php
include('config.php');
 $doname=''; $dofield='';$date='';$time='';$month=''; $did='';

        if(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['addtime']) && !empty($_POST['addtime'])){
	   $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	   //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	   $addtime = mysql_escape_string($_POST['addtime']); // Turn our post into a local variable
	   $date=date('d-m-Y');
	   
	   mysql_query("insert into amc_setting_timetable(do_id,timetable,date)values('$did','$addtime','$date')",$con);
       //echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
        echo "<script>alert('ADD TIME TABLE SUCCESSFULLY!');</script>";
		}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<script language="JavaScript">
	function selectAll(source) {
		checkboxes = document.getElementsByClassName("name");
		for(var i in checkboxes)
			checkboxes[i].checked = source.checked;
	}
</script>
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
      <input type="hidden" name="did" value="<?php echo $u_id; ?>" />
          
          <div style="width:460px; height: auto;">
        
          <div style="width:460px; height:40px;">
         <div style="width:130px; float:left; text-align:center; margin-top:10px;">ADD TIME TABLE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="addtime" value="" placeholder="e.g.6:30-7:00 PM" /></div>
          </div>
          <div style="clear:both"></div>
          </div>
          <div style="width:460px; height:40px; margin-top:5px; float:left;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:130px; float:left;"><input type="submit" name="submit" value="Save" style="background-color:#36F;width:80px; color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>