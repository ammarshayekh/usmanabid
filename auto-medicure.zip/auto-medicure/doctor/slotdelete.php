<?php include('config.php'); ?>
<?php
$id = $_REQUEST['id'];
$uupdate=mysql_query("delete from amc_timetable  where t_id='$id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=slotsedit.php\">";
echo "<script>alert('SLOT REMOVE SUCCESSFULLY!');</script>";
?>
