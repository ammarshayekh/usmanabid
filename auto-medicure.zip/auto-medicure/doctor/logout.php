<?php include('config.php'); ?>
<?php

$uupdate=mysql_query("update amc_doctor set dr_session_id='0' where dr_session_id='$ses_id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
?>
