<?php
include('dbconfig.php');
if($_POST['id'])
{
	$id=$_POST['id'];
	
	$stmt = $DB_con->prepare("SELECT * FROM amc_addmembers WHERE user_id=:id");
	$stmt->execute(array(':id' => $id));
	?><option selected="selected">Select users :</option><?php
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		?>
		<option value="<?php echo $row['m_id']; ?>"><?php echo $row['member_age']; ?></option>
		<?php
	}
}
?>