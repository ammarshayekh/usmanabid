<?php include('config.php'); ?>
<?php
$id = $_REQUEST['id'];
$uupdate=mysql_query("delete from amc_setting_timetable  where set_id='$id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=deletetimetable.php\">";
echo "<script>alert('TIME REMOVE SUCCESSFULLY!');</script>";
?>
