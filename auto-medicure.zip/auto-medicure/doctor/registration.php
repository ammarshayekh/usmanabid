<?php
include("config.php");
$dr_name=''; $dr_cnicno='';  $dr_email='';  $dr_cellno=''; $dr_gender=''; $dr_address='';$dr_city='';$dr_degination='';$dr_field='';$dr_pmdcno='';$dr_scandegree='';$dr_password=''; $drcnic='';$dremail='';$drcellno=''; $drpmdcno='';

   if(isset($_POST['dr_name']) && !empty($_POST['dr_name']) AND isset($_POST['dr_cnicno']) && !empty($_POST['dr_cnicno']) AND isset(  $_POST['dr_email']) && !empty($_POST['dr_email']) AND isset($_POST['dr_cellno']) && !empty($_POST['dr_cellno']) AND isset($_POST[  'dr_gender']) && !empty($_POST['dr_gender'])AND isset($_POST['dr_address']) && !empty($_POST['dr_address'])AND isset($_POST['dr_city']) && !empty($_POST['dr_city'])AND isset($_POST['dr_degree']) && !empty($_POST['dr_degree'])AND isset($_POST['dr_field']) && !empty($_POST['dr_field'])AND isset($_POST['dr_pmdcno']) && !empty($_POST['dr_pmdcno'])AND isset($_POST['dr_password']) && !empty($_POST['dr_password'])){
	   //=======================================
        $target_path = "image/";
        $target_path = $target_path . basename( $_FILES['image_upload']['name']);
        $target_path = "image/";
        $target_path = $target_path . basename( $_FILES['image_upload']['name']);
        $Target = $target_path;
        move_uploaded_file($_FILES['image_upload']['tmp_name'], $target_path);
       //=========================================
    $dr_name = mysql_escape_string($_POST['dr_name']); // Turn our post into a local variable
    $dr_cnicno = mysql_escape_string($_POST['dr_cnicno']); // Turn our post into a local variable
	$dr_email = mysql_escape_string($_POST['dr_email']); // Turn our post into a local variable
    $dr_cellno = mysql_escape_string($_POST['dr_cellno']); // Turn our post into a local variable
	$dr_gender = mysql_escape_string($_POST['dr_gender']); // Turn our post into a local variable
	$dr_address = mysql_escape_string($_POST['dr_address']); // Turn our post into a local variable
	$dr_city = mysql_escape_string($_POST['dr_city']); // Turn our post into a local variable
	$dr_degination = mysql_escape_string($_POST['dr_degree']); // Turn our post into a local variable
	$dr_field = mysql_escape_string($_POST['dr_field']); // Turn our post into a local variable
	$dr_pmdcno = mysql_escape_string($_POST['dr_pmdcno']); // Turn our post into a local variable
	//$dr_scandegree = mysql_escape_string($_POST['dr_scandegree']); // Turn our post into a local variable
	$dr_password = mysql_escape_string($_POST['dr_password']); // Turn our post into a local variable
	//echo $dr_name;
	$date=date('d-m-Y');
	     $qq1=mysql_query("select * from amc_doctor where dr_cnicno='$dr_cnicno'",$con);
	 while($qq1_data=mysql_fetch_array($qq1))
	 {
		 $drcnic=$qq1_data['dr_cnicno'];	
	 }
	  if($dr_cnicno == $drcnic)
	       {
		   echo "<script>alert('CNIC NO is Already exit.Please Try Again!');</script>";
		   //echo "Company Name is Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   echo "<meta http-equiv=\"refresh\" content=\"0;URL=registration.php\">";
		    exit();
			 }
	    $qq11=mysql_query("select * from amc_doctor where dr_email='$dr_email'",$con);
	 while($qq11_data=mysql_fetch_array($qq11))
	 {
		$dremail=$qq11_data['dr_email'];
		
	 }
	    if($dr_email == $dremail)
	   {
		    echo "<script>alert('Email Address Already exit.Please Try Again!');</script>";
		   //echo "Email Address Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   echo "<meta http-equiv=\"refresh\" content=\"0;URL=registration.php\">";
		     exit();
			 }
	    $qq11c=mysql_query("select * from amc_doctor where dr_cellno='$dr_cellno'",$con);
	 while($qq11c_data=mysql_fetch_array($qq11c))
	 {
		 $drcellno=$qq11c_data['dr_cellno'];
		 }
	    if($dr_cellno == $drcellno)
	   {
		    echo "<script>alert('Cell No is Already exit.Please Try Again!');</script>";
		   //echo "Email Address Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   echo "<meta http-equiv=\"refresh\" content=\"0;URL=registration.php\">";
		     exit();
			 }
			  $qq11p=mysql_query("select * from amc_doctor where dr_pmdcno='$dr_pmdcno'",$con);
	    while($qq11p_data=mysql_fetch_array($qq11p))
	     {
		 $drpmdcno=$qq11p_data['dr_pmdcno'];
		 }
	    if($dr_pmdcno == $drpmdcno)
	   {
		    echo "<script>alert('PMDC NO is Already exit.Please Try Again!');</script>";
		   //echo "Email Address Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   echo "<meta http-equiv=\"refresh\" content=\"0;URL=registration.php\">";
		     exit();
			 }
	    // mysql_query("insert into amc_user(user_name,user_cnicno,user_session_id) values ('$user_name','$user_cnicno','$ses_id')",$con);
	  mysql_query("insert into amc_doctor(dr_name,dr_cnicno,dr_email,dr_cellno,dr_gender,dr_address,dr_city,dr_degree,dr_field,dr_pmdcno,image_upload,dr_password,dr_session_id,doc_date) values ('$dr_name','$dr_cnicno','$dr_email','$dr_cellno','$dr_gender','$dr_address','$dr_city','$Target','$dr_field','$dr_pmdcno','$Target','$dr_password','$ses_id','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('Waiting For Approval!');</script>";
 
//echo "Successfully Submitted";
}           
?>
<html>
<head>
<title>Doctor Registration Form</title>
<style type="text/css">
h3{font-family: Calibri; font-size: 22pt; font-style: normal; font-weight: bold; color:#06F;
text-align: center; text-decoration: underline }
table{font-family: Calibri; color:white; font-size: 11pt; font-style: normal;
text-align:; background-color:#3391E7; border-collapse: collapse; border: 2px solid #3391E7;}
table.inner{border: 0px}
</style>
</head>
<body>
<h3>DOCTOR REGISTRATION FORM</h3>
<form action="" method="POST" enctype="multipart/form-data">
 
<table align="center" cellpadding = "10">
 
<!----- First Name ---------------------------------------------------------->
<tr>
<td>NAME</td>
<td><input type="text" name="dr_name" maxlength="30"/>
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Last Name ---------------------------------------------------------->
<tr>
<td>CNIC NO</td>
<td><input type="text" name="dr_cnicno" maxlength="30"/>
(max 30 characters a-z and A-Z)
</td>
</tr>
<!----- Email Id ---------------------------------------------------------->
<tr>
<td>EMAIL ID</td>
<td><input type="text" name="dr_email" maxlength="100" /></td>
</tr>
 
<!----- Mobile Number ---------------------------------------------------------->
<tr>
<td>MOBILE NUMBER</td>
<td>
<input type="text" name="dr_cellno" maxlength="10" />
(10 digit number)
</td>
</tr>
 
<!----- Gender ----------------------------------------------------------->
<tr>
<td>GENDER</td>
<td>
Male <input type="radio" name="dr_gender" value="Male" />
Female <input type="radio" name="dr_gender" value="Female" />
</td>
</tr>
 
<!----- Address ---------------------------------------------------------->
<tr>
<td>ADDRESS <br /><br /><br /></td>
<td><textarea name="dr_address" rows="4" cols="30"></textarea></td>
</tr>
 
<!----- City ---------------------------------------------------------->
<tr>
<td>CITY</td>
<td><input type="text" name="dr_city" maxlength="30" />
(max 30 characters a-z and A-Z)
</td>
</tr>
<!----- Degsination ---------------------------------------------------------->
<tr>
<td>DEGREE</td>
<td><input type="text" name="dr_degree" maxlength="30" />
(max 30 characters a-z and A-Z)
</td>
</tr>
<!----- Field ---------------------------------------------------------->
<tr>
<td>FIELD</td>
<td><input type="text" name="dr_field" maxlength="30" />
(max 30 characters a-z and A-Z)
</td>
</tr>
<!----- Pmdcno ---------------------------------------------------------->
<tr>
<td>PMDC NO</td>
<td><input type="text" name="dr_pmdcno" maxlength="30" />
(max 30 characters a-z and A-Z)
</td>
</tr>
<!----- Scandegree ---------------------------------------------------------->
<tr>
<td>SCAN DEGREE</td>
<td><input type="file" name="image_upload" />
</td>
</tr>
<!----- Password ---------------------------------------------------------->
<tr>
<td>PASSWORD</td>
<td><input type="password" name="dr_password" maxlength="15" />
(max 15 characters a-z and A-Z)
</td>
</tr>
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" value="Submit">
<input type="reset" value="Reset">
</td>
</tr>
</table>
 
</form>
 
</body>
</html>