<?php
include('config.php');
$username=''; $membername=''; $age='';$medicine='';$morning='';$afternoon='';$evening='';$night='';$nodays='';
   if(isset($_POST['presid']) && !empty($_POST['presid']) AND isset($_POST['docid']) && !empty($_POST['docid']) AND($_POST['username']) && !empty($_POST['username']) AND isset($_POST['membername']) && !empty($_POST['membername'])AND isset($_POST['age']) && !empty($_POST['age']) AND isset($_POST['medicine']) && !empty($_POST['medicine'])AND isset($_POST['symptoms']) && !empty($_POST['symptoms']) or isset($_POST['morning']) && !empty($_POST['morning']) or isset($_POST['afternoon']) && !empty($_POST['afternoon'])or isset($_POST['evening']) && !empty($_POST['evening']) AND isset($_POST['night']) && !empty($_POST['night'])AND isset($_POST['noday']) && !empty($_POST['noday'])){
	   $presid = mysql_escape_string($_POST['presid']); // Turn our post into a local variable
	   $doctorid = mysql_escape_string($_POST['docid']); // Turn our post into a local variable
    $username = mysql_escape_string($_POST['username']); // Turn our post into a local variable
    $membername = mysql_escape_string($_POST['membername']); // Turn our post into a local variable
	$age = mysql_escape_string($_POST['age']); // Turn our post into a local variable
	$medicine = mysql_escape_string($_POST['medicine']); // Turn our post into a local variable
	$symptoms = mysql_escape_string($_POST['symptoms']); // Turn our post into a local variable
	$morning = mysql_escape_string($_POST['morning']); // Turn our post into a local variable
	$afternoon = mysql_escape_string($_POST['afternoon']); // Turn our post into a local variable
	$evening = mysql_escape_string($_POST['evening']); // Turn our post into a local variable
	$night = mysql_escape_string($_POST['night']); // Turn our post into a local variable
	$nodays = mysql_escape_string($_POST['noday']); // Turn our post into a local variable
	
	//echo $username;$membername;
	   //mysql_query("insert into amc_prescription(doc_id,user_id,member_id,age,medicines_id,time_m,time_a,time_e,time_n,total_days) values ('$doctorid','$username','$membername','$age','$medicine','$morning','$afternoon','$evening','$night','$nodays')",$con);
	   $update=mysql_query("update amc_prescription set doc_id='$doctorid',user_id='$username',member_id='$membername',age='$age',medicines_id='$medicine',symptoms='$symptoms',	time_m='$morning',time_a='$afternoon',time_e='$evening',time_n='$night',total_days='$nodays' where pres_id='$presid'",$con);
	   echo "<script>alert('PRESCRIPTION FORM UPDATED SUCCESSFULLY!');</script>";
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=prescriptionform.php?userid=0&memberid=0\">";
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Prescription form</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
       
        <div class="analyst_right" style="height:auto; margin-top:30px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <div style="width:400px; height:40px;">
         <div style="width:100px;height:20px; padding-top:5px;border-radius:5px 5px 5px 5px; background-color:#36F; float:left; text-align:center; margin-top:10px; margin-left:350px;"><a href="prescriptionform.php?userid=0&memberid=0" style="background-color:#36F;width:80px;  text-decoration:none;color:#FFF; height:25px;  border-color:#36F; cursor:pointer;">BACK</a></div>
          </div>
          <?php
		  $idi=$_REQUEST['preid'];
		  ?>
         <form method="post" action="">
         <input type="hidden" name="docid" value="<?php echo $u_id;?>" />
          <input type="hidden" name="presid" value="<?php echo $idi;?>" />
         <div style="width:460px; height:40px;">
         <div style="width:120px; float:left; text-align:center; margin-top:10px;"> USER NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="username">
          
           <?php  
	 $idi=$_REQUEST['preid'];
	 $q=mysql_query("select * from amc_prescription inner join amc_user on amc_prescription.user_id = amc_user.user_id where pres_id='$idi'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $user_name =$q_data['user_name'];
		 $user_id =$q_data['user_id'];
		 
	 
	  ?>     
          <option value="<?php echo $user_id;?>"><?php echo $user_name;?></option>
          <?php } ?>
          </select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:120px; float:left; text-align:center; margin-top:10px;"> MEMBER NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="membername">
           
           <?php  
	$idi=$_REQUEST['preid'];
	 $qa=mysql_query("select * from amc_prescription inner join amc_addmembers on amc_prescription.member_id = amc_addmembers.m_id where pres_id='$idi'",$con);
	 while($qa_data=mysql_fetch_array($qa))
	 {
		 $member_name =$qa_data['member_name'];
		 
		 $member_id =$qa_data['m_id'];
		 
	 
	  ?>     
          <option value="<?php echo $member_id;?>"><?php echo $member_name;?></option>
          <?php } ?>
          </select>
          </div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:center; margin-top:10px;">AGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="age">
          
          
         <?php  
		 $idi=$_REQUEST['preid'];
		 $qaq=mysql_query("select * from amc_prescription where pres_id='$idi'",$con);
	 while($qaq_data=mysql_fetch_array($qaq))
	 {
		 
		 $member_age =$qaq_data['age'];
		 
	 
	  ?>     
          <option value="<?php echo $member_age;?>"><?php echo $member_age;?></option>
          <?php } ?>
          </select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:120px; float:left; text-align:center; margin-top:10px;">MEDICINE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="medicine">
          <?php  
		  $idi=$_REQUEST['preid'];
		  $qamq=mysql_query("select * from amc_prescription inner join amc_medicines on amc_prescription.medicines_id = amc_medicines.med_id where pres_id='$idi'",$con);
	 while($qamq_data=mysql_fetch_array($qamq))
	 {
		 
		 $med_name =$qamq_data['med_name'];
		  $med_id =$qamq_data['med_id'];
		 
	 
	  ?>     
          <option value="<?php echo $med_id;?>"><?php echo $med_name;?></option>
          <?php } ?>
          </select></div>
          </div>
          <?php
          $idi=$_REQUEST['preid'];
		  $mdm=mysql_query("select * from amc_prescription where pres_id='$idi'",$con);
	 while($mdm_data=mysql_fetch_array($mdm))
	 {
		 
		 //$medicine_name =$mdm_data['medicine_name'];
		 $symptoms=$mdm_data['symptoms'];
		  
		 
	 }
	  ?>     
          <div style="width:460px; height:40px;">
         <div style="width:145px; float:left; text-align:center; margin-top:10px;">SYMPTOMS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="symptoms" value="<?php echo $symptoms;?>"/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:140px; float:left; text-align:center; margin-top:10px;">TIMING</div>
          <?php  
		  $idi=$_REQUEST['preid'];
		  $qawtmq=mysql_query("select * from amc_prescription where pres_id='$idi'",$con);
	 while($qawtmq_data=mysql_fetch_array($qawtmq))
	 {
		 
		 $time_m=$qawtmq_data['time_m'];
		 $time_a=$qawtmq_data['time_a'];
		 $time_e=$qawtmq_data['time_e'];
		 $time_n=$qawtmq_data['time_n'];
		  
		 
	 }
	  ?>     
          <div style="width:57px; float:left; text-align:center;margin-top:7px;">M<input type="checkbox" name="morning" value="M" <?php echo ($time_m == 'M') ? 'checked="checked"' : ''; ?>  /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">A<input type="checkbox" name="afternoon" value="A" <?php echo ($time_a == 'A') ? 'checked="checked"' : ''; ?> /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">E<input type="checkbox" name="evening" value="E" <?php echo ($time_e == 'E') ? 'checked="checked"' : ''; ?> /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">N<input type="checkbox" name="night" value="N" <?php echo ($time_n == 'N') ? 'checked="checked"' : ''; ?> /></div>
          </div>
          <?php  
		  $idi=$_REQUEST['preid'];
		  $qatmq=mysql_query("select * from amc_prescription where pres_id='$idi'",$con);
	 while($qatmq_data=mysql_fetch_array($qatmq))
	 {
		 
		 $total_days =$qatmq_data['total_days'];
		  
		 
	 }
	  ?>     
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">NUMBER OF DAYS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;">
          <input type="text" name="noday" value="<?php echo $total_days;?>" placeholder="total number of days"/></div>
          </div>
          
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="UPDATE" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
         
        
         
        
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>