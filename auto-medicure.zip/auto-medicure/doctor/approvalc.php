<?php include('config.php'); ?>
<?php
 $uid=$_REQUEST['id'];
	   $uupdate=mysql_query("update amc_reuest set req_status='2' where re_id='$uid'",$con);
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
	   echo "<script>alert('APPOINTMENT REQUEST CANCEL SUCCESSFULLY!');</script>";
 
?>
