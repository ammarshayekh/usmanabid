<div class="center_left">
         <?php
		  include('config.php');
	 /*$drn=$_REQUEST['drname'];
	 $qq=mysql_query("select * from amc_appointmentc where d_id='$u_id'",$con);
	 while($qq_data=mysql_fetch_array($qq))
	 {
		// $unamee =$q_data['user_name'];
		 $ddrnameel =$qq_data['d_id'];
		 //$ddate =$q_data['d_date'];
		 //$dtime =$q_data['d_time'];
		// $fid =$q_data['s_id'];
		
		
	 }*/
	  $qqkq=mysql_query("select count(user_id) as user_id from amc_reuest where doc_id='$u_id' AND req_status ='0'",$con);
	 while($qqkq_data=mysql_fetch_array($qqkq))
	 {
		 $mm = $qqkq_data['user_id'];
		 
		
	 }
	  ?>     
         <div class="features">   
           
                    <ul class="list">
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px; width:200px;">
                    <li><a href="index.php" style="color:
                    #FFF;">HOME</a></li></div>
                     <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="profiled.php" style="color:
                    #FFF;">PROFILE</a></li></div>
                  <!---  <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="addtimetable.php" style="color:
                    #FFF;">ADD TIME TABLE</a></li></div>
                     <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="deletetimetable.php" style="color:
                    #FFF;">DELETE TIME TABLE</a></li></div>
                  <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="slotsdemo.php" style="color:
                    #FFF;">SET SLOTS</a></li></div>
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="slotsedit.php" style="color:
                    #FFF;">SLOT REMOVE</a></li></div>---->
                    <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="userdetail.php?id=<?php echo $u_id;?>" style="color:
                    #FFF;">APPOINTMENT REQUEST (<?php echo $mm;?>)</a></li></div>
                    <!--<div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="prescriptionform.php?userid=0&memberid=0" style="color:
                    #FFF;">PRESCRIPTION FORM</a></li></div>
                   
                     <div style="background-color:#36F; border-radius:5px 5px 5px 5px; color:#FFF; height:30px;width:200px;">
                    <li><a href="changepassword.php" style="color:
                    #FFF;">CHANGE PASSWORD</a></li></div>-->
                    
                    </ul> 
         </div> 
         
         
          
         
         
           
            
            
        </div>