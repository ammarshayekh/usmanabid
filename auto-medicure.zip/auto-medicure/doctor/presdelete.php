<?php include('config.php'); ?>
<?php
$id = $_REQUEST['prid'];
$uupdate=mysql_query("delete from amc_prescription  where pres_id='$id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=prescriptionform.php?userid=0&memberid=0\">";
echo "<script>alert(' REMOVE SUCCESSFULLY!');</script>";
?>
