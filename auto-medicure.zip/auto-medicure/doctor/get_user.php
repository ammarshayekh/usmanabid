<?php
include('dbconfig.php');
if($_POST['id'])
{
	$id=$_POST['id'];
		
	$stmt = $DB_con->prepare("SELECT * FROM amc_user");
	$stmt->execute(array(':id' => $id));
	?><option selected="selected">Select user :</option><?php
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		?>
        <option value="<?php echo $row['user_id']; ?>"><?php echo $row['user_name']; ?></option>
        <?php
	}
}
?>