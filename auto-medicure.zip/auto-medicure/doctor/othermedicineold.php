<?php
include('config.php');
$username=''; $membername=''; $age='';$medicine='';$morning='';$afternoon='';$evening='';$night='';$nodays='';
   if(isset($_POST['docid']) && !empty($_POST['docid']) AND($_POST['username']) && !empty($_POST['username']) AND isset($_POST['membername']) && !empty($_POST['membername'])AND isset($_POST['age']) && !empty($_POST['age']) AND isset($_POST['othermedicine']) && !empty($_POST['othermedicine'])AND isset($_POST['symptoms']) && !empty($_POST['symptoms']) or isset($_POST['morning']) && !empty($_POST['morning']) or isset($_POST['afternoon']) && !empty($_POST['afternoon'])or isset($_POST['evening']) && !empty($_POST['evening']) AND isset($_POST['night']) && !empty($_POST['night'])AND isset($_POST['noday']) && !empty($_POST['noday'])){
	   $doctorid = mysql_escape_string($_POST['docid']); // Turn our post into a local variable
    $username = mysql_escape_string($_POST['username']); // Turn our post into a local variable
    $membername = mysql_escape_string($_POST['membername']); // Turn our post into a local variable
	$age = mysql_escape_string($_POST['age']); // Turn our post into a local variable
	$medicine = mysql_escape_string($_POST['othermedicine']); // Turn our post into a local variable
	$symptoms = mysql_escape_string($_POST['symptoms']); // Turn our post into a local variable
	$morning = mysql_escape_string($_POST['morning']); // Turn our post into a local variable
	$afternoon = mysql_escape_string($_POST['afternoon']); // Turn our post into a local variable
	$evening = mysql_escape_string($_POST['evening']); // Turn our post into a local variable
	$night = mysql_escape_string($_POST['night']); // Turn our post into a local variable
	$nodays = mysql_escape_string($_POST['noday']); // Turn our post into a local variable
	$date=date('d-m-Y');
	
	//echo $username;$membername;
	   mysql_query("insert into amc_othermedicine(doc_id,user_id,member_id,medicine_name,symptoms,age,time_m,time_a,time_e,time_n,total_days,date) values ('$doctorid','$username','$membername','$medicine','$symptoms','$age','$morning','$afternoon','$evening','$night','$nodays','$date')",$con);
	   echo "<script>alert('PRESCRIPTION FORM UPLOADED SUCCESSFULLY!');</script>";
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=othermedicine.php\">";
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Prescription form</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
       
        <div class="analyst_right" style="height:auto; margin-top:30px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <div style="width:450px; height:40px;">
         <div style="width:100px;height:20px; padding-top:5px;border-radius:5px 5px 5px 5px; background-color:#36F; float:left; text-align:center; margin-top:10px; margin-left:340px;"><a href="prescriptionform.php" style="background-color:#36F;width:80px;  text-decoration:none;color:#FFF; height:25px;  border-color:#36F; cursor:pointer;">BACK</a></div>
          </div>
         <form method="post" action="">
         <input type="hidden" name="docid" value="<?php echo $u_id;?>" />
         <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;"> USER NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="username">
           <option selected="selected">Select User Name</option>
           <?php  
	 
	 $q=mysql_query("select * from amc_user",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $user_name =$q_data['user_name'];
		 $user_id =$q_data['user_id'];
		 
	 
	  ?>     
          <option value="<?php echo $user_id;?>"><?php echo $user_name;?></option>
          <?php } ?>
          </select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;"> MEMBER NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="membername">
           <option selected="selected">Select Member Name</option>
           <?php  
	// $useridd=$_REQUEST['username'];
	 $qa=mysql_query("select * from amc_addmembers",$con);
	 while($qa_data=mysql_fetch_array($qa))
	 {
		 $member_name =$qa_data['member_name'];
		 
		 $member_id =$qa_data['m_id'];
		 
	 
	  ?>     
          <option value="<?php echo $member_id;?>"><?php echo $member_name;?></option>
          <?php } ?>
          </select>
          </div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:135px; float:left; text-align:center; margin-top:10px;">AGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="age">
          <option selected="selected">Select Age</option>
         <?php  $qaq=mysql_query("select * from amc_addmembers",$con);
	 while($qaq_data=mysql_fetch_array($qaq))
	 {
		 
		 $member_age =$qaq_data['member_age'];
		 
	 
	  ?>     
          <option value="<?php echo $member_age;?>"><?php echo $member_age;?></option>
          <?php } ?>
          </select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:145px; float:left; text-align:center; margin-top:10px;">OTHERS MEDICINE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="othermedicine"/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">SYMPTOMS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="symptoms" placeholder="enter symptoms"/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:140px; float:left; text-align:center; margin-top:10px;">TIMING</div>
          <div style="width:57px; float:left; text-align:center;margin-top:7px;">M<input type="checkbox" name="morning" value="M" /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">A<input type="checkbox" name="afternoon" value="A" /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">E<input type="checkbox" name="evening" value="E" /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">N<input type="checkbox" name="night" value="N" /></div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">NUMBER OF DAYS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="noday" placeholder="total number of days"/></div>
          </div>
          
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="ADD" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
         <div style="width:560px; height:30px; float:left; margin-bottom:5px;  font-weight:bold;">
      LIST OF MEDICINES PRESCRIBED
         </div>
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:220px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> MEDICINES NAME</div>
         <div style="width:120px; float:left; padding-left:20px; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">TIMINGS</div>
          <div style="width:50px; float:left; padding-left:0px; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">DAYS</div>
          
          
          <div style="width:120px; float:left; text-align:center;color:#FFF;margin-top:7px;">ACTION</div>
         </div>
          <?php  
	 
	 $qdd=mysql_query("select * from amc_othermedicine where doc_id='$u_id'",$con);
	 while($qdd_data=mysql_fetch_array($qdd))
	 {
		 $mednae =$qdd_data['medicine_name'];
		 $timem =$qdd_data['time_m'];
		 $timea =$qdd_data['time_a'];
		 $timee =$qdd_data['time_e'];
		 $timen =$qdd_data['time_n'];
		 $totaldays =$qdd_data['total_days'];
		$otherid =$qdd_data['other_id']; 
		 
	 
	  ?>     
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:220px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $mednae?></div>
         <div style="width:120px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $timem;?> + <?php echo $timea;?> + <?php echo $timee;?> + <?php echo $timen;?> </div>
         <div style="width:50px; float:left; padding-left:20px;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $totaldays;?></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="othermedicineedit.php?otherid=<?php echo $otherid;?>" style="color:#FFF; text-decoration:none;">Edit</a></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="otherpresdelete.php?otherid=<?php echo $otherid;?>" style="color:#FFF; text-decoration:none;">Delete</a></div>
         </div>
         <?php }?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>