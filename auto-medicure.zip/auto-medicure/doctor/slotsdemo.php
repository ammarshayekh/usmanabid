<?php
include('config.php');
             /*if(isset($_POST['submit'])){//to run PHP script on submit
            if(!empty($_POST['check_list'])){
            // Loop to store and display values of individual checked checkbox.
             foreach($_POST['check_list'] as $selected){
              echo $selectedd[] = $selected."</br>";
                  }
                    $finalsub = implode(',',$selectedd);
$date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t3,t4,t5,t6) values('$finalsub','$finalsub','$finalsub','$date','$finalsub','$finalsub','$finalsub','$finalsub','$finalsub','$finalsub','$finalsub')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
}
}*/
         $doname=''; $dofield='';$date='';$time='';$month=''; $did='';

        if(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['days']) && !empty($_POST['days'])){
	   $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	   //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	   //$doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	   //$dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	   $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	   echo $did;echo $doname;echo $dofield;echo $days;
	   $date=date('d-m-y');
	   mysql_query("insert into amc_setslots(d_id,d_date,days,session_id)values('$did','$date','$days','$ses_id')",$con);
       //echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
        echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
       $qq=mysql_query("select * from amc_setslots  where session_id='$ses_id'",$con);
	    while($qq_data=mysql_fetch_array($qq))
	       {
		      $detailid =$qq_data['s_id'];
			  echo $detailid;
	       }
		    foreach($_POST['check_list'] as $value){
				mysql_query("insert into amc_timetable(detail_id,doc_id,schedule,date)values('$detailid','$did','$value','$date')",$con);
            
                  }
	        echo $detailid;
			$uupdate=mysql_query("update amc_setslots set session_id='0' where session_id='$ses_id'",$con);
 
} 
 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<script language="JavaScript">
	function selectAll(source) {
		checkboxes = document.getElementsByClassName("name");
		for(var i in checkboxes)
			checkboxes[i].checked = source.checked;
	}
</script>
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
         <?php  
	 
	 $q=mysql_query("select * from amc_doctor  where dr_id='$u_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $dname =$q_data['dr_name'];
		  $dfield =$q_data['dr_field'];
		  $doid =$q_data['dr_id'];
		 
	 }
	  ?>     
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
          <input type="hidden" name="did" value="<?php echo $u_id; ?>" />
         <input type="hidden" name="dname" value="<?php echo $dname; ?>" />
         <input type="hidden" name="dfield" value="<?php echo $dfield; ?>" />
         
        <!-- <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Month</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px; margin-left:4px;"><select name="month"><option selected="selected">Select Month</option><option value="Jan">January</option><option value="Feb">Feburary</option><option value="Mar">March</option><option value="Apr">April</option><option value="May">May</option></select></div>
          </div>
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Date</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="date"><option selected="selected">Select Date</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Time</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="tme"><option selected="selected">Select Time</option><option value="6:15 PM">6:15 PM</option><option value="6:30 PM">6:30 PM</option><option value="6:45 PM">6:45 PM</option><option value="7:00 PM">7:00 PM</option></select></div>
          </div>-->
          <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Days</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="days"><option selected="selected">Select Day</option><option value="Monday">Monday</option><option value="Tuesday" id="monday">Tuesday</option><option value="Wensday">Wensday</option><option value="Thursday">Thursday</option><option value="Friday">Friday</option><option value="Saturday">Saturday</option><option value="Sunday">Sunday</option></select></div>
          </div>
          <div style="width:460px; height: auto;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Time</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" id="selectall" onClick="selectAll(this)"/> SELECT ALL</div>
          <div style="width:460px; height:auto; float:left;">
           <?php  
	 
	 $qa=mysql_query("select * from amc_setting_timetable  where do_id='$doid'",$con);
	 while($qa_data=mysql_fetch_array($qa))
	 {
		 $timetable =$qa_data['timetable'];
		  
		 
	 
	  ?>     
         <div style="width:100px; float:left; text-align:right; padding-right:10px; margin-top:10px;"><?php echo $timetable;?></div>
          <div style="width:20px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" name="check_list[]" class="name" value="<?php echo $timetable;?>"/></div>
           <?php } ?>
          </div>
         
          </div>
          
          <div style="width:460px; height:40px; margin-top:5px; float:left;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:130px; float:left;"><input type="submit" name="submit" value="Save" style="background-color:#36F;width:80px; color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>