<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
       
        <div class="analyst_right" style="height:auto;">
       <div style="width:560px; height:30px; background-color: #09F; float:left;">
         <div style="width:130px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Name</div>
         <div style="width:130px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Date</div>
          <div style="width:80px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Day</div>
          <div style="width:110px; text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Time-Table</div>
          
          <div style="width:90px; float:left; text-align:center;color:#FFF;margin-top:7px;">Action</div>
         </div>
          
         <?php  
	 $doctorid=$_REQUEST['id'];
	 $q=mysql_query("select * from amc_reuest inner join amc_addmembers on amc_reuest.member_id = amc_addmembers.m_id where doc_id = '$doctorid' and req_status !='2'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $restatus =$q_data['req_status'];
		
		 
	 
	  ?>  
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:130px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['member_name']; ?></div>
         <div style="width:130px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['req_date']; ?></div>
         <div style="width:80px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['days']; ?></div>
          <div style="width:110px; float:left; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $q_data['timetable']; ?></div>
           <?php
		  if($restatus ==0)
		  {
		  ?>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a style="text-decoration:none; color:#FFF;" href="approval.php?id=<?php echo $q_data['re_id']; ?>">Approve</a></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a style="text-decoration:none; color:#FFF;" href="approvalc.php?id=<?php echo $q_data['re_id']; ?>">Cancel</a></div>
           <?php } ?>
           <?php
		  if($restatus == 1)
		  {
		  ?>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;">Approved</div>
          <?php } ?>
         </div>
         <?php } ?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>