<?php
include('config.php');
    $doctorid = $_POST['doc_id'];
    $username = $_POST['user_id'];
    $membername =$_POST['member_id'];
	$age = $_POST['age']; 
	$symptoms = $_POST['symptoms'];
	$medicine = $_POST['othermedicine'];
	$morning = $_POST['morning'];
	$afternoon = $_POST['afternoon'];
	$evening =$_POST['evening'];
	$night = $_POST['night'];
	$nodays = $_POST['noday'];
	$date=date('d-m-Y');
	echo $doctorid; echo $username; echo $membername; echo $age;
	//echo $username;$membername;
	 //mysql_query("insert into amc_prescription(doc_id,user_id,member_id,age) values ('$doctorid','$username','$membername','$age')",$con);
	 mysql_query("insert into amc_othermedicine(doc_id,user_id,member_id,medicine_name,symptoms,age,time_m,time_a,time_e,time_n,total_days,m_date) values ('$doctorid','$username','$membername','$medicine','$symptoms','$age','$morning','$afternoon','$evening','$night','$nodays','$date')",$con);
	   echo "<script>alert('PRESCRIPTION FORM UPLOADED SUCCESSFULLY!');</script>";
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=othermedicine.php?userid=0&memberid=0\">";
   
   ?>