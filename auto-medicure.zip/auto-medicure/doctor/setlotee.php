<?php include('config.php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Index</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        <?php
$qqkq=mysql_query("select count(user_id) as user_id from amc_reuest where req_status='1'",$con);
	 while($qqkq_data=mysql_fetch_array($qqkq))
	 {
		 $mm = $qqkq_data['user_id'];
		 
		
	 }
	  ?>    
        
        <div class="analyst_right" style="height:auto;">
       
          <div style="width:300px; height:40px; margin-left:100px;">
         <div style="width:200px;height:20px; float:left; padding-top:5px;border-radius:5px 5px 5px 5px; background-color:#36F; float:left; text-align:center; margin-top:10px; margin-left:70px;"><a href="slotsdemo.php" style="background-color:#36F;width:80px;  text-decoration:none;color:#FFF; height:25px;  border-color:#36F; cursor:pointer;">SET SLOTS</a></div>
          
          </div>
          <div style="width:300px; height:40px; margin-left:100px;">
         <div style="width:200px;height:20px; float:left; padding-top:5px;border-radius:5px 5px 5px 5px; background-color:#36F; float:left; text-align:center; margin-top:10px; margin-left:70px;"><a href="slotsedit.php" style="background-color:#36F;width:80px;  text-decoration:none;color:#FFF; height:25px;  border-color:#36F; cursor:pointer;">REMOVE SLOTS</a></div>
          
          </div>
        </div>  
        
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>   
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>