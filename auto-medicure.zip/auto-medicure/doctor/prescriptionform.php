<?php
include('config.php');


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Prescription form</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
       
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <div style="width:400px; height:40px;">
         <div style="width:140px;height:20px; padding-top:5px;border-radius:5px 5px 5px 5px; background-color:#36F; float:left; text-align:center; margin-top:10px; margin-left:310px;"><a href="othermedicine.php?userid=0&memberid=0" style="background-color:#36F;width:80px;  text-decoration:none;color:#FFF; height:25px;  border-color:#36F; cursor:pointer;">OTHERS MEDICINES</a></div>
          </div>
         <?php
		 $userid=$_GET['userid'];
		 $memberid=$_GET['memberid'];
		 
		 
		 ?> 
         <form method="get" action="prescriptionform.php">
     <input type="hidden" name="memberid" value="0" />
         <div style="width:460px; height:40px;">
         <div style="width:145px; float:left; text-align:center; margin-top:10px;"> USER NAME</div>
          <div style="width:120px; float:left; text-align:center;margin-top:7px;">
          <select name="userid" class="brand" onchange="submit('parent')">
           <?php
		  if($userid == 0)
		  {
			?>
              <option>--Select User--</option>
            <?php  
		  }
		  
	$q=mysql_query("select * from amc_user where user_id = '$userid'",$con);
	while($q1_data=mysql_fetch_array($q))
	{
		?>
         <option selected="selected" value="<?php echo $userid; ?>"><?php echo $q1_data['user_name']; ?></option>
        <?php } ?>
        
      
          <?php
		  
	$q=mysql_query("select * from amc_user",$con);
	while($q1_data=mysql_fetch_array($q))
	{
		?>
        <option value="<?php echo $q1_data['user_id']; ?>"><?php echo $q1_data['user_name']; ?></option>
        <?php
	} 
?>
          </select></div>
          </div>
          </form>
          <form method="get" action="prescriptionform.php">
          <input type="hidden" name="userid" value="<?php echo $userid; ?>" />
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;"> MEMBER NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;">
           <select name="memberid" class="brand" onchange="submit('parent')">
            <?php
	
	  if($memberid == 0)
		  {
			?>
              <option>--Select Member--</option>
            <?php  
		  }
		  	  
	$q2=mysql_query("select * from amc_addmembers where m_id = '$memberid'",$con);
	while($q2_data=mysql_fetch_array($q2))
	
	{
		?>
        <option  value="<?php echo $memberid; ?>"><?php echo $q2_data['member_name']; ?></option>
        <?php
	} 
?>
        
          <?php
		  
	$q3=mysql_query("select * from amc_addmembers where user_id = '$userid'",$con);
	while($q3_data=mysql_fetch_array($q3))
	{
		?>
        <option value="<?php echo $q3_data['m_id']; ?>"><?php echo $q3_data['member_name']; ?></option>
        <?php
	} 
?>
          </select>
          </div>
          </div>
          </form>
          <form method="post" action="prescriptionform-save.php">
          <input type="hidden" name="user_id" value="<?php echo $userid; ?>" />
          <input type="hidden" name="member_id" value="<?php echo $memberid; ?>" />
          <input type="hidden" name="doc_id" value="<?php echo $u_id?>" />
          <?php
		  
	  if($memberid != 0)
		  {
$q4=mysql_query("select * from amc_addmembers where m_id = '$memberid'",$con);
	while($q4_data=mysql_fetch_array($q4))
	
	{
		$dob = $q4_data['member_age'];
		include('age-calculation.php');

	}
		  }
		  ?>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">AGE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;">
          <input type="text" name="age" value="<?php 
	  if($memberid != 0)
		  { echo $year1."years , ". $month1. "months , " .$days1."days"; }
		  
		  ?>" readonly="readonly" />
          </div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:145px; float:left; text-align:center; margin-top:10px;">MEDICINE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="medicine">
          <?php  $qamq=mysql_query("select * from amc_medicines",$con);
	 while($qamq_data=mysql_fetch_array($qamq))
	 {
		 
		 $med_name =$qamq_data['med_name'];
		  $med_id =$qamq_data['med_id'];
		 
	 
	  ?>     
          <option value="<?php echo $med_id;?>"><?php echo $med_name;?></option>
          <?php } ?>
          </select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">SYMPTOMS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="symptoms" placeholder="enter symptoms"/></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:140px; float:left; text-align:center; margin-top:10px;">TIMING</div>
          <div style="width:57px; float:left; text-align:center;margin-top:7px;">M<input type="checkbox" name="morning" value="M" /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">A<input type="checkbox" name="afternoon" value="A" /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">E<input type="checkbox" name="evening" value="E" /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">N<input type="checkbox" name="night" value="N" /></div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">NUMBER OF DAYS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="noday" placeholder="total number of days"/></div>
          </div>
          
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="ADD" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
         <div style="width:560px; height:30px; float:left; margin-bottom:5px;  font-weight:bold;">
      LIST OF MEDICINES PRESCRIBED
         </div>
        <div style="width:560px; height:30px; background-color: #09F; float:left;">
                 <div style="width:100px;text-align:center; float:left; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> User's Name</div>
         <div style="width:100px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> Member's Name</div>

         <div style="width:100px; float:left;text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;"> Medicines Name</div>
         <div style="width:80px; float:left; text-align:center;border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Timings</div>
          <div style="width:50px; float:left; padding-left:0px; text-align:center; border-right:2px solid #FFF; color:#FFF; margin-top:7px;">Days</div>
          
          
          <div style="width:120px; float:left; text-align:center;color:#FFF;margin-top:7px;">Action</div>
         </div>
          <?php  
	 
	 $qdd=mysql_query("select * from amc_prescription inner join amc_medicines on amc_prescription.medicines_id = amc_medicines.med_id inner join amc_user on amc_prescription.user_id = amc_user.user_id inner join amc_addmembers on amc_prescription.member_id = amc_addmembers.m_id  where doc_id='$u_id'",$con);
	 while($qdd_data=mysql_fetch_array($qdd))
	 {
		 $mednae =$qdd_data['med_name'];
		 $timem =$qdd_data['time_m'];
		 $timea =$qdd_data['time_a'];
		 $timee =$qdd_data['time_e'];
		 $timen =$qdd_data['time_n'];
		 $totaldays =$qdd_data['total_days'];
		 $preid =$qdd_data['pres_id'];
		 
		  /*$rqdd=mysql_query("select * from amc_prescription inner join amc_user on amc_prescription.user_id = amc_user.user_id where doc_id='$u_id'",$con);
	 while($rqdd_data=mysql_fetch_array($rqdd))*/
	 
		 $usernamemm =$qdd_data['user_name'];
		  /*$mrqdd=mysql_query("select * from amc_prescription inner join amc_addmembers on amc_prescription.member_id = amc_addmembers.m_id where doc_id='$u_id'",$con);
	 while($mrqdd_data=mysql_fetch_array($mrqdd))*/
	 
		 $membernamemmm =$qdd_data['member_name'];
		 
	 
	  ?>     
         <div style="width:560px; height:30px; background-color:#36F; margin-top:2px; float:left;">
         <div style="width:100px; text-align:center; float:left;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $usernamemm;?></div>
          <div style="width:100px; text-align:center;float:left;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $membernamemmm;?></div>
           <div style="width:100px;text-align:center; float:left;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $mednae?></div>
         <div style="width:80px; text-align:center; float:left;border-right:2px solid #FFF; color:#FFF; margin-top:7px;"><?php echo $timem.'+';?>  <?php echo $timea.'+' ;?>  <?php echo $timee .'+';?>  <?php echo $timen;?> </div>
         <div style="width:50px; float:left;border-right:2px solid #FFF;text-align:center;  color:#FFF; margin-top:7px;"><?php echo $totaldays;?></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="prescriptionformedit.php?preid=<?php echo $preid;?>" style="color:#FFF; text-decoration:none;">Edit</a></div>
          <div style="width:50px; float:left; text-align:center;color:#FFF;margin-top:7px;"><a href="presdelete.php?prid=<?php echo $preid;?>" style="color:#FFF; text-decoration:none;">Delete</a></div>
         </div>
         <?php }?>
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>