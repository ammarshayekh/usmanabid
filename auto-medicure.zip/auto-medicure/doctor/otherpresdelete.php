<?php include('config.php'); ?>
<?php
$id = $_REQUEST['otherid'];
$uupdate=mysql_query("delete from amc_othermedicine  where other_id='$id'",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=othermedicine.php?userid=0&memberid=0\">";
echo "<script>alert(' REMOVE SUCCESSFULLY!');</script>";
?>
