<?php
include('config.php');
$dr_name=''; $dr_cnicno=''; $dr_email='';$dr_cellno='';$dr_gender='';$dr_address='';$dr_city='';$dr_degree='';$dr_field='';$dr_pmdcno=''; $uname='';$uemail='';
   if(isset($_POST['dr_name']) && !empty($_POST['dr_name']) AND isset($_POST['dr_cnicno']) && !empty($_POST['dr_cnicno'])AND isset($_POST['dr_email']) && !empty($_POST['dr_email'])AND isset($_POST['dr_cellno']) && !empty($_POST['dr_cellno'])AND isset($_POST['dr_gender']) && !empty($_POST['dr_gender'])AND isset($_POST['dr_address']) && !empty($_POST['dr_address'])AND isset($_POST['dr_city']) && !empty($_POST['dr_city'])AND isset($_POST['dr_degree']) && !empty($_POST['dr_degree'])AND isset($_POST['dr_field']) && !empty($_POST['dr_field'])AND isset($_POST['dr_pmdcno']) && !empty($_POST['dr_pmdcno'])){
    $dr_name = mysql_escape_string($_POST['dr_name']); // Turn our post into a local variable
    $dr_cnicno = mysql_escape_string($_POST['dr_cnicno']); // Turn our post into a local variable
	$dr_email = mysql_escape_string($_POST['dr_email']); // Turn our post into a local variable
	$dr_cellno = mysql_escape_string($_POST['dr_cellno']); // Turn our post into a local variable
	$dr_gender = mysql_escape_string($_POST['dr_gender']); // Turn our post into a local variable
	$dr_address = mysql_escape_string($_POST['dr_address']); // Turn our post into a local variable
	$dr_city = mysql_escape_string($_POST['dr_city']); // Turn our post into a local variable
	$dr_degree = mysql_escape_string($_POST['dr_degree']); // Turn our post into a local variable
	$dr_field = mysql_escape_string($_POST['dr_field']); // Turn our post into a local variable
	$dr_pmdcno = mysql_escape_string($_POST['dr_pmdcno']); // Turn our post into a local variable
	
	   $update=mysql_query("update amc_doctor set dr_name='$dr_name',dr_cnicno='$dr_cnicno',dr_email='$dr_email',dr_cellno='$dr_cellno',dr_gender='$dr_gender',	dr_address='$dr_address',dr_city='$dr_city',dr_degree='$dr_degree',dr_field='$dr_field',dr_pmdcno='$dr_pmdcno' where dr_id='$u_id'",$con);
	   $update=mysql_query("update amc_appointmentc set dr_name='$dr_name' where d_id='$u_id'",$con);
	   echo "<script>alert('YOUR PROFILE HAVE BEEN UPDATED SUCCESSFULLY!');</script>";
	   echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Profile</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
        
         <?php  
	 
	 $q=mysql_query("select * from amc_doctor where dr_session_id='$ses_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $drname =$q_data['dr_name'];
		 $drcnicno =$q_data['dr_cnicno'];
		 $dremail =$q_data['dr_email'];
		 $drcellno =$q_data['dr_cellno'];
		 $drgender =$q_data['dr_gender'];
		 $draddress =$q_data['dr_address'];
		 $drcity =$q_data['dr_city'];
		  $drdegree =$q_data['dr_degree'];
		 $drfield =$q_data['dr_field'];
		 $drpmdcno =$q_data['dr_pmdcno'];
		 $drpassword =$q_data['dr_password'];
		
	 }
	  ?>     
        <div class="analyst_right" style="height:auto;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
         <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">NAME</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_name" value="<?php echo $drname;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CNIC #</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_cnicno" value="<?php echo $drcnicno;?>" /></div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">E-MAIL</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_email" value="<?php echo $dremail;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CELL #</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_cellno" value="<?php echo $drcellno;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">GENDER</div>
          <div style="width:57px; float:left; text-align:center;margin-top:7px;">M<input type="radio" name="dr_gender" value="<?php echo $drgender;?>" /></div><div style="width:59px; float:left; text-align:center;margin-top:7px;">F<input type="radio" name="dr_gender" value="<?php echo $drgender;?>" /></div>
          </div>
          
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">ADDRESS</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_address" value="<?php echo $draddress;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">CITY</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_city" value="<?php echo $drcity;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">DEGREE</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_degree" value="<?php echo $drdegree;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">FIELD</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_field" value="<?php echo $drfield;?>" /></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:150px; float:left; text-align:center; margin-top:10px;">PMDC #</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="text" name="dr_pmdcno" value="<?php echo $drpmdcno;?>" /></div>
          </div>
          
          <div style="width:460px; height:40px; margin-top:5px;">
         
          <div style="width:80px; float:left; text-align:center;margin-top:7px; margin-left:150px;"><input type="submit" name="name" value="SAVE" style="background-color:#36F;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        
         
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>