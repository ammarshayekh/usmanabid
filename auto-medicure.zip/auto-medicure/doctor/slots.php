<?php
include('config.php');
$doname=''; $dofield='';$date='';$time='';$month=''; $did='';

   if(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t4']) && !empty($_POST['t4'])AND isset($_POST['t5']) && !empty($_POST['t5'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  echo $t1;
	 // echo $member_name;
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t3,t4,t5,t6) values('$did','$doname','$dofield','$date','$days','$t1','$t2','$t3','$t4','$t5','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
} 
//echo "Successfully Submitted";
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t4']) && !empty($_POST['t4'])AND isset($_POST['t5']) && !empty($_POST['t5'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t3,t4,t5) values('$did','$doname','$dofield','$date','$days','$t1','$t2','$t3','$t4','$t5')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}           


else if(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t4']) && !empty($_POST['t4'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	 
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t3,t4) values('$did','$doname','$dofield','$date','$days','$t1','$t2','$t3','$t4')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}         

 elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t3']) && !empty($_POST['t3'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t3) values('$did','$doname','$dofield','$date','$days','$t1','$t2','$t3')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t3']) && !empty($_POST['t3'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t3) values('$did','$doname','$dofield','$date','$days','$t1','$t2','$t3')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}        
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t4']) && !empty($_POST['t4'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t4) values('$did','$doname','$dofield','$date','$days','$t1','$t2','$t4')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}        
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t5']) && !empty($_POST['t5'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t5) values('$did','$doname','$dofield','$date','$days','$t1','$t2','$t5')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2,t6) values('$did','$doname','$dofield','$date','$days','$t1','$t2','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}           
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t4']) && !empty($_POST['t4'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t3,t4) values('$did','$doname','$dofield','$date','$days','$t1','$t3','$t4')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}    
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t5']) && !empty($_POST['t5'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t3,t5) values('$did','$doname','$dofield','$date','$days','$t1','$t3','$t5')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}               
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t3,t6) values('$did','$doname','$dofield','$date','$days','$t1','$t3','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}                  
 elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t2']) && !empty($_POST['t2'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	 
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t2) values('$did','$doname','$dofield','$date','$days','$t1','$t2')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t3']) && !empty($_POST['t3'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t3) values('$did','$doname','$dofield','$date','$days','$t1','$t3')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t4']) && !empty($_POST['t4'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t4) values('$did','$doname','$dofield','$date','$days','$t1','$t4')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t5']) && !empty($_POST['t5'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t5) values('$did','$doname','$dofield','$date','$days','$t1','$t5')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1,t6) values('$did','$doname','$dofield','$date','$days','$t1','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t3']) && !empty($_POST['t3'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t2,t3) values('$did','$doname','$dofield','$date','$days','$t2','$t3')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t4']) && !empty($_POST['t4'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t2,t4) values('$did','$doname','$dofield','$date','$days','$t2','$t4')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t5']) && !empty($_POST['t5'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t2,t5) values('$did','$doname','$dofield','$date','$days','$t2','$t5')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}   
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t2']) && !empty($_POST['t2'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t2,t6) values('$did','$doname','$dofield','$date','$days','$t2','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}       
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t4']) && !empty($_POST['t4'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t3,t4) values('$did','$doname','$dofield','$date','$days','$t3','$t4')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}   
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t5']) && !empty($_POST['t5'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t3,t5) values('$did','$doname','$dofield','$date','$days','$t3','$t5')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}        
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t3']) && !empty($_POST['t3'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t3,t6) values('$did','$doname','$dofield','$date','$days','$t3','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}          
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t4']) && !empty($_POST['t4'])AND isset($_POST['t5']) && !empty($_POST['t5'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t4,t5) values('$did','$doname','$dofield','$date','$days','$t4','$t5')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}          
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t4']) && !empty($_POST['t4'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t4,t6) values('$did','$doname','$dofield','$date','$days','$t4','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}          
elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t5']) && !empty($_POST['t5'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t5,t6) values('$did','$doname','$dofield','$date','$days','$t5','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}          
   elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t1']) && !empty($_POST['t1'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t1 = mysql_escape_string($_POST['t1']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t1) values('$did','$doname','$dofield','$date','$days','$t1')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     

 
 elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t2']) && !empty($_POST['t2'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t2 = mysql_escape_string($_POST['t2']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t2) values('$did','$doname','$dofield','$date','$days','$t2')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}   
 elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t3']) && !empty($_POST['t3'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t3 = mysql_escape_string($_POST['t3']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t3) values('$did','$doname','$dofield','$date','$days','$t3')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}   
 elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t4']) && !empty($_POST['t4'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t4 = mysql_escape_string($_POST['t4']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t4) values('$did','$doname','$dofield','$date','$days','$t4')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}         
 elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t5']) && !empty($_POST['t5'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t5 = mysql_escape_string($_POST['t5']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t5) values('$did','$doname','$dofield','$date','$days','$t5')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
 elseif(isset($_POST['did']) && !empty($_POST['did'])AND($_POST['dname']) && !empty($_POST['dname'])AND isset($_POST['dfield']) && !empty($_POST['dfield'])AND isset($_POST['days']) && !empty($_POST['days'])AND isset($_POST['t6']) && !empty($_POST['t6'])){
	    $did = mysql_escape_string($_POST['did']); // Turn our post into a local variable
	    //$month = mysql_escape_string($_POST['month']); // Turn our post into a local variable
	  $doname = mysql_escape_string($_POST['dname']); // Turn our post into a local variable
	  $dofield = mysql_escape_string($_POST['dfield']); // Turn our post into a local variable
	 $days = mysql_escape_string($_POST['days']); // Turn our post into a local variable
	  $t6 = mysql_escape_string($_POST['t6']); // Turn our post into a local variable
	  
	 $date=date('d-m-y');
	  mysql_query("insert into amc_setslots(d_id,d_name,d_field,d_date,days,t6) values('$did','$doname','$dofield','$date','$days','$t6')",$con);
//echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('SLOT SET SUCCESSFULLY!');</script>";
 
//echo "Successfully Submitted";
}     
 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Appointment</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<script language="JavaScript">
	function selectAll(source) {
		checkboxes = document.getElementsByClassName("name");
		for(var i in checkboxes)
			checkboxes[i].checked = source.checked;
	}
</script>
</head>
<body>

<div id="main_container">

	<div id="header">
    	<div class="logo"><span style="color:#FFF; font-size:24px; color:#000;">AUTO-MEDICURE</span>
        <a href="logout.php" style="color:#000; text-decoration:none;float:right;">LOGOUT</a>
        
        <span style="color:#000; font-weight:bold;float:right;margin-right:2px;margin-left:2px;">|</span>
        <a href="" style="color:#000; text-decoration:none;float:right;">WELCOME <?php echo $unameQ;?></a>
        </div> 
              
    </div>
        <div class="menu" style="float:right;">
        	
        </div>
        
    <div class="center_content">
    
     	<?php include('sidebar.php');?> 
         <?php  
	 
	 $q=mysql_query("select * from amc_doctor  where dr_id='$u_id'",$con);
	 while($q_data=mysql_fetch_array($q))
	 {
		 $dname =$q_data['dr_name'];
		  $dfield =$q_data['dr_field'];
		 
	 }
	  ?>     
        <div class="analyst_right" style="height:auto; margin-top:30px;">
        
         <div style="width:460px; height:auto; margin-left:100px;">
         <form method="post" action="">
          <input type="hidden" name="did" value="<?php echo $u_id; ?>" />
         <input type="hidden" name="dname" value="<?php echo $dname; ?>" />
         <input type="hidden" name="dfield" value="<?php echo $dfield; ?>" />
        <!-- <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Month</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px; margin-left:4px;"><select name="month"><option selected="selected">Select Month</option><option value="Jan">January</option><option value="Feb">Feburary</option><option value="Mar">March</option><option value="Apr">April</option><option value="May">May</option></select></div>
          </div>
         <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Date</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="date"><option selected="selected">Select Date</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></div>
          </div>
          <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Time</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="tme"><option selected="selected">Select Time</option><option value="6:15 PM">6:15 PM</option><option value="6:30 PM">6:30 PM</option><option value="6:45 PM">6:45 PM</option><option value="7:00 PM">7:00 PM</option></select></div>
          </div>-->
          <div style="width:460px; height:40px;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Days</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><select name="days"><option selected="selected">Select Day</option><option value="Monday">Monday</option><option value="Tuesday" id="monday">Tuesday</option><option value="Wensday">Wensday</option><option value="Thursday">Thursday</option><option value="Friday">Friday</option><option value="Saturday">Saturday</option><option value="Sunday">Sunday</option></select></div>
          </div>
          <div style="width:460px; height: auto;">
         <div style="width:110px; float:left; text-align:right; padding-right:10px; margin-top:10px;">Time</div>
          <div style="width:115px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" id="selectall" onClick="selectAll(this)"/> SELECT ALL</div>
          <div style="width:460px; height:auto; float:left;">
         <div style="width:100px; float:left; text-align:right; padding-right:10px; margin-top:10px;">6:30-7:00 PM</div>
          <div style="width:20px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" name="t1" class="name" value="6:30-7:00 PM"/></div>
           <div style="width:100px; float:left; text-align:right; padding-right:10px; margin-top:10px;">7:00-7:30 PM</div>
          <div style="width:20px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" name="t2" class="name" value="7:00-7:30 PM" /></div>
           <div style="width:100px; float:left; text-align:right; padding-right:10px; margin-top:10px;">8:30-9:00 PM</div>
          <div style="width:20px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" name="t3" class="name" value="8:30-9:00 PM" /></div>
          <div style="width:100px; float:left; text-align:right; padding-right:10px; margin-top:10px;">9:30-10:00 PM</div>
          <div style="width:20px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" name="t4" class="name" value="9:30-10:00 PM" /></div>
          <div style="width:100px; float:left; text-align:right; padding-right:10px; margin-top:10px;">10:30-11:00 PM</div>
          <div style="width:20px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" name="t5" class="name" value="10:30-11:00 PM" /></div>
          <div style="width:100px; float:left; text-align:right; padding-right:10px; margin-top:10px;">11:00-11:30 PM</div>
          <div style="width:20px; float:left; text-align:center;margin-top:7px;"><input type="checkbox" name="t6" class="name" value="11:00-11:30 PM" /></div>
          </div>
          </div>
          
       
          <div style="width:460px; height:40px; margin-top:5px; float:left;">
          <div style="width:80px;text-align:center;margin-top:7px; margin-left:130px; float:left;"><input type="submit" name="name" value="Save" style="background-color:#36F;width:80px; color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#36F; cursor:pointer;"/></div>
          
          </div>
         </form>
         </div>
        
        </div> 
          
        <div class="clear"></div> 
    
    </div>    

    
    <div id="footer">                                              
        
        
        <div class="right_footer" style="color:#000;">Cpyright Auto-Medicure
        </div>  
    
    </div>
    
    
    
</div>
<!-- end of main_container -->

</body>
</html>