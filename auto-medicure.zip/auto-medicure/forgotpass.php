<?php
include("config.php");
$emailaddress=''; $password=''; $cname=''; $from1='';

   if(isset($_POST['user_email']) && !empty($_POST['user_email'])){
    $email = mysql_escape_string($_POST['user_email']); // Turn our post into a local variable
	
	$qq=mysql_query("select * from amc_user where user_email='$email'",$con);
while($qq_data = mysql_fetch_array($qq))
{
	$cname=$qq_data['user_name'];
	$password=$qq_data['user_password'];
	$emailaddress=$qq_data['user_address'];
}

$to=$emailaddress;

$from1 == 'admin@automedicure.com';

$subject='Thanks for Contacting!';
$detail='Your Username: $cname , 
Your Password: $password
';
$txt = 'Auto-Medicure';	
//}
/*
if($from1 == 'support@thecabux.com')
{
$txt = 'TheCaBux Support';		
}
*/


//$to = $data['email_address'];
				
$headers = "From: $txt <$from1>";
$subject = "$subject";
$message = "$detail";

$send2 = mail($to, $subject, $message, $headers);	
if($emailaddress == true)
{
	//echo 'email sent';
	echo "<script>alert('EMAIL SENT ON YOUR EMAIL ADDRESS PLEASE CHECK YOUR EMAIL!');</script>";
}
else
{
	//echo 'email Not sent';
	echo "<script>alert('EMAIL NOT SENT PLEASE TRY AGAIN!');</script>";
}

	

   }
?>
<html>
<head>
<title>Forgotpassword | Auto-Medicure</title>
<style type="text/css">
h3{font-family: Calibri; font-size: 22pt; font-style: normal; font-weight: bold; color:#06F;
text-align: center; text-decoration: underline }
table{font-family: Calibri; color:white; font-size: 11pt; font-style: normal;
text-align:; background-color:#3391E7; border-collapse: collapse; border: 2px solid #3391E7;}
table.inner{border: 0px}
</style>
</head>
<body>
<h3>FOR GOT PASSWORD</h3>
<form action="" method="POST">
 
<table align="center" cellpadding = "10">
<!----- Last Name ---------------------------------------------------------->
<tr>
<td>E-MAIL</td>
<td><input type="text" name="user_email" maxlength="30"/>
</td>
</tr>
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" value="Send">
</td>
</tr>
</table>
 
</form>
 
</body>
</html>