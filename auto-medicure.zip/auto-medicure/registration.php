<?php
include("config.php");
$user_name=''; $user_cnicno='';  $user_age=''; $user_email='';$user_cellno='';$user_gender='';$user_address='';$user_city='';$user_pincode='';$user_state='';$user_country='';$user_password=''; $uname='';$uemail='';

   if(isset($_POST['user_name']) && !empty($_POST['user_name']) AND isset($_POST['user_cnicno']) && !empty($_POST['user_cnicno']) AND isset(  $_POST['user_age']) && !empty($_POST['user_age'])AND isset($_POST['user_email']) && !empty($_POST['user_email'])AND isset($_POST['user_cellno']) && !empty($_POST['user_cellno'])AND isset($_POST['user_gender']) && !empty($_POST['user_gender'])AND isset($_POST['user_address']) && !empty($_POST['user_address'])AND isset($_POST['user_city']) && !empty($_POST['user_city'])AND isset($_POST['user_pincode']) && !empty($_POST['user_pincode'])AND isset($_POST['user_state']) && !empty($_POST['user_state'])AND isset($_POST['user_country']) && !empty($_POST['user_country'])AND isset($_POST['user_password']) && !empty($_POST['user_password'])){
    $user_name = $_POST['user_name'];
    $user_cnicno = $_POST['user_cnicno'];
	$user_age = $_POST['user_age'];
	$user_email = $_POST['user_email'];
	$user_cellno =$_POST['user_cellno'];
	$user_gender = $_POST['user_gender'];
	$user_address = $_POST['user_address'];
	$user_city = $_POST['user_city'];
	$user_pincode = $_POST['user_pincode'];
	$user_state = $_POST['user_state'];
	$user_country = $_POST['user_country'];
	$user_password = $_POST['user_password'];
	echo $user_name;
	echo $user_cnicno;
	$date=date('d-m-Y');
	$ucnic='';
	//exit();
	     $qq1=mysql_query("select * from amc_user where user_cnicno='$user_cnicno'",$con);
	 while($qq1_data=mysql_fetch_array($qq1))
	 {
		 $ucnic=$qq1_data['user_cnicno'];	
	 }
	  if($user_cnicno == $ucnic)
	       {
		   echo "<script>alert('User CNIC NO is Already exit.Please Try Again!');</script>";
		   //echo "Company Name is Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   //echo "<meta http-equiv=\"refresh\" content=\"0;URL=register.php\">";
		    exit();
			 }
	    $qq11=mysql_query("select * from amc_user where user_email='$user_email'",$con);
	 while($qq11_data=mysql_fetch_array($qq11))
	 {
		 
		
		$uemail=$qq11_data['user_email'];
		
	 }
	    if($user_email == $uemail)
	   {
		    echo "<script>alert('Email Address Already exit.Please Try Again!');</script>";
		   //echo "Email Address Already exit.Please Try Again.<a href='register.php'>Click Here</a>";
		   //echo "<meta http-equiv=\"refresh\" content=\"0;URL=register.php\">";
		     exit();
			 }
	   
	  // mysql_query("insert into amc_user(user_name,user_cnicno,user_session_id) values ('$user_name','$user_cnicno','$ses_id')",$con);
	  mysql_query("insert into amc_user(user_name,user_cnicno,user_age,user_email,user_cellno,user_gender,user_address,user_city,user_pincode,user_state,user_country,user_password,user_session_id,u_date) values ('$user_name','$user_cnicno','$user_age','$user_email','$user_cellno','$user_gender','$user_address','$user_city','$user_pincode','$user_state','$user_country','$user_password','$ses_id','$date')",$con);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=login.php\">";
echo "<script>alert('Waiting For Approval!');</script>";
 
//echo "Successfully Submitted";
}           
?>
<html>
<head>
<title>Registration | Auto-Medicure</title>
<style type="text/css">
h3{font-family: Calibri; font-size: 22pt; font-style: normal; font-weight: bold; color:#06F;
text-align: center; text-decoration: underline }
table{font-family: Calibri; color:white; font-size: 11pt; font-style: normal;
text-align:; background-color:#3391E7; border-collapse: collapse; border: 2px solid #3391E7;}
table.inner{border: 0px}
</style>
<SCRIPT language=JavaScript>
<!--

//Accept terms & conditions script (by InsightEye www.insighteye.com)
//Visit JavaScript Kit (http://javascriptkit.com) for this script & more.


function checkCheckBox(f){


if (f.agree.checked == false )
{
alert('Please check the box to continue.');
return false;
}else
return true;

}
//-->
</SCRIPT>
</head>
<body>
<h3>USER REGISTRATION FORM</h3>
<form action="" method="POST" onSubmit="return checkCheckBox(this)">
 
<table align="center" cellpadding = "10">
 
<!----- First Name ---------------------------------------------------------->
<tr>
<td>NAME</td>
<td><input type="text" name="user_name" maxlength="30"/>
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Last Name ---------------------------------------------------------->
<tr>
<td>CNIC NO</td>
<td><input type="text" name="user_cnicno" maxlength="30"/>
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Date Of Birth -------------------------------------------------------->
<tr>
<td>DOB</td>
 
<td><input type="date" name="user_age" maxlength="30" formnovalidate/>
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Email Id ---------------------------------------------------------->
<tr>
<td>EMAIL ID</td>
<td><input type="text" name="user_email" maxlength="100" /></td>
</tr>
 
<!----- Mobile Number ---------------------------------------------------------->
<tr>
<td>MOBILE NUMBER</td>
<td>
<input type="text" name="user_cellno" maxlength="10" />
(10 digit number)
</td>
</tr>
 
<!----- Gender ----------------------------------------------------------->
<tr>
<td>GENDER</td>
<td>
Male <input type="radio" name="user_gender" value="M" />
Female <input type="radio" name="user_gender" value="F" />
</td>
</tr>
 
<!----- Address ---------------------------------------------------------->
<tr>
<td>ADDRESS <br /><br /><br /></td>
<td><textarea name="user_address" rows="4" cols="30"></textarea></td>
</tr>
 
<!----- City ---------------------------------------------------------->
<tr>
<td>CITY</td>
<td><input type="text" name="user_city" maxlength="30" />
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Zip Code ---------------------------------------------------------->
<tr>
<td>ZIP CODE</td>
<td><input type="text" name="user_pincode" maxlength="6" />
(6 digit number)
</td>
</tr>
 
<!----- State ---------------------------------------------------------->
<tr>
<td>STATE</td>
<td><input type="text" name="user_state" maxlength="30" />
(max 30 characters a-z and A-Z)
</td>
</tr>
 
<!----- Country ---------------------------------------------------------->
<tr>
<td>COUNTRY</td>
<td><input type="text" name="user_country"/></td>
</tr>
<!----- Password ---------------------------------------------------------->
<tr>
<td>PASSWORD</td>
<td><input type="password" name="user_password" maxlength="15" />
(max 15 characters a-z and A-Z)
</td>
</tr>
<!----- Terms and conditions ---------------------------------------------------------->
<tr>

<tr>
<td>I agree with all </td>
<td> terms and conditions of registration and satisfied to be registered</td>

</tr>
</tr>
<tr>
<td></td>
<td><input type="checkbox" name="agree" />
Terms and Conditions
</td>
</tr>
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" value="REGISTER" style="background-color:#3391E7;width:85px; text-align:center;color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#3391E7; cursor:pointer;">
<input type="button" value="CANCEL" style="background-color:#3391E7;width:80px;  color:#FFF; height:25px; border-radius:5px 5px 5px 5px; border-color:#3391E7; cursor:pointer; text-align:center;">
</td>
</tr>
</table>
 
</form>
 
</body>
</html>