-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2017 at 05:50 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `automedicare`
--

-- --------------------------------------------------------

--
-- Table structure for table `amc_addmembers`
--

CREATE TABLE IF NOT EXISTS `amc_addmembers` (
  `m_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `member_name` varchar(20) NOT NULL,
  `member_age` varchar(30) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `amc_addmembers`
--

INSERT INTO `amc_addmembers` (`m_id`, `user_id`, `member_name`, `member_age`, `date`) VALUES
(1, 5, 'Aslam', '1984-10-02', ''),
(2, 5, 'Ashan', '1984-10-02', ''),
(3, 5, 'Akram', '1984-10-02', ''),
(4, 5, 'Naveed', '1984-10-02', ''),
(5, 2, 'Asad', '1984-10-02', ''),
(6, 2, 'Junaid', '1984-10-02', ''),
(7, 2, 'Faryal', '1984-10-02', ''),
(8, 2, 'Babar', '1984-10-02', ''),
(9, 2, 'Saba', '1984-10-02', ''),
(11, 6, 'Mujeed', '1984-10-02', '13-05-2017'),
(12, 5, 'Aslam', '1984-10-02', ''),
(13, 5, 'Ashan', '1984-10-02', ''),
(14, 5, 'Akram', '1984-10-02', ''),
(15, 4, 'sara', '1984-10-02', ''),
(16, 4, 'haleema', '1984-10-02', ''),
(18, 6, 'Akbar', '1970-10-02', ' 13-05-2017'),
(19, 6, 'Aslam', '1984-10-02', ' 13-05-2017'),
(21, 5, 'khafsa', '21', '29-05-2017'),
(22, 6, 'Hafsa Abrar', '1996-07-01', ' 29-05-2017'),
(23, 3, 'Aslam', '2010-02-10', '26-07-2017'),
(24, 4, 'faryal', '2004-06-15', '20-08-2017'),
(25, 6, 'sadiha', '2008-02-28', '20-08-2017'),
(26, 5, 'arooj', '2006-07-13', '20-08-2017'),
(27, 3, 'tabinda', '2001-02-06', '20-08-2017'),
(28, 2, 'ayesha', '2008-02-12', '20-08-2017'),
(29, 7, 'anum', '1999-05-08', '29-08-2017'),
(30, 7, 'sadaf', '1992-08-08', '29-08-2017');

-- --------------------------------------------------------

--
-- Table structure for table `amc_administration`
--

CREATE TABLE IF NOT EXISTS `amc_administration` (
  `administrator_id` int(10) NOT NULL AUTO_INCREMENT,
  `adm_name` varchar(15) NOT NULL,
  `adm_cnicno` varchar(20) NOT NULL,
  `adm_password` varchar(15) NOT NULL,
  `session_id` varchar(200) NOT NULL,
  PRIMARY KEY (`administrator_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `amc_administration`
--

INSERT INTO `amc_administration` (`administrator_id`, `adm_name`, `adm_cnicno`, `adm_password`, `session_id`) VALUES
(1, 'Administrator', '33105-2853377-1', 'aa', '0');

-- --------------------------------------------------------

--
-- Table structure for table `amc_appointmentc`
--

CREATE TABLE IF NOT EXISTS `amc_appointmentc` (
  `a_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `dr_name` varchar(20) NOT NULL,
  `d_id` int(10) NOT NULL,
  `d_date` varchar(20) NOT NULL,
  `d_time` varchar(20) NOT NULL,
  `app_status` int(10) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `amc_appointmentc`
--

INSERT INTO `amc_appointmentc` (`a_id`, `user_id`, `user_name`, `dr_name`, `d_id`, `d_date`, `d_time`, `app_status`) VALUES
(1, 0, 'sajid', 'Naomi', 1, '14-03-17', '6:15 PM', 0),
(2, 0, 'sajid', 'Naomi', 1, '14-03-17', '6:30 PM', 0),
(3, 0, 'sajid', 'Naomi', 1, '14-03-17', '6:30 PM', 0),
(4, 0, 'sajid', 'Naomi', 1, '14-03-17', '6:30 PM', 0),
(5, 0, 'sajid', 'Naomi', 1, '14-03-17', '6:30 PM', 0),
(6, 0, 'sajid', 'Naomi', 1, '14-03-17', '6:30 PM', 0),
(7, 0, 'sajid', 'Naomi', 1, '14-03-17', '6:15 PM', 0),
(8, 0, 'sajid', 'Hafza', 4, '14-03-17', '6:45 PM', 0),
(9, 0, 'sajid', 'Gulnar', 6, '14-03-17', '6:30 PM', 0),
(10, 0, 'sajid', 'Gulnar', 6, '14-03-17', '7:00 PM', 0),
(11, 0, 'sajid', 'Gulnar', 6, '14-03-17', '6:45 PM', 0),
(12, 0, 'sajid', 'haji', 0, '14-03-17', '6:45 PM', 0),
(13, 0, 'sajid', 'haji', 0, '14-03-17', '6:30 PM', 0),
(14, 0, 'sajid', 'Gulnar', 6, '14-03-17', '6:30 PM', 0),
(15, 0, 'sajid', 'Hafza', 4, '14-03-17', '6:45 PM', 0),
(16, 0, 'sajid', 'Hafza', 4, '14-03-17', '6:15 PM', 0),
(17, 0, 'sajid', 'Gulnar', 6, '14-03-17', '6:45 PM', 0),
(18, 5, 'sajid', 'Gulnar', 6, '14-03-17', '6:45 PM', 1),
(19, 5, 'sajid', 'Gulnar', 6, '14-03-17', '7:00 PM', 1),
(20, 5, 'sajid', 'Gulnar', 6, '14-03-17', '6:15 PM', 1),
(21, 5, 'sajid', 'Gulnar', 6, '14-03-17', '6:15 PM', 1),
(22, 5, 'sajid', 'Gulnar', 6, '14-03-17', '6:15 PM', 1),
(23, 5, 'sajid', 'Hafza', 4, '14-03-17', '6:45 PM', 1),
(24, 5, 'sajid', 'Hafza', 4, '14-03-17', '6:45 PM', 1),
(25, 5, 'sajid', 'Hafza', 4, '14-03-17', '6:30 PM', 1),
(26, 5, 'sajid', 'Hafza', 4, '14-03-17', '6:45 PM', 1),
(27, 5, 'sajid', 'Gulnar', 6, '14-03-17', '6:15 PM', 1),
(28, 5, 'sajid', 'Hafza', 4, '14-03-17', '6:30 PM', 1),
(29, 5, 'sajid', 'Gulnar', 6, '14-03-17', '6:45 PM', 1),
(30, 5, 'sajid', 'Gulnar', 6, '14-03-17', '6:30 PM', 1),
(31, 5, 'sajid', 'Hafza', 4, '14-03-17', '6:45 PM', 1),
(32, 6, 'GHANI', 'Hafza', 4, '14-03-17', '6:15 PM', 1),
(33, 6, 'GHANI', 'Naomi', 1, '21-03-17', '6:30 PM', 1),
(34, 6, 'GHANI', 'Naomi', 1, '21-03-17', '6:45 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `amc_category_image`
--

CREATE TABLE IF NOT EXISTS `amc_category_image` (
  `cimgid` int(10) NOT NULL AUTO_INCREMENT,
  `image_id` int(10) NOT NULL,
  `image_path` varchar(200) NOT NULL,
  `symptoms` varchar(200) NOT NULL,
  PRIMARY KEY (`cimgid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `amc_category_image`
--

INSERT INTO `amc_category_image` (`cimgid`, `image_id`, `image_path`, `symptoms`) VALUES
(1, 1, 'images_category/headache1.jpg', 'headic'),
(2, 1, 'images_category/headache2.jpg', 'pain arm'),
(3, 1, 'images_category/headache3.jpg', 'pain arm'),
(4, 1, 'images_category/headache4.jpg', 'pain arm'),
(5, 1, 'images_category/headace5.jpg', 'pain arm'),
(6, 2, 'images_category/eye1.jpg', 'left eye pain'),
(7, 2, 'images_category/eye2.jpg', 'right eye pain'),
(8, 2, 'images_category/eye3.jpg', 'bottom eye pain'),
(9, 2, 'images_category/eye4.jpg', 'upper side pain on eye'),
(10, 2, 'images_category/eye1.jpg', 'main eye');

-- --------------------------------------------------------

--
-- Table structure for table `amc_contact`
--

CREATE TABLE IF NOT EXISTS `amc_contact` (
  `c_id` int(10) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(20) NOT NULL,
  `c_email` varchar(25) NOT NULL,
  `c_subject` varchar(40) NOT NULL,
  `c_message` text NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `amc_contact`
--

INSERT INTO `amc_contact` (`c_id`, `c_name`, `c_email`, `c_subject`, `c_message`, `date`) VALUES
(1, 'imran', 'usmanabid900@yahoo.com', 'doctor', ' kkkjkkjj', ''),
(2, 'usman', 'usman90@gmail.com', 'doctor', ' mkkk', '12-05-2017'),
(3, 'usman', 'usman90@gmail.com', 'doctor', ' lll', '12-05-2017'),
(4, 'usman', 'usman90@gmail.com', 'doctor', ' jkjkkj', '12-05-2017');

-- --------------------------------------------------------

--
-- Table structure for table `amc_doctor`
--

CREATE TABLE IF NOT EXISTS `amc_doctor` (
  `dr_id` int(10) NOT NULL AUTO_INCREMENT,
  `dr_name` varchar(25) NOT NULL,
  `dr_cnicno` varchar(25) NOT NULL,
  `dr_email` varchar(25) NOT NULL,
  `dr_cellno` varchar(25) NOT NULL,
  `dr_gender` varchar(15) NOT NULL,
  `dr_address` text NOT NULL,
  `dr_city` varchar(25) NOT NULL,
  `dr_degree` varchar(30) NOT NULL,
  `dr_field` varchar(30) NOT NULL,
  `dr_pmdcno` varchar(30) NOT NULL,
  `image_upload` text NOT NULL,
  `dr_password` varchar(25) NOT NULL,
  `dr_session_id` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  `doc_date` varchar(40) NOT NULL,
  `rating` int(10) NOT NULL,
  PRIMARY KEY (`dr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `amc_doctor`
--

INSERT INTO `amc_doctor` (`dr_id`, `dr_name`, `dr_cnicno`, `dr_email`, `dr_cellno`, `dr_gender`, `dr_address`, `dr_city`, `dr_degree`, `dr_field`, `dr_pmdcno`, `image_upload`, `dr_password`, `dr_session_id`, `status`, `doc_date`, `rating`) VALUES
(2, 'sajid', '33105-2855334-8', 'usmanabid9000@yahoo.com', '3353438549', 'Male', 'Balochistan', 'Amritsar', 'doctor', 'eye special list', '9402', 'llsld', 'kkdk', '0', 1, '', 0),
(3, 'usman', '33105-2855334-7', 'hafsa@gmail.com', '0432449443', 'Male', 'islamabad', 'Delvine', 'mbbs', 'skin', '94023', '', 'kkdk', '0', 2, '', 0),
(4, 'Hafza', '33105-2855334-81', 'usmanabid9100@yahoo.com', '3316393241', 'Male', 'Karachi', 'Aboutabad', 'mbbs', 'skin', '94031', '', 'll', '0', 1, '', 0),
(5, 'anwar', '33105-2844334-9', 'usmanabid9440@yahoo.com', '3353433346', 'Male', 'Balochistan', 'Amritsar', 'mbbs', 'doctor of heart', '940233', '', 'kdk', '0', 2, '', 0),
(6, 'Gulnar', '33105-2855330-0', 'usmanabid902340@yahoo.com', '3353400546', 'Male', 'Balochistan', 'Amritsar', 'mmbss', 'heart', '94000', 'image/id card0002.jpg', 'mmmm', '0', 1, '', 0),
(7, 'Ali', '33105-2855330-8', 'ali_khan@hotmail.com', '3546289222', 'Male', 'adayala road', 'Rawalpindi', 'image/cisco.png', 'brain', '8356', 'image/cisco.png', 'ali', '0', 1, '29-08-2017', 0);

-- --------------------------------------------------------

--
-- Table structure for table `amc_main_image`
--

CREATE TABLE IF NOT EXISTS `amc_main_image` (
  `imgid` int(10) NOT NULL AUTO_INCREMENT,
  `img_type` varchar(100) NOT NULL,
  `imge_name` varchar(200) NOT NULL,
  PRIMARY KEY (`imgid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `amc_main_image`
--

INSERT INTO `amc_main_image` (`imgid`, `img_type`, `imge_name`) VALUES
(1, 'HEADIC', 'images/headic.jpg'),
(2, 'EYE', 'images/eye.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `amc_medicines`
--

CREATE TABLE IF NOT EXISTS `amc_medicines` (
  `med_id` int(10) NOT NULL AUTO_INCREMENT,
  `med_type` varchar(100) NOT NULL,
  `med_name` varchar(255) NOT NULL,
  `rating` int(10) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`med_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `amc_medicines`
--

INSERT INTO `amc_medicines` (`med_id`, `med_type`, `med_name`, `rating`, `date`) VALUES
(2, 'skin', 'Acetazolamide', 0, ''),
(3, 'Skin', 'Alclometasone ', 0, ''),
(4, 'bones', 'Calcitonin', 0, ''),
(5, 'heart', 'Acebutolol ', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `amc_othermedicine`
--

CREATE TABLE IF NOT EXISTS `amc_othermedicine` (
  `other_id` int(10) NOT NULL AUTO_INCREMENT,
  `doc_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `member_id` int(10) NOT NULL,
  `medicine_name` varchar(200) NOT NULL,
  `symptoms` text NOT NULL,
  `age` varchar(30) NOT NULL,
  `time_m` varchar(10) NOT NULL,
  `time_a` varchar(10) NOT NULL,
  `time_e` varchar(10) NOT NULL,
  `time_n` varchar(10) NOT NULL,
  `total_days` varchar(10) NOT NULL,
  `m_date` varchar(40) NOT NULL,
  `rating` int(10) NOT NULL,
  PRIMARY KEY (`other_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `amc_othermedicine`
--

INSERT INTO `amc_othermedicine` (`other_id`, `doc_id`, `user_id`, `member_id`, `medicine_name`, `symptoms`, `age`, `time_m`, `time_a`, `time_e`, `time_n`, `total_days`, `m_date`, `rating`) VALUES
(1, 6, 2, 7, 'desprine', 'pain headic', '1984-10-02', 'M', 'A', 'E', 'N', '4', '27-05-2017', 0),
(4, 6, 2, 8, 'col', 'pain leg', '32years , 7months , 27days', 'M', 'A', 'E', 'N', '2', '27-05-2017', 0);

-- --------------------------------------------------------

--
-- Table structure for table `amc_pharmacy`
--

CREATE TABLE IF NOT EXISTS `amc_pharmacy` (
  `phar_id` int(10) NOT NULL AUTO_INCREMENT,
  `med_id` int(10) NOT NULL,
  `pharmacy_id` int(10) NOT NULL,
  `branch_id` int(10) NOT NULL,
  `address` text NOT NULL,
  `price` varchar(50) NOT NULL,
  `availability` varchar(30) NOT NULL,
  `cell_no` varchar(50) NOT NULL,
  `timing` varchar(70) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`phar_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `amc_pharmacy`
--

INSERT INTO `amc_pharmacy` (`phar_id`, `med_id`, `pharmacy_id`, `branch_id`, `address`, `price`, `availability`, `cell_no`, `timing`, `date`) VALUES
(1, 2, 1, 3, 'Super Market Amar Pak Plaza,next to kidney center,grand trunk road(gt road) ', '1200rs', 'YES', '0515701144', '1:00am', ''),
(2, 2, 3, 2, 'Balochistan ', '1200Rs', 'YES', '+923353438546', '23:59', ''),
(3, 2, 3, 2, 'Karachi ', '22 Rs', 'NO', '03316393246', '2:13 PM', '01-05-2017'),
(4, 3, 3, 3, 'islamabad ', '1200rs', 'YES', '03316393246', '2:13 PM', '27-05-2017'),
(5, 3, 3, 3, 'islamabad ', '1200rs', 'YES', '03316393246', '2:13 PM', '27-05-2017'),
(6, 5, 1, 2, 'Rawalpindi', '200 Rs', 'YES', '03316393246', '2:13 PM', '10-06-2017');

-- --------------------------------------------------------

--
-- Table structure for table `amc_pharmacy_branch`
--

CREATE TABLE IF NOT EXISTS `amc_pharmacy_branch` (
  `branch_id` int(10) NOT NULL AUTO_INCREMENT,
  `pharmacy_id` int(10) NOT NULL,
  `branch_name` varchar(200) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `amc_pharmacy_branch`
--

INSERT INTO `amc_pharmacy_branch` (`branch_id`, `pharmacy_id`, `branch_name`, `date`) VALUES
(2, 1, 'Peshawar Road', ''),
(3, 3, 'Morgah branchg', ''),
(4, 4, 'sadar branch', '17-05-2017'),
(5, 4, 'Adyala branch', '17-05-2017'),
(6, 1, 'Newlalazar branch', '17-05-2017');

-- --------------------------------------------------------

--
-- Table structure for table `amc_pharmacy_name`
--

CREATE TABLE IF NOT EXISTS `amc_pharmacy_name` (
  `pharmacy_id` int(10) NOT NULL AUTO_INCREMENT,
  `pharmacy_name` varchar(200) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`pharmacy_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `amc_pharmacy_name`
--

INSERT INTO `amc_pharmacy_name` (`pharmacy_id`, `pharmacy_name`, `date`) VALUES
(1, 'Shaheen Chemist', ''),
(3, 'D Watson Chemist', ''),
(4, 'Abu Zahrr', '');

-- --------------------------------------------------------

--
-- Table structure for table `amc_prescription`
--

CREATE TABLE IF NOT EXISTS `amc_prescription` (
  `pres_id` int(10) NOT NULL AUTO_INCREMENT,
  `doc_id` int(10) NOT NULL,
  `user_id` int(4) NOT NULL,
  `member_id` int(4) NOT NULL,
  `age` varchar(200) NOT NULL,
  `medicines_id` int(10) NOT NULL,
  `symptoms` text NOT NULL,
  `time_m` varchar(20) NOT NULL,
  `time_a` varchar(20) NOT NULL,
  `time_e` varchar(20) NOT NULL,
  `time_n` varchar(20) NOT NULL,
  `total_days` varchar(20) NOT NULL,
  `p_date` varchar(40) NOT NULL,
  PRIMARY KEY (`pres_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `amc_prescription`
--

INSERT INTO `amc_prescription` (`pres_id`, `doc_id`, `user_id`, `member_id`, `age`, `medicines_id`, `symptoms`, `time_m`, `time_a`, `time_e`, `time_n`, `total_days`, `p_date`) VALUES
(1, 6, 2, 5, '32years , 7months , 27days', 2, 'heart', 'M', 'A', 'E', 'N', '9', '27-05-2017'),
(2, 6, 2, 5, '32years , 7months , 27days', 3, 'skin', 'M', 'A', 'E', 'N', '4', '27-05-2017'),
(4, 6, 6, 18, '46years , 7months , 27days', 2, 'skin', 'M', 'A', 'E', 'N', '4', '27-05-2017'),
(5, 7, 7, 29, '17years , 15months , 29days', 2, 'headache', 'M', '', '', 'N', '3', '29-08-2017');

-- --------------------------------------------------------

--
-- Table structure for table `amc_reuest`
--

CREATE TABLE IF NOT EXISTS `amc_reuest` (
  `re_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `doc_id` int(10) NOT NULL,
  `member_id` int(10) NOT NULL,
  `req_date` varchar(30) NOT NULL,
  `days` varchar(30) NOT NULL,
  `timetable` varchar(255) NOT NULL,
  `req_status` int(10) NOT NULL,
  PRIMARY KEY (`re_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `amc_reuest`
--

INSERT INTO `amc_reuest` (`re_id`, `user_id`, `doc_id`, `member_id`, `req_date`, `days`, `timetable`, `req_status`) VALUES
(1, 6, 6, 18, '22-04-17', 'Monday', '6:00-7:00 PM', 1),
(2, 6, 5, 19, '16-04-17', 'Wensday', '10:30-11:00 PM', 0),
(3, 6, 6, 20, '16-04-17', 'Wensday', '6:30-7:00 PM', 2),
(4, 6, 5, 22, '16-04-17', 'Wensday', '10:30-11:00 PM', 0),
(5, 6, 6, 18, '22-04-17', 'Monday', '6:00-7:00 PM', 2),
(6, 3, 5, 23, '16-04-17', 'Wensday', '10:30-11:00 PM', 0),
(7, 4, 5, 16, '16-04-17', 'Wensday', '10:30-11:00 PM', 1),
(8, 4, 6, 15, '16-04-17', 'Wensday', '6:30-7:00 PM', 0),
(9, 4, 5, 24, '16-04-17', 'Wensday', '10:30-11:00 PM', 0),
(10, 4, 6, 24, '16-04-17', 'Wensday', '6:30-7:00 PM', 1),
(11, 2, 5, 5, '16-04-17', 'Wensday', '10:30-11:00 PM', 0),
(12, 7, 7, 29, '29-08-17', 'Monday', '8:00-8:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `amc_setslots`
--

CREATE TABLE IF NOT EXISTS `amc_setslots` (
  `s_id` int(8) NOT NULL AUTO_INCREMENT,
  `d_id` int(10) NOT NULL,
  `d_date` varchar(25) NOT NULL,
  `days` varchar(20) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `amc_setslots`
--

INSERT INTO `amc_setslots` (`s_id`, `d_id`, `d_date`, `days`, `session_id`) VALUES
(1, 6, '16-04-17', 'Friday', '0'),
(2, 6, '16-04-17', 'Wensday', '0'),
(3, 6, '16-04-17', 'Wensday', '0'),
(4, 6, '16-04-17', 'Saturday', '0'),
(5, 6, '16-04-17', 'Thursday', '0'),
(6, 6, '16-04-17', 'Friday', '0'),
(7, 7, '17-04-17', 'Monday', '0'),
(8, 7, '18-04-17', 'Wensday', '0'),
(9, 7, '18-04-17', 'Friday', '0'),
(10, 6, '22-04-17', 'Monday', '0'),
(11, 7, '29-08-17', 'Friday', '0'),
(12, 7, '29-08-17', 'Monday', '0'),
(13, 7, '29-08-17', 'Thursday', '0');

-- --------------------------------------------------------

--
-- Table structure for table `amc_setting_timetable`
--

CREATE TABLE IF NOT EXISTS `amc_setting_timetable` (
  `set_id` int(10) NOT NULL AUTO_INCREMENT,
  `do_id` int(10) NOT NULL,
  `timetable` varchar(255) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `amc_setting_timetable`
--

INSERT INTO `amc_setting_timetable` (`set_id`, `do_id`, `timetable`, `date`) VALUES
(1, 5, '6:30-7:00 PM', ''),
(3, 5, '6:30-8:00 PM', ''),
(4, 6, '7:30-8:00 PM', ''),
(5, 6, '6:00-7:00 PM', ''),
(12, 6, '6:30-7:00 PM', '27-05-2017'),
(13, 7, '8:00-8:30 PM', '29-08-2017'),
(14, 7, '7:30-8:00 PM', '29-08-2017');

-- --------------------------------------------------------

--
-- Table structure for table `amc_timetable`
--

CREATE TABLE IF NOT EXISTS `amc_timetable` (
  `t_id` int(10) NOT NULL AUTO_INCREMENT,
  `detail_id` int(10) NOT NULL,
  `doc_id` int(10) NOT NULL,
  `schedule` varchar(255) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `amc_timetable`
--

INSERT INTO `amc_timetable` (`t_id`, `detail_id`, `doc_id`, `schedule`, `date`) VALUES
(1, 2, 6, '6:30-7:00 PM', ''),
(2, 2, 3, '7:00-7:30 PM', ''),
(3, 2, 2, '8:30-9:00 PM', ''),
(4, 2, 4, '9:30-10:00 PM', ''),
(5, 2, 5, '10:30-11:00 PM', ''),
(6, 2, 6, '11:00-11:30 PM', ''),
(7, 3, 2, '6:30-7:00 PM', ''),
(9, 4, 3, '6:00-7:00 PM', ''),
(10, 4, 4, '7:30-8:00 PM', ''),
(12, 5, 2, '7:30-8:00 PM', ''),
(13, 6, 3, '6:00-7:00 PM', ''),
(14, 4, 2, '6:00-7:00 PM', ''),
(15, 2, 3, '6:00-7:00 PM', ''),
(16, 4, 4, '7:30-8:00 PM', ''),
(17, 3, 3, '6:30-7:00 PM', ''),
(18, 2, 2, '6:00-7:00 PM', ''),
(19, 4, 4, '7:30-8:00 PM', ''),
(20, 9, 4, '6:30-7:00 PM', ''),
(21, 2, 2, '6:00-7:00 PM', ''),
(22, 3, 3, '7:30-8:00 PM', ''),
(23, 5, 3, '6:30-7:00 PM', ''),
(24, 7, 2, '6:00-7:00 PM', ''),
(25, 7, 2, '7:30-8:00 PM', ''),
(26, 7, 4, '6:30-7:00 PM', ''),
(27, 8, 4, '6:00-7:00 PM', ''),
(28, 8, 4, '7:30-8:00 PM', ''),
(29, 8, 5, '6:30-7:00 PM', ''),
(30, 8, 5, '6:30-7:00 PM', ''),
(31, 9, 9, '7:30-8:00 PM', ''),
(32, 10, 6, '6:00-7:00 PM', ''),
(34, 10, 6, '6:00-7:00 PM', ''),
(35, 10, 6, '7:30-8:00 PM', ''),
(38, 13, 7, '8:00-8:30', '29-08-17'),
(39, 13, 7, '7:30-8:00 PM', '29-08-17');

-- --------------------------------------------------------

--
-- Table structure for table `amc_user`
--

CREATE TABLE IF NOT EXISTS `amc_user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(25) NOT NULL,
  `user_cnicno` varchar(25) NOT NULL,
  `user_age` varchar(30) NOT NULL,
  `user_email` varchar(20) NOT NULL,
  `user_cellno` varchar(25) NOT NULL,
  `user_gender` varchar(10) NOT NULL,
  `user_address` text NOT NULL,
  `user_city` varchar(25) NOT NULL,
  `user_pincode` varchar(20) NOT NULL,
  `user_state` varchar(40) NOT NULL,
  `user_country` varchar(30) NOT NULL,
  `user_password` varchar(20) NOT NULL,
  `user_session_id` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  `u_date` varchar(40) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `amc_user`
--

INSERT INTO `amc_user` (`user_id`, `user_name`, `user_cnicno`, `user_age`, `user_email`, `user_cellno`, `user_gender`, `user_address`, `user_city`, `user_pincode`, `user_state`, `user_country`, `user_password`, `user_session_id`, `status`, `u_date`) VALUES
(2, 'ayesha', '33105-2855334-4', '28', 'ayesha@yahoo.com', '3316393246', 'F', 'Balochistan', 'Faisalabad', '563', 'Punjab', 'Pakistan', 'kk', '0', 1, ''),
(3, 'tabinda', '333105-29996677-1', '21', 'tabinda@900gmail.com', '43244944', 'F', 'karachi', 'Rawalpindi', '344', 'Punjab', 'Pakistan', 'kk', '0', 2, ''),
(4, 'faryal', '232-393999-9', '20', 'faryal22@hotmail.com', '3316393246', 'F', 'Karachi', 'Aboutabad', '563', 'Khyber Pakhtunkhwa', 'Pakistan', 'll', '0', 1, ''),
(5, 'arooj', '999-939939-9', '19', 'arooj@gmail.com', '43244944', 'F', 'islamabad', 'Delvine', '344', 'Delvine', 'Albania', 'll', '0', 1, ''),
(6, 'sadiha', '33105-8888888-4', '23', 'sadiha222@yahoo.com', '0331639555', 'F', 'peshwar', 'peshwar', '94', 'Punjab', 'Pakistan', 'll', '0', 1, ''),
(7, 'anum', '333105-2856677-7', '1995-02-03', 'anum_khan@yahoo.com', '3353438546', 'F', 'Balochistan', 'Rawalpindi', '435', 'Punjab', 'Pakistan', 'anum', '0', 1, '29-08-2017');

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE IF NOT EXISTS `area` (
  `area_id` int(10) NOT NULL AUTO_INCREMENT,
  `area_name` varchar(50) NOT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`area_id`, `area_name`) VALUES
(1, 'Dha'),
(2, 'Bahria'),
(3, 'Sadar'),
(4, 'Islamabad');

-- --------------------------------------------------------

--
-- Table structure for table `location_map`
--

CREATE TABLE IF NOT EXISTS `location_map` (
  `map_id` int(10) NOT NULL AUTO_INCREMENT,
  `area_id` int(10) NOT NULL,
  `image_name` varchar(200) NOT NULL,
  PRIMARY KEY (`map_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `location_map`
--

INSERT INTO `location_map` (`map_id`, `area_id`, `image_name`) VALUES
(2, 4, 'image_loc/isb.png'),
(3, 2, 'image_loc/bahria.png'),
(4, 4, 'image_loc/isb.png'),
(5, 1, 'image_loc/sadar.png');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `vote` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`id`, `product_id`, `vote`) VALUES
(1, 2, 3.7),
(2, 3, 3.6),
(3, 3, 3.7),
(4, 4, 2.7),
(5, 6, 4),
(6, 5, 0.7),
(7, 6, 4.8),
(8, 2, 4.5),
(9, 2, 1.4),
(10, 2, 2.6);

-- --------------------------------------------------------

--
-- Table structure for table `rating_medicine`
--

CREATE TABLE IF NOT EXISTS `rating_medicine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `vote` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `rating_medicine`
--

INSERT INTO `rating_medicine` (`id`, `product_id`, `vote`) VALUES
(1, 2, 3.7),
(2, 4, 4.7),
(3, 4, 2.6),
(4, 4, 0.6),
(5, 2, 4.6),
(6, 3, 2.9);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
