<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
$(document).ready(function(){

                $(".inline").colorbox({inline:true,opacity:0.7, fixed:true, innerWidth:1100, innerHeight:550, scrolling:false});

  //array to store checkbox values
            checkValues = new Array();

            document.getElementById('update').onclick = function(){
                        //capture all text in a variable
                        var textStr = $('<ul></ul>');
                        //iterate all checkbox values to create ul
                        $.each(checkValues, function( index, value ){
                              textStr.append('<li>'+value+'</li>');
                        });
                        //add text
                        $("#text").html(textStr);
                        parent.$.colorbox.close();
                        return false;
            };

             //add change handler for checkbox        
           $('input:checkbox[name=complaint]').change(function(){
               value = $(this).val();
               if(this.checked)
                   checkValues.push(value);
               else
               {   //Removing by value
                  checkValues = $.grep(checkValues, function(n, i) { 
                      return n !== value;
                  }); 
               }
          });    

</head>

<body>
<form action="testinsert.php" method="post">
<input type="checkbox" id="selectall" onClick="selectAll(this)" />Monday
<ul>
	<li><input type="checkbox" name="t1" class="name" value="red" />Red</li>
	<li><input type="checkbox" name="t2" class="name" value="blue" />Blue</li>
	<li><input type="checkbox" name="t3" class="name" value="green" />Green</li>
	<li><input type="checkbox" name="t4" class="name" value="black" />Black</li>
    <li><input type="submit" name="send"/></li>
</ul>

</form>
<label class="question-name" ng-class="{error:hasError()}">  <span class="ng-binding" ng-hide="question.nameHiddenOnMobile">Main Complaint </span>  <span class="icon-required" ng-show="question.required"></span>  </label>

<select name="Language.PrimarySpoken" ng-hide="showAddAnswer" ng-model="question.response.value" ng-options="a.text as a.getText() for a in question.answers.items" id="Language.PrimarySpoken" ng-value="a.text" class="input-wide " ng-class="{error:hasError()}" ng-change="selectAnswer()">
   <option class="hidden" disabled="disabled" value=""></option>
        <option value="One">One</option>
        <option value="Two">Two</option>
        <option value="Three">Three</option>
        <option value="Four">Four</option>
        <option value="Five">Five</option> 
        <option value="Six">Six</option> 
        <option value="Seven">Seven</option> 
        <option value="Eight">Eight</option> 
</select>


 <label class="question-name" ng-class="{error:hasError()}">  <span class="ng-binding" ng-hide="question.nameHiddenOnMobile">Additional Complaint </span>  <span class="icon-required" ng-show="question.required"></span>  </label>

         <div class="form-row added ng-binding content" ng-bind-html="question.getText()" id="text" ></div>
       <div class="form-row addlink ng-binding" ng-bind-html="question.getText()"><em><a class='inline' href="#inline_content">+ Add/Edit</a></em></div>

  <div style='display:none'>
   <div id='inline_content' style='padding:25px; background:#fff; font-size: 17px;'>
<form action="" id="popup_form">
    <div class="added">

        <div class="column-left">
                <label class="checkbox" for="checkbox1" style="font-size:20px;">
                <input type="checkbox" name="complaint" value="One" id="checkbox1" data-toggle="checkbox">
                One
                </label>
                <br/>
                <label class="checkbox" for="checkbox2" style="font-size:20px;">
                <input type="checkbox" name="complaint" value="Two" id="checkbox2" data-toggle="checkbox">
                Two
                </label>

</body>
</html>